import dotenv from 'dotenv';
dotenv.config();

const appConfig = {
    server: {
        port: process.env.PORT || 3001,
        env: process.env.NODE_ENV || 'development',
        apiVersion: process.env.API_VERSION || 'v1'
    },
    google: {
        vision: {
            projectId: process.env.GOOGLE_CLOUD_PROJECT_ID
        },
        storage: {
            projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
            bucketName: process.env.GCS_BUCKET_NAME,
            folderPath: process.env.GCS_FOLDER_PATH || 'receipts'
        }
    },
    ai: {
        gemini: {
            apiKey: process.env.GEMINI_API_KEY
        }
    },
    upload: {
        maxFileSize: process.env.MAX_FILE_SIZE || '10mb',
        allowedMimeTypes: process.env.ALLOWED_MIME_TYPES?.split(',') || [
            'image/jpeg',
            'image/jpg',
            'image/png',
            'image/gif',
            'image/bmp',
            'image/webp'
        ]
    }
};

// Validate required environment variables
const requiredEnvVars = [
    'GEMINI_API_KEY',
    'GOOGLE_CLOUD_PROJECT_ID',
    'GCS_BUCKET_NAME'
];

const missingEnvVars = requiredEnvVars.filter(envVar => !process.env[envVar]);

if (missingEnvVars.length > 0) {
    console.error('❌ Missing required environment variables:', missingEnvVars.join(', '));
    console.error('Please check your .env file and ensure all required variables are set.');
    process.exit(1);
}

export default appConfig;
