export const RECEIPT_PARSING_TEMPLATE = {
    instruction: "Convert this receipt text into structured JSON and include a clear categorization of the bill such as 'Restaurant', 'Clothing', 'Grocery', 'Medicine', 'Travel', or 'Other'.",
    format: {
        category: "string",
        vendor: "string",
        date: "YYYY-MM-DD",
        items: [{"name": "string", "price": "number"}],
        taxes:{"cgst": "number", "sgst": "number", "serviceCharge": "number", "roundOff": "number"},
        total: "number"
    },
    rules: [

        "Extract vendor/store name from the text and based on the reciept ",
        "Convert dates to YYYY-MM-DD format",
        "Parse individual items with names and prices",
        "Ensure prices are numbers (not strings)",
        "Calculate or extract the total amount",
        "If any field cannot be determined, use null",
        "Please ensure the output is ONLY the JSON object, wrapped in a ```json code block, and nothing else."
    ]
};

export const buildReceiptPrompt = (rawText) => {
    const {instruction, format, rules} = RECEIPT_PARSING_TEMPLATE;

    return `
${instruction}
"""
${rawText}
"""
Format:
\`\`\`json
${JSON.stringify(format, null, 2)}
\`\`\`
Rules:
${rules.map(rule => `- ${rule}`).join('\n')}
`;
};
