export const RECEIPT_PARAGRAPH_TEMPLATE = {
  instruction:
    "Use the following OCR text and convert it into paragraph-style human-readable format. At the end of the paragraph, include a clear categorization of the bill such as 'Restaurant', 'Clothing', 'Grocery', 'Medicine', 'Travel', or 'Other'.",
  format: `Vendor : [Vendor Name] Bill

Description:
This bill is from [Vendor Name], located at [Full Address]. The establishment is managed by [Management/Company Name], with details such as GSTIN: [GST Number], FSSAI: [FSSAI Number], and other identifiers like HSN/SAC if present. This was a [Order Type] (e.g., Dine-In, Takeaway, Delivery) order, possibly associated with Table #[Number], Bill No. [Bill Number], or Order No. [Order Number]. Any relevant contact information like phone or email can also be included. The subtotal for the items was Rs. [Subtotal Amount]. Additional charges such as CGST, SGST, service charge, and round-off (if any) should be mentioned. The final bill total was Rs. [Total Amount].

Items and Price:
The bill includes [X] item(s): [Item Name] ([Quantity] unit(s) @ Rs. [Price each], totaling Rs. [Total]), and so on for each item.

Date and Experience:
The visit to [Vendor Name] was on [Full Date] at [Time if available]. If the bill includes any message like “Thank You” or other sentiments, note them as a sign of a positive experience.

Category:
This bill falls under the category: [One of: Restaurant, Clothing, Grocery, Medicine, Travel, Other]
`,
  rules: [
    "Add appropriate titles for each section",
    "Ensure descriptive sentences for summary",
    "Add full vendor address and contact info if available",
    "Include management/company name and identifiers like GSTIN, FSSAI, HSN",
    "Group item names with their price (and quantity if found)",
    "Use paragraph form, not structured JSON",
    "Format should be copy-paste ready plain text",
    "Do NOT add any extra commentary or metadata",
    "Ensure all known fields are clearly written out, skip unknowns",
    "At the end, always include a clear 'Category:' line"
  ]
};

export const buildParagraphPrompt = (rawText) => {
  const { instruction, format, rules } = RECEIPT_PARAGRAPH_TEMPLATE;

  return `
${instruction}

Output Format:
------------------
${format}

Raw OCR Text:
"""
${rawText}
"""

Rules:
${rules.map(rule => `- ${rule}`).join('\n')}
  `;
};
