import multer from 'multer';
import appConfig from '../config/appConfig.js';

const createUploadMiddleware = (fieldName = 'file') => {
    const upload = multer({
        storage: multer.memoryStorage(),
        limits: {
            fileSize: parseInt(appConfig.upload.maxFileSize.replace('mb', '')) * 1024 * 1024 // Convert to bytes
        },
        fileFilter: (req, file, cb) => {
            // Check if a file type is allowed
            if (appConfig.upload.allowedMimeTypes.includes(file.mimetype)) {
                cb(null, true);
            } else {
                const error = new Error(
                    `File type ${file.mimetype} is not allowed. Allowed types: ${appConfig.upload.allowedMimeTypes.join(', ')}`
                );
                error.status = 400;
                cb(error, false);
            }
        }
    });

    return upload.single(fieldName);
};

const handleUploadError = (error, req, res, next) => {
    if (error instanceof multer.MulterError) {
        if (error.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({
                success: false,
                message: `File size exceeds the maximum limit of ${appConfig.upload.maxFileSize}`
            });
        }
        if (error.code === 'LIMIT_UNEXPECTED_FILE') {
            return res.status(400).json({
                success: false,
                message: 'Unexpected field name for file upload'
            });
        }
    }

    if (error.message && error.message.includes('File type')) {
        return res.status(400).json({
            success: false,
            message: error.message
        });
    }

    next(error);
};

// Pre-configured middleware for common use cases
export const receiptUpload = createUploadMiddleware('receipt');

export { createUploadMiddleware, handleUploadError };
export default createUploadMiddleware;
