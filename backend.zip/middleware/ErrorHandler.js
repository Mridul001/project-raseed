import appConfig from '../config/appConfig.js';

class ErrorHandler {

    static asyncHandler(fn) {
        return (req, res, next) => {
            Promise.resolve(fn(req, res, next)).catch(next);
        };
    }

    static globalErrorHandler(err, req, res, next) {
        console.error('❌ Global Error Handler:', {
            message: err.message,
            stack: err.stack,
            url: req.url,
            method: req.method,
            timestamp: new Date().toISOString(),
            userAgent: req.get('User-Agent')
        });

        // Determine error status code
        const statusCode = err.statusCode || err.status || 500;

        // Determine error code
        let errorCode = err.code || 'INTERNAL_ERROR';
        let errorMessage = err.message || 'Internal server error';

        // Handle specific error types
        if (err.name === 'ValidationError') {
            errorCode = 'VALIDATION_ERROR';
        } else if (err.name === 'CastError') {
            errorCode = 'INVALID_DATA';
            errorMessage = 'Invalid data format';
        } else if (err.code === 'ENOENT') {
            errorCode = 'FILE_NOT_FOUND';
            errorMessage = 'Requested file not found';
        }

        // Send error response
        res.status(statusCode).json({
            success: false,
            error: {
                message: errorMessage,
                code: errorCode,
                timestamp: new Date().toISOString(),
                ...(appConfig.server.env === 'development' && {
                    stack: err.stack,
                    details: err
                })
            }
        });
    }

    static notFoundHandler(req, res) {
        res.status(404).json({
            success: false,
            error: {
                message: `Route ${req.method} ${req.originalUrl} not found`,
                code: 'ROUTE_NOT_FOUND',
                timestamp: new Date().toISOString()
            }
        });
    }

    static createError(message, statusCode = 500, code = 'CUSTOM_ERROR') {
        const error = new Error(message);
        error.statusCode = statusCode;
        error.code = code;
        return error;
    }
}

export default ErrorHandler;
