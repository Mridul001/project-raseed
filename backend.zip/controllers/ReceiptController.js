import receiptService from '../services/ReceiptService.js';

class ReceiptController {

    async uploadReceipt(req, res) {
        try {
            // Validate file upload
            if (!req.file) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'No file uploaded. Please upload a receipt image.',
                        code: 'FILE_REQUIRED'
                    }
                });
            }

            const buffer = req.file.buffer;
            const fileInfo = {
                originalName: req.file.originalname,
                mimetype: req.file.mimetype,
                size: req.file.size
            };

            console.log(`🧠 Received in-memory image: ${fileInfo.originalName} (${fileInfo.size} bytes)`);

            // Process the receipt using service
            const result = await receiptService.processReceipt(buffer, fileInfo);

            res.status(200).json({
                success: true,
                data: result
            });

        } catch (err) {
            console.error('❌ Error in receiptController:', err.message);

            // Handle multer errors
            if (err.code === 'LIMIT_FILE_SIZE') {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: 'File size too large',
                        code: 'FILE_TOO_LARGE'
                    }
                });
            }

            if (err.message.includes('File type') && err.message.includes('not allowed')) {
                return res.status(400).json({
                    success: false,
                    error: {
                        message: err.message,
                        code: 'INVALID_FILE_TYPE'
                    }
                });
            }

            res.status(500).json({
                success: false,
                error: {
                    message: 'Failed to process receipt',
                    code: 'PROCESSING_ERROR',
                    details: err.message
                }
            });
        }
    }
}

export default new ReceiptController();
