import express from 'express';
import cors from 'cors';
import appConfig from './config/appConfig.js';
import routes from './routes/index.js';

const app = express();
const PORT = appConfig.server.port;

// Middleware
app.use(cors());
app.use(express.json({ limit: appConfig.upload.maxFileSize }));
app.use(express.urlencoded({ extended: true, limit: appConfig.upload.maxFileSize }));

// Health check route
app.get('/health', (req, res) => {
  res.status(200).send('OK');
});

// Routes
app.use('/api', routes);

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
  console.log(`📊 Environment: ${appConfig.server.env}`);
  console.log(`🔗 API Version: ${appConfig.server.apiVersion}`);
  console.log(`🔍 Health check: http://localhost:${PORT}/health`);
});

export default app;
