# project-raseed

receipt prompt - 

instruction: "Convert this receipt text into structured JSON:",
    format: {
        vendor: "string",
        date: "YYYY-MM-DD",
        items: [{"name": "string", "price": "number"}],
        total: "number"
    },
    rules: [
        "Extract vendor/store name from the text",
        "Convert dates to YYYY-MM-DD format",
        "Parse individual items with names and prices",
        "Ensure prices are numbers (not strings)",
        "Calculate or extract the total amount",
        "If any field cannot be determined, use null",
        "Please ensure the output is ONLY the JSON object, wrapped in a ```json code block, and nothing else."
    ]
};


