import express from 'express';
import receiptRoutes from './receiptRoutes.js'; // Ensure .js extension if you're using ES Modules

const router = express.Router();

// Add all routes here.
router.use('/receipt', receiptRoutes);

router.get('/health', (req, res) => {
    res.status(200).json({
        status: 'OK',
        message: 'API is running',
        timestamp: new Date().toISOString()
    });
});

// router.use('*', (req, res) => {
//     res.status(404).json({
//         error: 'API endpoint not found',
//         path: req.originalUrl
//     });
// });

export default router;
