import express from 'express';
import receiptController from '../controllers/ReceiptController.js';
import { receiptUpload, handleUploadError } from '../middleware/UploadMiddleware.js';

const router = express.Router();

// Receipt upload route with middleware
router.post('/upload',
    receiptUpload,
    receiptController.uploadReceipt
);


export default router;
