import {GoogleGenerativeAI} from '@google/generative-ai';
import appConfig from '../config/appConfig.js';
import {buildReceiptPrompt} from '../utils/prompts/receiptPrompt.js';
import {buildParagraphPrompt} from '../utils/prompts/buildTextPrompt.js';

class AiService {
    constructor() {
        const API_KEY = appConfig.ai.gemini.apiKey;

        if (!API_KEY) {
            throw new Error('GEMINI_API_KEY is not configured in environment variables');
        }

        this.genAI = new GoogleGenerativeAI(API_KEY);
    }

    async formatReceiptText(rawText) {
        try {
            if (!rawText || rawText.trim().length === 0) {
                throw new Error('No text provided for AI processing');
            }

            const model = this.genAI.getGenerativeModel({
                model: 'gemini-1.5-pro',
            });

            const prompt = buildReceiptPrompt(rawText);

            const result = await model.generateContent(prompt);
            const response = await result.response;
            let text = response.candidates?.[0]?.content?.parts?.[0]?.text;

            if (!text) {
                throw new Error('No response generated from AI service');
            }

            // Extract JSON from response
            const structuredData = this._extractJsonFromResponse(text);
            return structuredData;

        } catch (error) {
            console.error('❌ AI Service Error:', error.message);
            throw new Error(`AI processing failed: ${error.message}`);
        }
    }

    async formatReceiptTextTOText(rawText) {
        try {
            if (!rawText || rawText.trim().length === 0) {
                throw new Error('No text provided for AI processing');
            }

            const model = this.genAI.getGenerativeModel({
                model: 'gemini-1.5-pro',
            });

            const prompt = buildParagraphPrompt(rawText);

            const result = await model.generateContent(prompt);
            const response = await result.response;
            let text = response.candidates?.[0]?.content?.parts?.[0]?.text;

            if (!text) {
                throw new Error('No response generated from AI service');
            }

            // Extract JSON from response
           
            return text;

        } catch (error) {
            console.error('❌ AI Service Error:', error.message);
            throw new Error(`AI processing failed: ${error.message}`);
        }
    }

    _buildPrompt(rawText) {
        return `
Convert this receipt text into structured JSON:
"""
${rawText}
"""
Format:
\`\`\`json
{
  "vendor": "string",
  "date": "YYYY-MM-DD",
  "items": [{"name": "string", "price": number}],
  "total": number
}
\`\`\`
Rules:
- Extract vendor/store name from the text
- Convert dates to YYYY-MM-DD format
- Parse individual items with names and prices
- Ensure prices are numbers (not strings)
- Calculate or extract the total amount
- If any field cannot be determined, use null
- Please ensure the output is ONLY the JSON object, wrapped in a \`\`\`json code block, and nothing else.
`;
    }


    _extractJsonFromResponse(text) {
        let jsonString = '';

        // Regex to find JSON within ```json ... ```
        const jsonRegex = /```json\s*([\s\S]*?)\s*```/;
        // Regex for any code block
        const genericCodeBlockRegex = /```(?:\w+)?\s*([\s\S]*?)\s*```/;

        const jsonMatch = text.match(jsonRegex);
        const genericCodeMatch = text.match(genericCodeBlockRegex);

        if (jsonMatch && jsonMatch[1]) {
            jsonString = jsonMatch[1].trim();
        } else if (genericCodeMatch && genericCodeMatch[1]) {
            jsonString = genericCodeMatch[1].trim();
        } else {
            // Fallback: If no code block, assume the entire response is JSON
            jsonString = text.trim();
        }

        try {
            const parsedData = JSON.parse(jsonString);

            // Validate basic structure
            if (typeof parsedData !== 'object' || parsedData === null) {
                throw new Error('AI response is not a valid object');
            }

            return parsedData;
        } catch (parseError) {
            console.error("❌ Failed to parse AI response as JSON:");
            console.error("Full response:\n", text);
            console.error("Attempted to parse:\n", jsonString);
            throw new Error(`Invalid JSON response from AI service: ${parseError.message}`);
        }
    }
}

export default new AiService();
