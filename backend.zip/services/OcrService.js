import vision from '@google-cloud/vision';
import appConfig from '../config/appConfig.js';

class OcrService {
    constructor() {
        // Initialize Vision client with config
        const clientConfig = {};

        if (appConfig.google.vision.projectId) {
            clientConfig.projectId = appConfig.google.vision.projectId;
        }

        if (appConfig.google.vision.keyFilename) {
            clientConfig.keyFilename = appConfig.google.vision.keyFilename;
        }

        this.visionClient = new vision.ImageAnnotatorClient(clientConfig);
    }

    async extractTextFromImage(imageInput) {
        try {
            let result;

            if (Buffer.isBuffer(imageInput)) {
                // If the buffer passed, use a content option
                [result] = await this.visionClient.textDetection({
                    image: { content: imageInput }
                });
            } else {
                // If a file path passed
                [result] = await this.visionClient.textDetection(imageInput);
            }

            const detections = result.textAnnotations;
            const extractedText = detections[0]?.description || '';

            if (!extractedText || extractedText.trim().length === 0) {
                throw new Error('No text detected in the image. Please ensure the image contains readable text.');
            }

            return extractedText;

        } catch (error) {
            console.error('❌ OCR Service Error:', error.message);

            if (error.message.includes('No text detected')) {
                throw error; // Re-throw our custom error
            }

            throw new Error(`OCR processing failed: ${error.message}`);
        }
    }
}

export default new OcrService();
