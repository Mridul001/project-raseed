import admin from 'firebase-admin';
import { readFileSync } from 'fs';
import { getFirestore } from 'firebase-admin/firestore';
import { randomUUID } from 'crypto';


const serviceAccount = JSON.parse(
  readFileSync(process.env.GOOGLE_APPLICATION_CREDENTIALS)
);

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}
const db = getFirestore(admin.app(), 'raseed');



// 🔄 Save to Firestore
export async function storeReceipt(data) {
  try {
    const id = randomUUID();
    const newData = { id, ...data };
    const docRef = await db.collection('receipts').add(newData);
    console.log('✅ Document written with ID:', docRef.id);
  } catch (error) {
    console.error('❌ Error writing document:', error);
  }
}

