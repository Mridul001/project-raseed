import { Storage } from '@google-cloud/storage';
import appConfig from '../config/appConfig.js';

class StorageService {
    constructor() {
        this.storage = new Storage({
            projectId: appConfig.google.storage.projectId,
            keyFilename: appConfig.google.storage.keyFilename
        });
        this.bucketName = appConfig.google.storage.bucketName;
        this.folderPath = appConfig.google.storage.folderPath;
        this.bucket = this.storage.bucket(this.bucketName);
    }

    /**
     * Generate a unique filename for the receipt JSON
     * @param {string} originalFileName - Original file name if available
     * @returns {string} Generated filename
     */
    _generateFileName(originalFileName = null) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const randomId = Math.random().toString(36).substr(2, 9);

        let baseName = 'receipt';
        if (originalFileName) {
            // Remove extension and clean the name
            baseName = originalFileName.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9]/g, '_');
        }

        return `${this.folderPath}/${baseName}_${timestamp}_${randomId}.json`;
    }

    /**
     * Store receipt data as JSON file in Google Cloud Storage
     * @param {Object} receiptData - The processed receipt data
     * @param {string} originalFileName - Original file name for reference
     * @returns {Object} Storage result with file URL and metadata
     */
    async storeReceiptData(receiptData, originalFileName = null) {
        try {
            console.log('💾 Storing receipt data in Google Cloud Storage...');

            const fileName = this._generateFileName(originalFileName);
            const file = this.bucket.file(fileName);

            // Convert data to JSON string
            const jsonData = JSON.stringify(receiptData, null, 2);

            // Upload the file
            await file.save(jsonData, {
                metadata: {
                    contentType: 'application/json',
                    metadata: {
                        originalFileName: originalFileName || 'unknown',
                        uploadedAt: new Date().toISOString(),
                        dataType: 'receipt_processed',
                        version: '1.0'
                    }
                },
                resumable: false
            });

            // Generate signed URL for accessing the file (optional, valid for 1 hour)
            const [signedUrl] = await file.getSignedUrl({
                action: 'read',
                expires: Date.now() + 1000 * 60 * 60 // 1 hour
            });

            const result = {
                success: true,
                fileName,
                bucketName: this.bucketName,
                signedUrl,
                publicUrl: `gs://${this.bucketName}/${fileName}`,
                uploadedAt: new Date().toISOString()
            };

            console.log(`✅ Receipt data stored successfully: ${fileName}`);
            return result;

        } catch (error) {
            console.error('❌ Failed to store receipt data in GCS:', error.message);
            throw new Error(`Storage failed: ${error.message}`);
        }
    }

    /**
     * Retrieve receipt data from Google Cloud Storage
     * @param {string} fileName - The file name to retrieve
     * @returns {Object} The receipt data
     */
    async getReceiptData(fileName) {
        try {
            console.log(`📥 Retrieving receipt data: ${fileName}`);

            const file = this.bucket.file(fileName);
            const [exists] = await file.exists();

            if (!exists) {
                throw new Error(`File not found: ${fileName}`);
            }

            const [contents] = await file.download();
            const receiptData = JSON.parse(contents.toString());

            console.log(`✅ Receipt data retrieved successfully: ${fileName}`);
            return receiptData;

        } catch (error) {
            console.error('❌ Failed to retrieve receipt data from GCS:', error.message);
            throw new Error(`Retrieval failed: ${error.message}`);
        }
    }

    /**
     * List all receipt files in the storage bucket
     * @param {number} limit - Maximum number of files to return
     * @returns {Array} List of file metadata
     */
    async listReceiptFiles(limit = 100) {
        try {
            console.log('📋 Listing receipt files from GCS...');

            const [files] = await this.bucket.getFiles({
                prefix: this.folderPath,
                maxResults: limit
            });

            const fileList = files.map(file => ({
                name: file.name,
                size: file.metadata.size,
                updated: file.metadata.updated,
                contentType: file.metadata.contentType,
                originalFileName: file.metadata.metadata?.originalFileName || 'unknown'
            }));

            console.log(`✅ Found ${fileList.length} receipt files`);
            return fileList;

        } catch (error) {
            console.error('❌ Failed to list receipt files from GCS:', error.message);
            throw new Error(`Listing failed: ${error.message}`);
        }
    }

    /**
     * Delete a receipt file from Google Cloud Storage
     * @param {string} fileName - The file name to delete
     * @returns {boolean} Success status
     */
    async deleteReceiptFile(fileName) {
        try {
            console.log(`🗑️ Deleting receipt file: ${fileName}`);

            const file = this.bucket.file(fileName);
            await file.delete();

            console.log(`✅ Receipt file deleted successfully: ${fileName}`);
            return true;

        } catch (error) {
            console.error('❌ Failed to delete receipt file from GCS:', error.message);
            throw new Error(`Deletion failed: ${error.message}`);
        }
    }

    /**
     * Check if the bucket exists and is accessible
     * @returns {boolean} Bucket accessibility status
     */
    async checkBucketAccess() {
        try {
            const [exists] = await this.bucket.exists();
            if (!exists) {
                throw new Error(`Bucket ${this.bucketName} does not exist`);
            }

            // Try to list files to verify access
            await this.bucket.getFiles({ maxResults: 1 });

            console.log(`✅ Bucket ${this.bucketName} is accessible`);
            return true;

        } catch (error) {
            console.error(`❌ Bucket access check failed: ${error.message}`);
            throw new Error(`Bucket access failed: ${error.message}`);
        }
    }
    /**
 * Append formatted text to a category-based .txt file in GCS bucket
 * @param {string} formattedText - The plain text to append (must include "Category: XYZ" line)
 * @param {string} originalFileName - Source file name for context
 */
async appendFormattedTextToGCS(formattedText, originalFileName = 'unknown') {
    try {
        // 🔍 Extract category from formattedText
        const categoryMatch = formattedText.match(/Category:\s*(.+)/i);
        const category = categoryMatch ? categoryMatch[1].trim().toLowerCase().replace(/\s+/g, '_') : 'uncategorized';
        const targetFileName = `${category}.txt`; // e.g., restaurant.txt, grocery.txt

        const filePath = `${this.folderPath}/${targetFileName}`;
        const file = this.bucket.file(filePath);

        let existingContent = '';
        const [exists] = await file.exists();

        if (exists) {
            // Download existing content
            const [data] = await file.download();
            existingContent = data.toString();
        }

        // Append new content with header
        const timestamp = new Date().toISOString();
        const updatedContent = existingContent + '\n' + formattedText;

        // Upload updated content
        await file.save(updatedContent, {
            metadata: {
                contentType: 'text/plain',
                metadata: {
                    originalFileName,
                    appendedAt: timestamp,
                    category,
                    dataType: 'receipt_text',
                    version: '1.0'
                }
            },
            resumable: false
        });

        console.log(`📝 Text appended to GCS file: ${filePath}`);
        return {
            success: true,
            category,
            filePath,
            bucketName: this.bucketName,
            publicUrl: `gs://${this.bucketName}/${filePath}`
        };

    } catch (error) {
        console.error('❌ Failed to append text to GCS file:', error.message);
        throw new Error(`Append failed: ${error.message}`);
    }
}


}

export default new StorageService();
