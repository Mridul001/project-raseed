import ocrService from './OcrService.js';
import aiService from './AiService.js';
import storageService from './storageService.js';
import { appendFile } from 'fs/promises';
import { storeReceipt } from './FireStore.js';
import path from 'path';


class ReceiptService {

    async processReceipt(imageInput, fileInfo = {}) {
        try {
            console.log('🔄 Starting receipt processing...');

            if (fileInfo.originalName) {
                console.log(`📄 Processing file: ${fileInfo.originalName}`);
            }

            // Step 1: Extract text from image using OCR
            console.log('📸 Extracting text from image...');
            const rawText = await ocrService.extractTextFromImage(imageInput);

            console.log("🔍 Raw OCR Text:\n", rawText);

            // Step 2: Format text into structured data using AI
            console.log('🤖 Formatting text with AI...');
            const structuredData = await aiService.formatReceiptText(rawText);
            console.log("structuredData", structuredData);
            storeReceipt(structuredData);
            const formattedText = await aiService.formatReceiptTextTOText(rawText);
            console.log("formattedText", formattedText);

            // Append formatted text to text file in GCS
            await storageService.appendFormattedTextToGCS(
                formattedText,
                fileInfo.originalName
            );
            // console.log("✅ Structured Receipt:\n", JSON.stringify(structuredData, null, 2));

            // let storageResult = null;
            // try {
            //     console.log('💾 Storing receipt data in cloud storage...');
            //     storageResult = await storageService.storeReceiptData(
            //         structuredData,
            //         fileInfo.originalName
            //     );
            //     console.log('✅ Receipt data stored successfully in cloud storage');
            // } catch (storageError) {
            //     console.warn('⚠️ Failed to store receipt data in cloud storage:', storageError.message);
            //     // Continue processing even if storage fails
            // }

            // Prepare the complete response object
            return {
                formattedText: formattedText,
                
            
            };

        } catch (error) {
            console.error("❌ Receipt processing failed:", error.message);
            throw error;
        }
    }
}

export default new ReceiptService();
