import React, { useState, useEffect } from 'react';

const InteractiveNotFound404SVG = () => {
    const [hoveredElement, setHoveredElement] = useState(null);

    return (
        <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 800 400"
            className="w-full max-w-3xl mx-auto"
        >
            {/* Gradient definitions */}
            <defs>
                <linearGradient id="primaryGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="var(--color-primary-light)" />
                    <stop offset="100%" stopColor="var(--color-primary)" />
                </linearGradient>

                <linearGradient id="secondaryGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="var(--color-secondary-light)" />
                    <stop offset="100%" stopColor="var(--color-secondary)" />
                </linearGradient>

                <linearGradient id="accentGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="var(--color-accent-light)" />
                    <stop offset="100%" stopColor="var(--color-accent)" />
                </linearGradient>

                {/* Animated dash pattern */}
                <pattern id="pattern-circles" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                    <circle cx="10" cy="10" r="2" fill="var(--color-primary-light)" fillOpacity="0.3" />
                </pattern>

                {/* Glow filter */}
                <filter id="glow">
                    <feGaussianBlur stdDeviation="5" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>

                {/* Drop shadow */}
                <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                    <feDropShadow dx="0" dy="10" stdDeviation="15" floodColor="var(--color-primary-dark)" floodOpacity="0.3" />
                </filter>
            </defs>

            {/* Background layers */}
            <rect x="0" y="0" width="800" height="400" fill="url(#pattern-circles)" opacity="0.5" />
            <circle cx="400" cy="200" r="180" fill="var(--color-primary)" fillOpacity="0.05">
                <animate attributeName="r" values="180;190;180" dur="5s" repeatCount="indefinite" />
            </circle>
            <ellipse cx="400" cy="320" rx="300" ry="30" fill="var(--color-secondary)" fillOpacity="0.1" />

            {/* Dynamic paths */}
            <path
                d="M100,350 Q250,200 400,350 T700,350"
                stroke="var(--color-primary-light)"
                strokeWidth="2"
                fill="none"
                strokeDasharray="5,5"
            >
                <animate
                    attributeName="d"
                    values="M100,350 Q250,200 400,350 T700,350;
                            M100,330 Q250,220 400,330 T700,330;
                            M100,350 Q250,200 400,350 T700,350"
                    dur="15s"
                    repeatCount="indefinite"
                />
            </path>

            <path
                d="M150,150 Q400,100 650,150"
                stroke="var(--color-secondary)"
                strokeOpacity="0.3"
                strokeWidth="2"
                fill="none"
                strokeDasharray="8,4"
            >
                <animate
                    attributeName="d"
                    values="M150,150 Q400,100 650,150;
                            M150,170 Q400,130 650,170;
                            M150,150 Q400,100 650,150"
                    dur="18s"
                    repeatCount="indefinite"
                />
            </path>

            {/* Left "4" */}
            <g
                id="number4-left"
                className="cursor-pointer"
                onMouseEnter={() => setHoveredElement('left-4')}
                onMouseLeave={() => setHoveredElement(null)}
            >
                <path
                    d="M60,0 L60,200 M0,150 L120,150"
                    transform="translate(70, 60)"
                    stroke="var(--color-primary-dark)"
                    strokeWidth="40"
                    strokeLinecap="round"
                    fill="none"
                    filter="url(#shadow)"
                >
                    <animate attributeName="opacity" values="0.8;1;0.8" dur="3s" repeatCount="indefinite" />
                </path>
                <circle
                    cx="130"
                    cy="160"
                    r="25"
                    fill="var(--color-primary-light)"
                    fillOpacity="0.5"
                    style={{
                        transform: hoveredElement === 'left-4' ? 'scale(1.2)' : 'scale(1)',
                        transition: 'transform 0.3s ease-out'
                    }}
                >
                    <animate attributeName="r" values="25;30;25" dur="2s" repeatCount="indefinite" />
                </circle>
            </g>

            {/* Middle "0" - Circular element */}
            <g
                id="number0"
                className="cursor-pointer"
                onMouseEnter={() => setHoveredElement('zero')}
                onMouseLeave={() => setHoveredElement(null)}
            >
                {/* Main circle */}
                <ellipse
                    cx="400"
                    cy="180"
                    rx="120"
                    ry="120"
                    fill="var(--color-primary)"
                    filter="url(#shadow)"
                    style={{
                        transform: hoveredElement === 'zero' ? 'scale(1.05)' : 'scale(1)',
                        transition: 'transform 0.3s ease-out',
                        transformOrigin: 'center'
                    }}
                >
                    <animate attributeName="rx" values="120;125;120" dur="4s" repeatCount="indefinite" />
                    <animate attributeName="ry" values="120;125;120" dur="3s" repeatCount="indefinite" />
                </ellipse>

                {/* Inner ring */}
                <ellipse
                    cx="400"
                    cy="180"
                    rx="100"
                    ry="100"
                    fill="var(--color-secondary)"
                    style={{
                        transform: hoveredElement === 'zero' ? 'scale(1.05)' : 'scale(1)',
                        transition: 'transform 0.3s ease-out',
                        transformOrigin: 'center'
                    }}
                >
                    <animate attributeName="opacity" values="1;0.9;1" dur="2.5s" repeatCount="indefinite" />
                </ellipse>

                {/* Clock element */}
                <g transform="translate(360, 110)">
                    <circle
                        cx="40"
                        cy="40"
                        r="30"
                        fill="var(--color-accent)"
                    />
                    <circle
                        cx="40"
                        cy="40"
                        r="25"
                        fill="var(--color-primary)"
                    />
                    <line
                        x1="40"
                        y1="40"
                        x2="25"
                        y2="55"
                        stroke="var(--color-accent-light)"
                        strokeWidth="3"
                        strokeLinecap="round"
                    >
                        <animateTransform
                            attributeName="transform"
                            type="rotate"
                            from="0 40 40"
                            to="360 40 40"
                            dur="6s"
                            repeatCount="indefinite"
                        />
                    </line>
                    <line
                        x1="40"
                        y1="40"
                        x2="50"
                        y2="30"
                        stroke="var(--color-accent-light)"
                        strokeWidth="3"
                        strokeLinecap="round"
                    >
                        <animateTransform
                            attributeName="transform"
                            type="rotate"
                            from="0 40 40"
                            to="360 40 40"
                            dur="30s"
                            repeatCount="indefinite"
                        />
                    </line>
                </g>

                {/* Box element top */}
                <g transform="translate(440, 120)">
                    <rect
                        x="0"
                        y="0"
                        width="30"
                        height="30"
                        fill="var(--color-accent-light)"
                    >
                        <animate
                            attributeName="y"
                            values="0;-5;0"
                            dur="2s"
                            repeatCount="indefinite"
                        />
                    </rect>
                </g>

                {/* Box element right */}
                <g transform="translate(470, 170)">
                    <rect
                        x="0"
                        y="0"
                        width="30"
                        height="40"
                        fill="var(--color-accent)"
                    >
                        <animate
                            attributeName="y"
                            values="0;5;0"
                            dur="3s"
                            repeatCount="indefinite"
                        />
                    </rect>
                    <line
                        x1="15"
                        y1="0"
                        x2="15"
                        y2="40"
                        stroke="var(--color-accent-dark)"
                        strokeWidth="2"
                    />
                    <line
                        x1="0"
                        y1="20"
                        x2="30"
                        y2="20"
                        stroke="var(--color-accent-dark)"
                        strokeWidth="2"
                    />
                </g>

                {/* Bicycle element */}
                <g transform="translate(320, 230)">
                    {/* Bicycle frame */}
                    <path
                        d="M30,0 L45,30 L10,30 Z"
                        fill="var(--color-accent)"
                        strokeWidth="4"
                        stroke="var(--color-accent-dark)"
                    >
                        <animate
                            attributeName="transform"
                            values="translate(0,0);translate(0,-3);translate(0,0)"
                            dur="1s"
                            repeatCount="indefinite"
                        />
                    </path>

                    {/* Wheels */}
                    <g>
                        <circle
                            cx="10"
                            cy="45"
                            r="15"
                            fill="none"
                            stroke="var(--color-accent)"
                            strokeWidth="4"
                        >
                            <animate
                                attributeName="transform"
                                values="translate(0,0);translate(0,-3);translate(0,0)"
                                dur="1s"
                                repeatCount="indefinite"
                            />
                        </circle>
                        <g>
                            <animateTransform
                                attributeName="transform"
                                type="rotate"
                                from="0 10 45"
                                to="360 10 45"
                                dur="2s"
                                repeatCount="indefinite"
                            />
                            <line
                                x1="10"
                                y1="30"
                                x2="10"
                                y2="60"
                                stroke="var(--color-accent-light)"
                                strokeWidth="1"
                            />
                            <line
                                x1="-5"
                                y1="45"
                                x2="25"
                                y2="45"
                                stroke="var(--color-accent-light)"
                                strokeWidth="1"
                            />
                        </g>
                    </g>

                    <g>
                        <circle
                            cx="45"
                            cy="45"
                            r="15"
                            fill="none"
                            stroke="var(--color-accent)"
                            strokeWidth="4"
                        >
                            <animate
                                attributeName="transform"
                                values="translate(0,0);translate(0,-3);translate(0,0)"
                                dur="1s"
                                repeatCount="indefinite"
                            />
                        </circle>
                        <g>
                            <animateTransform
                                attributeName="transform"
                                type="rotate"
                                from="0 45 45"
                                to="360 45 45"
                                dur="2s"
                                repeatCount="indefinite"
                            />
                            <line
                                x1="45"
                                y1="30"
                                x2="45"
                                y2="60"
                                stroke="var(--color-accent-light)"
                                strokeWidth="1"
                            />
                            <line
                                x1="30"
                                y1="45"
                                x2="60"
                                y2="45"
                                stroke="var(--color-accent-light)"
                                strokeWidth="1"
                            />
                        </g>
                    </g>

                    {/* Handlebars */}
                    <path
                        d="M45,30 C55,25 55,15 45,10"
                        fill="none"
                        stroke="var(--color-accent)"
                        strokeWidth="4"
                        strokeLinecap="round"
                    >
                        <animate
                            attributeName="transform"
                            values="translate(0,0);translate(0,-3);translate(0,0)"
                            dur="1s"
                            repeatCount="indefinite"
                        />
                    </path>

                    {/* Seat */}
                    <path
                        d="M30,0 C25,0 20,-5 15,-5"
                        fill="none"
                        stroke="var(--color-accent)"
                        strokeWidth="4"
                        strokeLinecap="round"
                    >
                        <animate
                            attributeName="transform"
                            values="translate(0,0);translate(0,-3);translate(0,0)"
                            dur="1s"
                            repeatCount="indefinite"
                        />
                    </path>
                </g>

                {/* Box element bottom */}
                <g transform="translate(430, 230)">
                    <rect
                        x="0"
                        y="0"
                        width="30"
                        height="30"
                        fill="var(--color-accent-light)"
                    >
                        <animate
                            attributeName="y"
                            values="0;5;0"
                            dur="2.5s"
                            repeatCount="indefinite"
                        />
                    </rect>
                </g>
            </g>

            {/* Right "4" */}
            <g
                id="number4-right"
                className="cursor-pointer"
                onMouseEnter={() => setHoveredElement('right-4')}
                onMouseLeave={() => setHoveredElement(null)}
            >
                <path
                    d="M60,0 L60,200 M0,150 L120,150"
                    transform="translate(570, 60)"
                    stroke="var(--color-primary-dark)"
                    strokeWidth="40"
                    strokeLinecap="round"
                    fill="none"
                    filter="url(#shadow)"
                >
                    <animate attributeName="opacity" values="0.8;1;0.8" dur="3s" repeatCount="indefinite" />
                </path>
                <circle
                    cx="630"
                    cy="160"
                    r="25"
                    fill="var(--color-primary-light)"
                    fillOpacity="0.5"
                    style={{
                        transform: hoveredElement === 'right-4' ? 'scale(1.2)' : 'scale(1)',
                        transition: 'transform 0.3s ease-out'
                    }}
                >
                    <animate attributeName="r" values="25;30;25" dur="2s" repeatCount="indefinite" />
                </circle>
            </g>

            {/* Horizontal lines */}
            <line
                x1="60"
                y1="350"
                x2="350"
                y2="350"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            >
                <animate
                    attributeName="strokeDasharray"
                    values="0,300;300,0"
                    dur="2s"
                    begin="0s"
                    fill="freeze"
                />
            </line>
            <line
                x1="450"
                y1="350"
                x2="740"
                y2="350"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            >
                <animate
                    attributeName="strokeDasharray"
                    values="0,300;300,0"
                    dur="2s"
                    begin="0.3s"
                    fill="freeze"
                />
            </line>
            <line
                x1="200"
                y1="380"
                x2="320"
                y2="380"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            >
                <animate
                    attributeName="strokeDasharray"
                    values="0,120;120,0"
                    dur="2s"
                    begin="0.6s"
                    fill="freeze"
                />
            </line>
            <line
                x1="480"
                y1="380"
                x2="600"
                y2="380"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            >
                <animate
                    attributeName="strokeDasharray"
                    values="0,120;120,0"
                    dur="2s"
                    begin="0.6s"
                    fill="freeze"
                />
            </line>
            <line
                x1="340"
                y1="380"
                x2="360"
                y2="380"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            >
                <animate
                    attributeName="strokeDasharray"
                    values="0,20;20,0"
                    dur="1s"
                    begin="0.9s"
                    fill="freeze"
                />
            </line>
            <line
                x1="380"
                y1="380"
                x2="390"
                y2="380"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            >
                <animate
                    attributeName="strokeDasharray"
                    values="0,10;10,0"
                    dur="1s"
                    begin="1s"
                    fill="freeze"
                />
            </line>
            <line
                x1="400"
                y1="380"
                x2="440"
                y2="380"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            >
                <animate
                    attributeName="strokeDasharray"
                    values="0,40;40,0"
                    dur="1s"
                    begin="1.1s"
                    fill="freeze"
                />
            </line>
            <line
                x1="450"
                y1="380"
                x2="470"
                y2="380"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            >
                <animate
                    attributeName="strokeDasharray"
                    values="0,20;20,0"
                    dur="1s"
                    begin="1.2s"
                    fill="freeze"
                />
            </line>
        </svg>
    );
};

export default InteractiveNotFound404SVG;
