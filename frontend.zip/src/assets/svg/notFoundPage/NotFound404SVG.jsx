import React from 'react';

const NotFound404SVG = () => {
    return (
        <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 800 400"
            className="w-full max-w-2xl mx-auto"
        >
            {/* Background elements */}
            <rect x="0" y="0" width="800" height="400" fill="transparent" />

            {/* Left "4" */}
            <g transform="translate(70, 60)">
                <path
                    d="M60,0 L60,200 M0,150 L120,150"
                    className="stroke-primary-dark"
                    strokeWidth="40"
                    strokeLinecap="round"
                    fill="none"
                />
            </g>

            {/* Middle "0" - Circular element */}
            <g transform="translate(250, 60)">
                {/* Main circle */}
                <circle
                    cx="150"
                    cy="120"
                    r="120"
                    className="fill-primary"
                />

                {/* Inner ring */}
                <circle
                    cx="150"
                    cy="120"
                    r="100"
                    className="fill-secondary"
                />

                {/* Clock element */}
                <g transform="translate(110, 50)">
                    <circle
                        cx="40"
                        cy="40"
                        r="30"
                        className="fill-accent"
                    />
                    <circle
                        cx="40"
                        cy="40"
                        r="25"
                        className="fill-primary"
                    />
                    <line
                        x1="40"
                        y1="40"
                        x2="25"
                        y2="55"
                        className="stroke-accent-light"
                        strokeWidth="3"
                        strokeLinecap="round"
                    />
                    <line
                        x1="40"
                        y1="40"
                        x2="50"
                        y2="30"
                        className="stroke-accent-light"
                        strokeWidth="3"
                        strokeLinecap="round"
                    />
                </g>

                {/* Box element top */}
                <g transform="translate(190, 60)">
                    <rect
                        x="0"
                        y="0"
                        width="30"
                        height="30"
                        className="fill-accent-light"
                    />
                </g>

                {/* Box element right */}
                <g transform="translate(220, 110)">
                    <rect
                        x="0"
                        y="0"
                        width="30"
                        height="40"
                        className="fill-accent"
                    />
                    <line
                        x1="15"
                        y1="0"
                        x2="15"
                        y2="40"
                        className="stroke-accent-dark"
                        strokeWidth="2"
                    />
                    <line
                        x1="0"
                        y1="20"
                        x2="30"
                        y2="20"
                        className="stroke-accent-dark"
                        strokeWidth="2"
                    />
                </g>

                {/* Bicycle element */}
                <g transform="translate(70, 170)">
                    {/* Bicycle frame */}
                    <path
                        d="M30,0 L45,30 L10,30 Z"
                        className="fill-accent"
                        strokeWidth="4"
                        stroke="#d97706"
                    />

                    {/* Wheels */}
                    <circle
                        cx="10"
                        cy="45"
                        r="15"
                        className="fill-none stroke-accent"
                        strokeWidth="4"
                    />
                    <circle
                        cx="45"
                        cy="45"
                        r="15"
                        className="fill-none stroke-accent"
                        strokeWidth="4"
                    />

                    {/* Handlebars */}
                    <path
                        d="M45,30 C55,25 55,15 45,10"
                        className="fill-none stroke-accent"
                        strokeWidth="4"
                        strokeLinecap="round"
                    />

                    {/* Seat */}
                    <path
                        d="M30,0 C25,0 20,-5 15,-5"
                        className="fill-none stroke-accent"
                        strokeWidth="4"
                        strokeLinecap="round"
                    />
                </g>

                {/* Box element bottom */}
                <g transform="translate(180, 170)">
                    <rect
                        x="0"
                        y="0"
                        width="30"
                        height="30"
                        className="fill-accent-light"
                    />
                </g>
            </g>

            {/* Right "4" */}
            <g transform="translate(570, 60)">
                <path
                    d="M60,0 L60,200 M0,150 L120,150"
                    className="stroke-primary-dark"
                    strokeWidth="40"
                    strokeLinecap="round"
                    fill="none"
                />
            </g>

            {/* Horizontal lines */}
            <line
                x1="60"
                y1="350"
                x2="350"
                y2="350"
                className="stroke-accent-light"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="450"
                y1="350"
                x2="740"
                y2="350"
                className="stroke-accent-light"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="200"
                y1="380"
                x2="320"
                y2="380"
                className="stroke-accent-light"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="480"
                y1="380"
                x2="600"
                y2="380"
                className="stroke-accent-light"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="340"
                y1="380"
                x2="360"
                y2="380"
                className="stroke-accent-light"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="380"
                y1="380"
                x2="390"
                y2="380"
                className="stroke-accent-light"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="400"
                y1="380"
                x2="440"
                y2="380"
                className="stroke-accent-light"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="450"
                y1="380"
                x2="470"
                y2="380"
                className="stroke-accent-light"
                strokeWidth="6"
                strokeLinecap="round"
            />

            {/* Small decorative dots */}
            <circle cx="40" cy="150" r="6" className="fill-accent-light" />
            <circle cx="750" cy="100" r="6" className="fill-accent-light" />
            <circle cx="30" cy="30" r="6" className="fill-accent-light" />
        </svg>
    );
};

export default NotFound404SVG;
