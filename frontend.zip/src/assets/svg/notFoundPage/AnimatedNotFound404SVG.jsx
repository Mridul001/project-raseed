import React, { useEffect } from 'react';

const AnimatedNotFound404SVG = () => {
    // Add animations when component mounts
    useEffect(() => {
        // Rotating animation for clock hands
        const clockHands = document.querySelectorAll('.clock-hand');
        clockHands.forEach((el, index) => {
            const speed = index === 0 ? 8 : 2; // Different speeds for hour and minute hands
            const direction = 1;

            el.animate(
                [
                    { transform: 'rotate(0deg)' },
                    { transform: `rotate(${360 * direction}deg)` }
                ],
                {
                    duration: speed * 1000,
                    iterations: Infinity,
                    easing: 'linear'
                }
            );
        });

        // Bicycle wheel spinning animation
        const bicycleWheels = document.querySelectorAll('.bicycle-wheel');
        bicycleWheels.forEach((el) => {
            el.animate(
                [
                    { transform: 'rotate(0deg)' },
                    { transform: 'rotate(360deg)' }
                ],
                {
                    duration: 4000,
                    iterations: Infinity,
                    easing: 'linear'
                }
            );
        });

        // Floating animation for decorative dots
        const floatingDots = document.querySelectorAll('.floating-dot');
        floatingDots.forEach((el, index) => {
            const duration = 3 + (index % 3);
            const delay = index * 0.5;

            el.animate(
                [
                    { transform: 'translateY(0px)' },
                    { transform: 'translateY(-15px)' },
                    { transform: 'translateY(0px)' }
                ],
                {
                    duration: duration * 1000,
                    iterations: Infinity,
                    easing: 'ease-in-out',
                    delay: delay * 1000
                }
            );
        });

        // Pulse animation for circular elements
        const pulsingElements = document.querySelectorAll('.pulsing');
        pulsingElements.forEach((el, index) => {
            const delay = index * 0.3;

            el.animate(
                [
                    { opacity: 0.5, transform: 'scale(0.95)' },
                    { opacity: 1, transform: 'scale(1.05)' },
                    { opacity: 0.5, transform: 'scale(0.95)' }
                ],
                {
                    duration: 2500,
                    iterations: Infinity,
                    easing: 'ease-in-out',
                    delay: delay * 1000
                }
            );
        });

        // Bouncing animation for bicycle
        const bicycle = document.querySelector('.bicycle');
        if (bicycle) {
            bicycle.animate(
                [
                    { transform: 'translateY(0px)' },
                    { transform: 'translateY(-8px)' },
                    { transform: 'translateY(0px)' }
                ],
                {
                    duration: 1500,
                    iterations: Infinity,
                    easing: 'ease-in-out'
                }
            );
        }

        // Dash animation for lines
        const dashLines = document.querySelectorAll('.animated-line');
        dashLines.forEach((el, index) => {
            // Get the total length of the line
            const length = el.getTotalLength ? el.getTotalLength() : 300;

            // Set initial dash properties
            el.style.strokeDasharray = length;
            el.style.strokeDashoffset = length;

            // Animate the dash offset
            el.animate(
                [
                    { strokeDashoffset: length },
                    { strokeDashoffset: 0 }
                ],
                {
                    duration: 2000,
                    iterations: Infinity,
                    easing: 'ease-in-out',
                    delay: index * 300
                }
            );
        });

        // Add a bob animation to the 4s
        const fourDigits = document.querySelectorAll('.four-digit');
        fourDigits.forEach((el) => {
            el.animate(
                [
                    { transform: 'translateY(0px)' },
                    { transform: 'translateY(-10px)' },
                    { transform: 'translateY(0px)' }
                ],
                {
                    duration: 3000,
                    iterations: Infinity,
                    easing: 'ease-in-out'
                }
            );
        });
    }, []);

    return (
        <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 800 400"
            className="w-full max-w-2xl mx-auto"
        >
            {/* Gradient definitions */}
            <defs>
                <linearGradient id="primaryGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="var(--color-primary-light)" />
                    <stop offset="100%" stopColor="var(--color-primary)" />
                </linearGradient>

                <linearGradient id="secondaryGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="var(--color-secondary-light)" />
                    <stop offset="100%" stopColor="var(--color-secondary)" />
                </linearGradient>

                <linearGradient id="accentGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="var(--color-accent-light)" />
                    <stop offset="100%" stopColor="var(--color-accent)" />
                </linearGradient>

                <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
                    <feDropShadow dx="0" dy="5" stdDeviation="5" floodColor="var(--color-primary-dark)" floodOpacity="0.3" />
                </filter>

                <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="5" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
            </defs>

            {/* Background elements */}
            <rect x="0" y="0" width="800" height="400" fill="transparent" />

            {/* Left "4" */}
            <g className="four-digit" transform="translate(70, 60)">
                <path
                    d="M60,0 L60,200 M0,150 L120,150"
                    stroke="var(--color-primary-dark)"
                    strokeWidth="40"
                    strokeLinecap="round"
                    fill="none"
                    filter="url(#shadow)"
                />
            </g>

            {/* Middle "0" - Circular element */}
            <g transform="translate(250, 60)">
                {/* Main circle */}
                <circle
                    cx="150"
                    cy="120"
                    r="120"
                    fill="var(--color-primary)"
                    className="pulsing"
                    filter="url(#shadow)"
                />

                {/* Inner ring */}
                <circle
                    cx="150"
                    cy="120"
                    r="100"
                    fill="var(--color-secondary)"
                    className="pulsing"
                />

                {/* Clock element */}
                <g transform="translate(110, 50)">
                    <circle
                        cx="40"
                        cy="40"
                        r="30"
                        fill="var(--color-accent)"
                    />
                    <circle
                        cx="40"
                        cy="40"
                        r="25"
                        fill="var(--color-primary)"
                    />
                    <line
                        x1="40"
                        y1="40"
                        x2="25"
                        y2="55"
                        className="clock-hand"
                        stroke="var(--color-accent-light)"
                        strokeWidth="3"
                        strokeLinecap="round"
                        transform-origin="40 40"
                    />
                    <line
                        x1="40"
                        y1="40"
                        x2="50"
                        y2="30"
                        className="clock-hand"
                        stroke="var(--color-accent-light)"
                        strokeWidth="3"
                        strokeLinecap="round"
                        transform-origin="40 40"
                    />
                </g>

                {/* Box element top */}
                <g transform="translate(190, 60)">
                    <rect
                        x="0"
                        y="0"
                        width="30"
                        height="30"
                        fill="var(--color-accent-light)"
                        className="pulsing"
                    />
                </g>

                {/* Box element right */}
                <g transform="translate(220, 110)">
                    <rect
                        x="0"
                        y="0"
                        width="30"
                        height="40"
                        fill="var(--color-accent)"
                        className="pulsing"
                    />
                    <line
                        x1="15"
                        y1="0"
                        x2="15"
                        y2="40"
                        stroke="var(--color-accent-dark)"
                        strokeWidth="2"
                    />
                    <line
                        x1="0"
                        y1="20"
                        x2="30"
                        y2="20"
                        stroke="var(--color-accent-dark)"
                        strokeWidth="2"
                    />
                </g>

                {/* Bicycle element */}
                <g className="bicycle" transform="translate(70, 170)">
                    {/* Bicycle frame */}
                    <path
                        d="M30,0 L45,30 L10,30 Z"
                        fill="var(--color-accent)"
                        strokeWidth="4"
                        stroke="var(--color-accent-dark)"
                    />

                    {/* Wheels */}
                    <g className="bicycle-wheel" transform-origin="10 45">
                        <circle
                            cx="10"
                            cy="45"
                            r="15"
                            fill="none"
                            stroke="var(--color-accent)"
                            strokeWidth="4"
                        />
                        <line
                            x1="10"
                            y1="30"
                            x2="10"
                            y2="60"
                            stroke="var(--color-accent-light)"
                            strokeWidth="1"
                        />
                        <line
                            x1="-5"
                            y1="45"
                            x2="25"
                            y2="45"
                            stroke="var(--color-accent-light)"
                            strokeWidth="1"
                        />
                    </g>

                    <g className="bicycle-wheel" transform-origin="45 45">
                        <circle
                            cx="45"
                            cy="45"
                            r="15"
                            fill="none"
                            stroke="var(--color-accent)"
                            strokeWidth="4"
                        />
                        <line
                            x1="45"
                            y1="30"
                            x2="45"
                            y2="60"
                            stroke="var(--color-accent-light)"
                            strokeWidth="1"
                        />
                        <line
                            x1="30"
                            y1="45"
                            x2="60"
                            y2="45"
                            stroke="var(--color-accent-light)"
                            strokeWidth="1"
                        />
                    </g>

                    {/* Handlebars */}
                    <path
                        d="M45,30 C55,25 55,15 45,10"
                        fill="none"
                        stroke="var(--color-accent)"
                        strokeWidth="4"
                        strokeLinecap="round"
                    />

                    {/* Seat */}
                    <path
                        d="M30,0 C25,0 20,-5 15,-5"
                        fill="none"
                        stroke="var(--color-accent)"
                        strokeWidth="4"
                        strokeLinecap="round"
                    />
                </g>

                {/* Box element bottom */}
                <g transform="translate(180, 170)">
                    <rect
                        x="0"
                        y="0"
                        width="30"
                        height="30"
                        fill="var(--color-accent-light)"
                        className="pulsing"
                    />
                </g>
            </g>

            {/* Right "4" */}
            <g className="four-digit" transform="translate(570, 60)">
                <path
                    d="M60,0 L60,200 M0,150 L120,150"
                    stroke="var(--color-primary-dark)"
                    strokeWidth="40"
                    strokeLinecap="round"
                    fill="none"
                    filter="url(#shadow)"
                />
            </g>

            {/* Horizontal lines */}
            <line
                x1="60"
                y1="350"
                x2="350"
                y2="350"
                className="animated-line"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="450"
                y1="350"
                x2="740"
                y2="350"
                className="animated-line"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="200"
                y1="380"
                x2="320"
                y2="380"
                className="animated-line"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="480"
                y1="380"
                x2="600"
                y2="380"
                className="animated-line"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="340"
                y1="380"
                x2="360"
                y2="380"
                className="animated-line"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="380"
                y1="380"
                x2="390"
                y2="380"
                className="animated-line"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="400"
                y1="380"
                x2="440"
                y2="380"
                className="animated-line"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            />
            <line
                x1="450"
                y1="380"
                x2="470"
                y2="380"
                className="animated-line"
                stroke="var(--color-accent-light)"
                strokeWidth="6"
                strokeLinecap="round"
            />

            {/* Small decorative dots */}
            <circle cx="40" cy="150" r="6" fill="var(--color-accent-light)" className="floating-dot" />
            <circle cx="750" cy="100" r="6" fill="var(--color-accent-light)" className="floating-dot" />
            <circle cx="30" cy="30" r="6" fill="var(--color-accent-light)" className="floating-dot" />
            <circle cx="760" cy="280" r="6" fill="var(--color-primary-light)" className="floating-dot" />
            <circle cx="650" cy="50" r="6" fill="var(--color-secondary-light)" className="floating-dot" />
        </svg>
    );
};

export default AnimatedNotFound404SVG;
