'use client';

import { useState, useEffect } from 'react';
import { ThemeContext } from '../context/ThemeContext';

import lightTheme from '../themes/light.js'
import darkTheme from '../themes/dark.js'
import burgundyTheme from "../themes/burgundy.js";

// Define theme configurations
const themeDefinitions = {
    light: lightTheme,
    dark: darkTheme,
    // A more burgundy-forward theme option
    burgundy: burgundyTheme
};

// Get default theme
const getDefaultTheme = () => 'dark';

export const ThemeProvider = ({ children }) => {
    // Get the themes object
    const themes = themeDefinitions;

    // Get initial theme from localStorage or system preference
    const getInitialTheme = () => {
        if (typeof window !== 'undefined' && window.localStorage) {
            const storedTheme = window.localStorage.getItem('theme');
            if (storedTheme && themes[storedTheme]) {
                return storedTheme;
            }

            if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                return 'dark';
            }
        }
        return getDefaultTheme();
    };

    const [currentTheme, setCurrentTheme] = useState(getInitialTheme);

    // Toggle between light and dark themes
    const toggleTheme = () => {
        setCurrentTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
    };

    // Apply theme changes
    useEffect(() => {
        if (typeof window === 'undefined') return;

        const theme = themes[currentTheme];
        if (!theme) return;

        const root = document.documentElement;

        // Apply all theme properties as CSS variables

        // Apply colors
        if (theme.colors) {
            Object.entries(theme.colors).forEach(([key, value]) => {
                if (typeof value === 'object' && value !== null) {
                    // Handle nested color objects (like glass, chat, camera, etc.)
                    Object.entries(value).forEach(([nestedKey, nestedValue]) => {
                        root.style.setProperty(`--color-${key}-${nestedKey}`, nestedValue);
                    });
                } else {
                    root.style.setProperty(`--color-${key}`, value);
                }
            });

            // Special case for background and foreground for compatibility
            root.style.setProperty('--background', theme.colors.background);
            root.style.setProperty('--foreground', theme.colors.foreground);
        }

        // Apply glass effects
        if (theme.glass) {
            // Apply glass blur values
            if (theme.glass.blur) {
                Object.entries(theme.glass.blur).forEach(([key, value]) => {
                    root.style.setProperty(`--glass-blur-${key}`, value);
                });
            }

            // Apply glass backdrop filters
            if (theme.glass.backdrop) {
                Object.entries(theme.glass.backdrop).forEach(([key, value]) => {
                    root.style.setProperty(`--glass-${key}`, value);
                });
            }
        }

        // Apply fonts
        if (theme.fonts) {
            Object.entries(theme.fonts).forEach(([key, value]) => {
                root.style.setProperty(`--font-${key}`, value);
            });
        }

        // Apply font sizes
        if (theme.fontSizes) {
            Object.entries(theme.fontSizes).forEach(([key, value]) => {
                root.style.setProperty(`--font-size-${key}`, value);
            });
        }

        // Apply font weights
        if (theme.fontWeights) {
            Object.entries(theme.fontWeights).forEach(([key, value]) => {
                root.style.setProperty(`--font-weight-${key}`, value);
            });
        }

        // Apply line heights
        if (theme.lineHeights) {
            Object.entries(theme.lineHeights).forEach(([key, value]) => {
                root.style.setProperty(`--line-height-${key}`, value);
            });
        }

        // Apply letter spacing
        if (theme.letterSpacings) {
            Object.entries(theme.letterSpacings).forEach(([key, value]) => {
                root.style.setProperty(`--letter-spacing-${key}`, value);
            });
        }

        // Apply border radius
        if (theme.borderRadius) {
            Object.entries(theme.borderRadius).forEach(([key, value]) => {
                root.style.setProperty(`--radius-${key}`, value);
            });
        }

        // Apply border widths
        if (theme.borderWidths) {
            Object.entries(theme.borderWidths).forEach(([key, value]) => {
                root.style.setProperty(`--border-width-${key}`, value);
            });
        }

        // Apply spacing
        if (theme.spacing) {
            Object.entries(theme.spacing).forEach(([key, value]) => {
                root.style.setProperty(`--spacing-${key}`, value);
            });
        }

        // Apply shadows
        if (theme.shadows) {
            Object.entries(theme.shadows).forEach(([key, value]) => {
                root.style.setProperty(`--shadow-${key}`, value);
            });
        }

        // Apply transitions
        if (theme.transitions) {
            Object.entries(theme.transitions).forEach(([key, value]) => {
                root.style.setProperty(`--transition-${key}`, value);
            });
        }

        // Apply z-indices
        if (theme.zIndices) {
            Object.entries(theme.zIndices).forEach(([key, value]) => {
                root.style.setProperty(`--z-${key}`, value);
            });
        }

        // Apply opacity values
        if (theme.opacity) {
            Object.entries(theme.opacity).forEach(([key, value]) => {
                root.style.setProperty(`--opacity-${key}`, value);
            });
        }

        // Apply blur values
        if (theme.blurs) {
            Object.entries(theme.blurs).forEach(([key, value]) => {
                root.style.setProperty(`--blur-${key}`, value);
            });
        }

        // Apply gradient values
        if (theme.gradients) {
            Object.entries(theme.gradients).forEach(([key, value]) => {
                root.style.setProperty(`--gradient-${key}`, value);
            });
        }

        // Apply animation values
        if (theme.animations) {
            // Handle nested animation objects
            Object.entries(theme.animations).forEach(([key, value]) => {
                if (typeof value === 'object' && value !== null) {
                    // Handle nested animation objects (like duration, ease, etc.)
                    Object.entries(value).forEach(([nestedKey, nestedValue]) => {
                        root.style.setProperty(`--animation-${key}-${nestedKey}`, nestedValue);
                    });
                } else {
                    root.style.setProperty(`--animation-${key}`, value);
                }
            });
        }

        // Toggle dark class on the html element for compatibility with existing dark mode classes
        if (currentTheme === 'dark') {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }

        // Save to localStorage
        localStorage.setItem('theme', currentTheme);
    }, [currentTheme, themes]);

    // Function to change the theme
    const setTheme = (themeName) => {
        if (themes[themeName]) {
            setCurrentTheme(themeName);
        }
    };

    return (
        <ThemeContext.Provider
            value={{
                theme: themes[currentTheme],
                themeName: currentTheme,
                setTheme,
                toggleTheme,
                themes
            }}
        >
            {children}
        </ThemeContext.Provider>
    );
};
