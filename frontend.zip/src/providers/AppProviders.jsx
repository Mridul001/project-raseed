import { ThemeProvider } from './ThemeProvider';
// Import other providers as needed

export const AppProviders = ({ children }) => {
  return (
    <ThemeProvider>
      {/* Wrap with other providers as needed */}
      {children}
    </ThemeProvider>
  );
};
