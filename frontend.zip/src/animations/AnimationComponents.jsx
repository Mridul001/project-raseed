import React, { useRef, useEffect, forwardRef } from 'react';
import { useAnimation } from './hooks/useAnimation';
import { pageEnter, pageExit, staggerElements } from './pageTransitions';
import {
    fadeInOnScroll,
    parallaxOnScroll,
    revealOnScroll,
    batchScrollAnimations
} from './scrollAnimations';
import { useAnimationContext } from './AnimationProvider';

/**
 * Animated component that applies page transitions
 */
export const AnimatedPage = forwardRef(({
                                            children,
                                            animation = 'fade',
                                            direction = 'bottom',
                                            staggerChildren = false,
                                            childrenSelector = '.anim-child',
                                            duration = 1,
                                            delay = 0,
                                            ...props
                                        }, ref) => {
    const { container } = useAnimation((gsap, element) => {
        const options = {
            type: animation,
            from: direction,
            duration,
            delay,
        };

        pageEnter(element, options);

        if (staggerChildren && element.querySelectorAll(childrenSelector).length > 0) {
            staggerElements(element.querySelectorAll(childrenSelector), {
                delay: delay + duration * 0.5,
                from: direction === 'left' || direction === 'right' ? direction : 'start',
            });
        }
    });

    // Forward the ref while maintaining our container ref
    useEffect(() => {
        if (ref) {
            if (typeof ref === 'function') {
                ref(container.current);
            } else {
                ref.current = container.current;
            }
        }
    }, [ref, container.current]);

    return (
        <div ref={container} {...props}>
            {children}
        </div>
    );
});

/**
 * Component that animates on scroll
 */
export const ScrollReveal = forwardRef(({
                                            children,
                                            animation = 'fade',
                                            threshold = '80%',
                                            direction = 'bottom',
                                            staggerChildren = false,
                                            childrenSelector = '.anim-child',
                                            duration = 0.8,
                                            once = false,
                                            ...props
                                        }, ref) => {
    const { container } = useAnimation((gsap, element) => {
        const options = {
            start: `top ${threshold}`,
            type: animation,
            from: direction,
            duration,
            once,
        };

        if (staggerChildren && element.querySelectorAll(childrenSelector).length > 0) {
            revealOnScroll(
                gsap.utils.toArray(element.querySelectorAll(childrenSelector)),
                {
                    ...options,
                    trigger: element,
                }
            );
        } else {
            fadeInOnScroll(element, options);
        }
    });

    // Forward the ref while maintaining our container ref
    useEffect(() => {
        if (ref) {
            if (typeof ref === 'function') {
                ref(container.current);
            } else {
                ref.current = container.current;
            }
        }
    }, [ref, container.current]);

    return (
        <div ref={container} {...props}>
            {children}
        </div>
    );
});

/**
 * Component for parallax effect
 */
export const Parallax = forwardRef(({
                                        children,
                                        speed = 0.3,
                                        direction = 'y',
                                        ...props
                                    }, ref) => {
    const { container } = useAnimation((gsap, element) => {
        parallaxOnScroll(element, {
            speed,
            direction,
        });
    });

    // Forward the ref while maintaining our container ref
    useEffect(() => {
        if (ref) {
            if (typeof ref === 'function') {
                ref(container.current);
            } else {
                ref.current = container.current;
            }
        }
    }, [ref, container.current]);

    return (
        <div ref={container} {...props}>
            {children}
        </div>
    );
});

/**
 * Component for batched animations
 */
export const BatchReveal = ({
                                selector,
                                container: containerSelector = 'body',
                                animation = 'fade',
                                direction = 'bottom',
                                interval = 0.1,
                                batchMax = 3,
                                threshold = '85%',
                                once = false,
                                duration = 0.8,
                                stagger = 0.05
                            }) => {
    const { isEnabled } = useAnimationContext();

    useEffect(() => {
        if (!isEnabled) return;

        const elements = document.querySelectorAll(selector);
        if (elements.length === 0) return;

        batchScrollAnimations(elements, {
            interval,
            batchMax,
            start: `top ${threshold}`,
            once,
            type: animation,
            from: direction,
            duration,
            stagger,
        });
    }, [selector, isEnabled, animation, direction, interval, batchMax, threshold, once, duration, stagger]);

    return null; // This component doesn't render anything
};

/**
 * Higher-order component for page transitions
 */
export const withPageAnimation = (Component, options = {}) => {
    const WithPageAnimation = forwardRef((props, ref) => {
        return (
            <AnimatedPage
                animation={options.animation || 'fade'}
                direction={options.direction || 'bottom'}
                duration={options.duration || 1}
                delay={options.delay || 0}
                staggerChildren={options.staggerChildren || false}
                childrenSelector={options.childrenSelector || '.anim-child'}
                ref={ref}
                style={{ width: '100%', height: '100%' }}
            >
                <Component {...props} />
            </AnimatedPage>
        );
    });

    WithPageAnimation.displayName = `WithPageAnimation(${Component.displayName || Component.name || 'Component'})`;
    return WithPageAnimation;
};

/**
 * Higher-order component for scroll animations
 */
export const withScrollAnimation = (Component, options = {}) => {
    const WithScrollAnimation = forwardRef((props, ref) => {
        return (
            <ScrollReveal
                animation={options.animation || 'fade'}
                direction={options.direction || 'bottom'}
                threshold={options.threshold || '80%'}
                duration={options.duration || 0.8}
                once={options.once || false}
                staggerChildren={options.staggerChildren || false}
                childrenSelector={options.childrenSelector || '.anim-child'}
                ref={ref}
                style={{ width: '100%', height: '100%' }}
            >
                <Component {...props} />
            </ScrollReveal>
        );
    });

    WithScrollAnimation.displayName = `WithScrollAnimation(${Component.displayName || Component.name || 'Component'})`;
    return WithScrollAnimation;
};
