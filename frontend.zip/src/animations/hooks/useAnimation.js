import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { useGSAP } from '@gsap/react';

/**
 * Enhanced animation hook that provides more flexibility and options
 *
 * @param {Function} animationSetup - Function that sets up animations
 * @param {Object} options - Configuration options
 * @param {Array} options.dependencies - Array of dependencies for useGSAP
 * @param {boolean} options.createTimeline - Whether to create and pass a timeline
 * @param {Object} options.timelineOptions - Options for the GSAP timeline
 * @param {Object} options.scope - Additional elements to include in the scope
 * @returns {Object} - Container ref and controls for the animation
 */
export const useAnimation = (
    animationSetup,
    {
        dependencies = [],
        createTimeline = false,
        timelineOptions = {},
        scope = null,
    } = {}
) => {
    const container = useRef();
    const animation = useRef(null);

    useGSAP(() => {
        const ctx = gsap.context(() => {
            if (createTimeline) {
                const tl = gsap.timeline(timelineOptions);
                animation.current = tl;
                animationSetup(gsap, container.current, tl);
            } else {
                animation.current = animationSetup(gsap, container.current);
            }
        }, scope || container);

        return () => ctx.revert();
    }, { dependencies, scope });

    // Controls for the animation
    const controls = {
        play: () => animation.current?.play(),
        pause: () => animation.current?.pause(),
        reverse: () => animation.current?.reverse(),
        restart: () => animation.current?.restart(),
        progress: (value) => {
            if (value !== undefined) {
                animation.current?.progress(value);
                return;
            }
            return animation.current?.progress();
        },
        timeScale: (value) => {
            if (value !== undefined) {
                animation.current?.timeScale(value);
                return;
            }
            return animation.current?.timeScale();
        }
    };

    return { container, controls };
};

/**
 * Hook for creating sequences of animations
 */
export const useSequence = (sequenceSetup, options = {}) => {
    return useAnimation(
        (gsap, container, tl) => sequenceSetup(gsap, container, tl),
        { ...options, createTimeline: true }
    );
};
