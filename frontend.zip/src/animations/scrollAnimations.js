import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Register ScrollTrigger plugin once
gsap.registerPlugin(ScrollTrigger);

/**
 * Enhanced fade in on scroll with more options
 */
export const fadeInOnScroll = (element, options = {}) => {
    const {
        y = 50,
        x = 0,
        opacity = 0,
        scale = 1,
        duration = 1,
        ease = 'power2.out',
        start = 'top 80%',
        end = 'bottom 20%',
        toggleActions = 'play none none reverse',
        markers = false,
        scrub = false,
        once = false,
        stagger = 0,
    } = options;

    return gsap.from(element, {
        scrollTrigger: {
            trigger: options.trigger || element,
            start,
            end,
            toggleActions,
            markers,
            scrub,
            once,
        },
        opacity,
        y,
        x,
        scale,
        duration,
        ease,
        stagger: stagger && {
            amount: stagger,
            from: options.from || "start",
        },
    });
};

/**
 * Parallax effect on scroll
 */
export const parallaxOnScroll = (element, options = {}) => {
    const {
        speed = 0.5,
        direction = 'y', // 'x' or 'y'
        start = 'top bottom',
        end = 'bottom top',
        scrub = true,
        markers = false,
    } = options;

    const props = direction === 'x'
        ? { x: `${speed * 100}%` }
        : { y: `${speed * 100}%` };

    return gsap.fromTo(
        element,
        { ...props },
        {
            ...props,
            ease: 'none',
            scrollTrigger: {
                trigger: options.trigger || element,
                start,
                end,
                scrub,
                markers,
            },
        }
    );
};

/**
 * Reveal elements on scroll with a stagger effect
 */
export const revealOnScroll = (elements, options = {}) => {
    const {
        stagger = 0.1,
        duration = 0.8,
        ease = 'power2.out',
        y = 50,
        x = 0,
        start = 'top 80%',
        toggleActions = 'play none none reverse',
        markers = false,
        clipPath = true, // Use clip-path for reveal effect
    } = options;

    const tl = gsap.timeline({
        scrollTrigger: {
            trigger: options.trigger || elements[0],
            start,
            toggleActions,
            markers,
        },
    });

    if (clipPath) {
        tl.from(elements, {
            clipPath: 'inset(100% 0 0 0)',
            y,
            x,
            opacity: 0,
            duration,
            stagger,
            ease,
        });
    } else {
        tl.from(elements, {
            y,
            x,
            opacity: 0,
            duration,
            stagger,
            ease,
        });
    }

    return tl;
};

/**
 * Pin an element and animate its children based on scroll progress
 */
export const pinAndAnimateOnScroll = (container, options = {}) => {
    const {
        duration = 1,
        pinSpacing = true,
        start = 'top top',
        end = 'bottom top',
        markers = false,
        scrub = true,
        animations = [],
    } = options;

    const tl = gsap.timeline({
        scrollTrigger: {
            trigger: container,
            start,
            end,
            pin: true,
            pinSpacing,
            scrub,
            markers,
        },
    });

    animations.forEach(anim => {
        tl.to(anim.target, {
            ...anim.props,
            duration: anim.duration || duration,
            ease: anim.ease || 'none',
        }, anim.position || '+=0');
    });

    return tl;
};

/**
 * Batch animations for multiple elements with the same effect
 */
export const batchScrollAnimations = (elements, options = {}) => {
    const {
        interval = 0.1,
        batchMax = 3,
        start = 'top 85%',
        once = false,
        type = 'fade', // 'fade', 'slide', 'zoom', 'flip'
        from = 'bottom',
        y = 40,
        x = 0,
        duration = 0.8,
        stagger = 0.05,
    } = options;

    ScrollTrigger.batch(elements, {
        interval,
        batchMax,
        onEnter: (batch) => {
            switch (type) {
                case 'slide':
                    gsap.from(batch, {
                        x: from === 'left' ? -50 : from === 'right' ? 50 : 0,
                        y: from === 'top' ? -50 : from === 'bottom' ? 50 : 0,
                        opacity: 0,
                        duration,
                        stagger,
                    });
                    break;
                case 'zoom':
                    gsap.from(batch, {
                        scale: 0.8,
                        opacity: 0,
                        duration,
                        stagger,
                    });
                    break;
                case 'flip':
                    gsap.from(batch, {
                        rotationX: from === 'top' || from === 'bottom' ? 90 * (from === 'top' ? -1 : 1) : 0,
                        rotationY: from === 'left' || from === 'right' ? 90 * (from === 'left' ? -1 : 1) : 0,
                        opacity: 0,
                        transformPerspective: 600,
                        duration,
                        stagger,
                    });
                    break;
                case 'fade':
                default:
                    gsap.from(batch, {
                        opacity: 0,
                        y,
                        x,
                        duration,
                        stagger,
                    });
            }
        },
        onLeave: once ? null : (batch) => {
            gsap.to(batch, {
                opacity: 0,
                y: y / 2,
                duration: duration / 2,
                stagger: stagger / 2,
            });
        },
        onEnterBack: once ? null : (batch) => {
            gsap.to(batch, {
                opacity: 1,
                y: 0,
                duration: duration / 2,
                stagger: stagger / 2,
            });
        },
        onLeaveBack: once ? null : (batch) => {
            gsap.to(batch, {
                opacity: 0,
                y: -y / 2,
                duration: duration / 2,
                stagger: stagger / 2,
            });
        },
        start,
    });
};
