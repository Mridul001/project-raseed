import React, { createContext, useContext, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ScrollToPlugin } from 'gsap/ScrollToPlugin';

// Register all required plugins
gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

// Create animation context
const AnimationContext = createContext();

export const AnimationProvider = ({ children, config = {} }) => {
    const [animationEnabled, setAnimationEnabled] = useState(
        config.enabled !== undefined ? config.enabled : true
    );

    // Global GSAP settings
    useEffect(() => {
        // Set global defaults
        gsap.defaults({
            ease: config.defaultEase || 'power2.out',
            duration: config.defaultDuration || 0.8,
        });

        // Configure ScrollTrigger defaults
        ScrollTrigger.defaults({
            toggleActions: config.defaultToggleActions || 'play none none reverse',
            markers: config.showMarkers || false,
        });

        // Cleanup on unmount
        return () => {
            ScrollTrigger.getAll().forEach(trigger => trigger.kill());
        };
    }, []);

    // Handle disabling animations (for reduced motion preference)
    useEffect(() => {
        if (config.respectReducedMotion !== false) {
            const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');

            const handleReducedMotionChange = () => {
                setAnimationEnabled(!mediaQuery.matches);

                if (mediaQuery.matches) {
                    // Kill all animations if reduced motion is preferred
                    ScrollTrigger.getAll().forEach(trigger => trigger.kill());
                    gsap.globalTimeline.clear();
                }
            };

            handleReducedMotionChange();
            mediaQuery.addEventListener('change', handleReducedMotionChange);

            return () => {
                mediaQuery.removeEventListener('change', handleReducedMotionChange);
            };
        }
    }, [config.respectReducedMotion]);

    // Animation utilities
    const animationUtils = {
        isEnabled: animationEnabled,
        setEnabled: setAnimationEnabled,

        // Utility to scroll to an element with animation
        scrollTo: (target, options = {}) => {
            if (!animationEnabled) {
                window.scrollTo({
                    top: typeof target === 'string'
                        ? document.querySelector(target)?.offsetTop || 0
                        : target.offsetTop || 0,
                    behavior: 'auto'
                });
                return;
            }

            gsap.to(window, {
                duration: options.duration || 1,
                scrollTo: {
                    y: target,
                    offsetY: options.offset || 0,
                },
                ease: options.ease || 'power2.inOut',
            });
        },

        // Get GSAP instance for advanced usage
        gsap,
        ScrollTrigger,
    };

    return (
        <AnimationContext.Provider value={animationUtils}>
            {children}
        </AnimationContext.Provider>
    );
};

// Custom hooks to use animations
export const useAnimationContext = () => {
    const context = useContext(AnimationContext);
    if (!context) {
        throw new Error('useAnimationContext must be used within an AnimationProvider');
    }
    return context;
};

// Higher-order component for page transitions
export const withPageTransition = (Component, transitionOptions = {}) => {
    return function WithPageTransition(props) {
        const { container, controls } = useAnimationContext();

        return (
            <Component
                {...props}
                ref={container}
                animationControls={controls}
                transitionOptions={transitionOptions}
            />
        );
    };
};
