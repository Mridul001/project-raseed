import { gsap } from 'gsap';

/**
 * Enhanced page enter transitions
 */
export const pageEnter = (container, options = {}) => {
    const {
        duration = 1,
        ease = 'power2.out',
        stagger = 0.1,
        y = 50,
        delay = 0,
        type = 'fade', // 'fade', 'slide', 'zoom', 'flip'
        from = 'bottom', // 'bottom', 'top', 'left', 'right'
    } = options;

    // Select all direct children if container is a parent element
    const elements = container.children?.length > 0
        ? gsap.utils.toArray(container.children)
        : container;

    const commonProps = {
        duration,
        ease,
        delay,
        stagger: elements.length > 1 ? stagger : 0,
    };

    switch (type) {
        case 'slide':
            return gsap.from(elements, {
                ...commonProps,
                x: from === 'left' ? -100 : from === 'right' ? 100 : 0,
                y: from === 'top' ? -100 : from === 'bottom' ? 100 : 0,
                opacity: 0,
            });

        case 'zoom':
            return gsap.from(elements, {
                ...commonProps,
                scale: 0.5,
                opacity: 0,
            });

        case 'flip':
            return gsap.from(elements, {
                ...commonProps,
                rotationX: from === 'top' || from === 'bottom' ? 90 * (from === 'top' ? -1 : 1) : 0,
                rotationY: from === 'left' || from === 'right' ? 90 * (from === 'left' ? -1 : 1) : 0,
                opacity: 0,
                transformPerspective: 600,
            });

        case 'fade':
        default:
            return gsap.from(elements, {
                ...commonProps,
                opacity: 0,
                y: y,
            });
    }
};

/**
 * Enhanced page exit transitions
 */
export const pageExit = (container, options = {}) => {
    const {
        duration = 0.5,
        ease = 'power2.in',
        stagger = 0.05,
        y = -50,
        delay = 0,
        type = 'fade', // 'fade', 'slide', 'zoom', 'flip'
        to = 'top', // 'bottom', 'top', 'left', 'right'
        onComplete,
    } = options;

    // Select all direct children if container is a parent element
    const elements = container.children?.length > 0
        ? gsap.utils.toArray(container.children)
        : container;

    const commonProps = {
        duration,
        ease,
        delay,
        stagger: elements.length > 1 ? stagger : 0,
        onComplete,
    };

    switch (type) {
        case 'slide':
            return gsap.to(elements, {
                ...commonProps,
                x: to === 'left' ? -100 : to === 'right' ? 100 : 0,
                y: to === 'top' ? -100 : to === 'bottom' ? 100 : 0,
                opacity: 0,
            });

        case 'zoom':
            return gsap.to(elements, {
                ...commonProps,
                scale: 0.5,
                opacity: 0,
            });

        case 'flip':
            return gsap.to(elements, {
                ...commonProps,
                rotationX: to === 'top' || to === 'bottom' ? 90 * (to === 'top' ? -1 : 1) : 0,
                rotationY: to === 'left' || to === 'right' ? 90 * (to === 'left' ? -1 : 1) : 0,
                opacity: 0,
                transformPerspective: 600,
            });

        case 'fade':
        default:
            return gsap.to(elements, {
                ...commonProps,
                opacity: 0,
                y: y,
            });
    }
};

/**
 * Handles both entry and exit transitions as a sequence
 */
export const pageTransition = (container, options = {}) => {
    const tl = gsap.timeline(options);
    tl.add(pageEnter(container, options.enter || {}));

    if (options.exitOnComplete) {
        tl.add(pageExit(container, options.exit || {}));
    }

    return tl;
};

/**
 * Staggered entrance for a group of elements
 */
export const staggerElements = (elements, options = {}) => {
    const {
        duration = 0.5,
        stagger = 0.1,
        from = 'start', // 'start', 'end', 'center', 'edges', 'random'
        ease = 'power1.out',
        y = 20,
        x = 0,
        opacity = 0,
        scale = 1,
        delay = 0
    } = options;

    return gsap.from(elements, {
        duration,
        y,
        x,
        opacity,
        scale,
        stagger: {
            amount: elements.length * stagger,
            from,
        },
        ease,
        delay,
    });
};
