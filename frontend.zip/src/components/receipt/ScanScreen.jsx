import React, { useState, useRef, useEffect } from 'react';
import { FlipHorizontal, Zap, ZapOff, Image, History } from 'lucide-react';
import { initializeCamera, cleanupCamera, captureImageFromVideo, isCameraSupported } from '@/utils/receipt/cameraUtils.js';
import { saveReceiptToStorage, saveReceiptBatchToStorage } from '@/utils/receipt/receiptStorage.js';
import receiptService from '@/services/receiptService';
import Toast from '@/components/common/Toast/Toast';
import ReceiptPreview from './ReceiptPreview.jsx';

const ScanScreen = ({
                        onUploadSuccess,
                        onNavigateHome,
                        onShowHistory
                    }) => {
    const [mode, setMode] = useState('camera');
    const [stream, setStream] = useState(null);
    const [capturedImages, setCapturedImages] = useState([]);
    const [capturedFiles, setCapturedFiles] = useState([]);
    const [flashEnabled, setFlashEnabled] = useState(false);
    const [facingMode, setFacingMode] = useState('environment');
    const [error, setError] = useState('');
    const [isUploading, setIsUploading] = useState(false);
    const [toast, setToast] = useState(null);
    const [uploadResponse, setUploadResponse] = useState(null);

    const videoRef = useRef(null);
    const canvasRef = useRef(null);
    const fileInputRef = useRef(null);

    // Listen for bottom nav scan button clicks
    useEffect(() => {
        const handleScanButtonClick = (event) => {
            if (event.detail === 'scan' && mode === 'camera') {
                handleCapture();
            }
        };

        window.addEventListener('bottomNavClick', handleScanButtonClick);
        return () => {
            window.removeEventListener('bottomNavClick', handleScanButtonClick);
        };
    }, [mode]);

    // Toast functions
    const showToast = (message, type = 'info', title = null) => {
        setToast({ message, type, title });
    };

    const hideToast = () => {
        setToast(null);
    };

    // Initialize camera
    const setupCamera = async () => {
        try {
            setError('');

            if (!isCameraSupported()) {
                throw new Error('Camera is not supported on this device');
            }

            if (stream) {
                cleanupCamera(stream);
            }

            const newStream = await initializeCamera({
                facingMode,
                flashEnabled
            });

            setStream(newStream);

            if (videoRef.current) {
                videoRef.current.srcObject = newStream;
            }
        } catch (err) {
            setError(err.message);
            showToast(err.message, 'error', 'Camera Error');
            console.error('Camera error:', err);
        }
    };

    // Capture image from camera
    const handleCapture = async () => {
        if (!videoRef.current || !canvasRef.current) return;

        try {
            const file = await captureImageFromVideo(videoRef.current, canvasRef.current);
            const imageUrl = URL.createObjectURL(file);

            // Add to arrays
            setCapturedImages(prev => [...prev, imageUrl]);
            setCapturedFiles(prev => [...prev, file]);

            // Go to preview mode
            setMode('preview');
            cleanupCamera(stream);
            setStream(null);

            showToast('Image captured successfully!', 'success');
        } catch (err) {
            const errorMessage = 'Failed to capture image';
            setError(errorMessage);
            console.error('Capture error:', err);
            showToast(errorMessage, 'error', 'Capture Error');
        }
    };

    // Handle gallery selection
    const handleGallerySelect = (event) => {
        const files = Array.from(event.target.files);

        files.forEach(file => {
            if (file && file.type.startsWith('image/')) {
                const imageUrl = URL.createObjectURL(file);
                setCapturedImages(prev => [...prev, imageUrl]);
                setCapturedFiles(prev => [...prev, file]);
            }
        });

        if (files.length > 0) {
            setMode('preview');
            cleanupCamera(stream);
            setStream(null);
            showToast(`${files.length} image(s) added successfully!`, 'success');
        }

        // Reset file input
        event.target.value = '';
    };

    // Remove image from collection
    const handleRemoveImage = (index) => {
        const imageToRemove = capturedImages[index];
        if (imageToRemove) {
            URL.revokeObjectURL(imageToRemove);
        }

        setCapturedImages(prev => prev.filter((_, i) => i !== index));
        setCapturedFiles(prev => prev.filter((_, i) => i !== index));

        // If no images left, go back to camera
        if (capturedImages.length === 1) {
            setMode('camera');
            setError('');
            hideToast();
        }
    };

    // Add more images (go back to camera)
    const handleAddMore = () => {
        setUploadResponse(null);
        setMode('camera');
        setError('');
        hideToast();
    };

    // Retry capture (clear all and start over)
    const handleRetry = () => {
        // Clean up URLs
        capturedImages.forEach(url => URL.revokeObjectURL(url));
        setCapturedImages([]);
        setCapturedFiles([]);
        setUploadResponse(null);
        setMode('camera');
        setError('');
        hideToast();
    };

    // Enhanced confirm and upload with better error handling
    const handleConfirmUpload = async (notes = '') => {
        if (capturedFiles.length === 0) return;

        try {
            setIsUploading(true);
            setError('');

            showToast('Processing and saving receipts...', 'info', 'Processing');

            // Save to local storage with compression - now properly awaited
            let savedReceipt;
            try {
                if (capturedFiles.length > 1) {
                    savedReceipt = await saveReceiptBatchToStorage(capturedFiles, notes);
                    const compressionInfo = savedReceipt.totalCompressedSize && savedReceipt.totalSize
                        ? ` (${Math.round((1 - savedReceipt.totalCompressedSize / savedReceipt.totalSize) * 100)}% smaller)`
                        : '';
                    showToast(`Batch saved locally with compression${compressionInfo}`, 'success', 'Saved Locally');
                } else {
                    savedReceipt = await saveReceiptToStorage(capturedFiles[0]);
                    const compressionInfo = savedReceipt.compressedSizes && savedReceipt.sizes
                        ? ` (${Math.round((1 - savedReceipt.compressedSizes[0] / savedReceipt.sizes[0]) * 100)}% smaller)`
                        : '';
                    showToast(`Receipt saved locally with compression${compressionInfo}`, 'success', 'Saved Locally');
                }
            } catch (storageError) {
                console.error('Storage error:', storageError);

                // Handle specific storage errors
                if (storageError.message.includes('QuotaExceededError') ||
                    storageError.message.includes('quota') ||
                    storageError.message.includes('storage')) {

                    showToast(
                        'Storage space is full. Images compressed and saved with reduced quality. Consider clearing old receipts.',
                        'warning',
                        'Storage Warning'
                    );
                } else {
                    showToast(
                        'Failed to save locally, but continuing with upload...',
                        'warning',
                        'Storage Warning'
                    );
                }
            }

            // Upload all files to server
            showToast('Uploading to server...', 'info', 'Uploading');

            const uploadPromises = capturedFiles.map(file =>
                receiptService.uploadReceipt(file, notes)
            );

            const responses = await Promise.all(uploadPromises);
            const successfulUploads = responses.filter(response => response.success);

            if (successfulUploads.length > 0) {
                setIsUploading(false);

                // Store the first successful upload response for wallet functionality
                setUploadResponse(successfulUploads[0].data);

                const totalFiles = capturedFiles.length;
                const successCount = successfulUploads.length;
                const failedCount = totalFiles - successCount;

                if (failedCount === 0) {
                    showToast(
                        `${successCount} receipt(s) uploaded successfully!`,
                        'success',
                        'Upload Complete'
                    );
                } else {
                    showToast(
                        `${successCount} of ${totalFiles} receipts uploaded. ${failedCount} failed.`,
                        'warning',
                        'Partial Upload'
                    );
                }

                // Call success callback with all responses
                if (onUploadSuccess) {
                    onUploadSuccess({
                        files: capturedFiles,
                        apiResponses: successfulUploads.map(response => response.data),
                        notes,
                        savedLocally: !!savedReceipt
                    });
                }

                // Don't navigate home - stay on preview to show wallet option
            } else {
                throw new Error('All uploads failed');
            }

        } catch (err) {
            let errorMessage = 'An unexpected error occurred while uploading';

            // Provide more specific error messages
            if (err.message.includes('network') || err.message.includes('fetch')) {
                errorMessage = 'Network error - check your connection and try again';
            } else if (err.message.includes('timeout')) {
                errorMessage = 'Upload timed out - please try again';
            } else if (err.message.includes('server')) {
                errorMessage = 'Server error - please try again later';
            } else if (err.message.includes('quota') || err.message.includes('storage')) {
                errorMessage = 'Storage quota exceeded - consider clearing old receipts';
            }

            setError(errorMessage);
            console.error('Upload error:', err);
            showToast(errorMessage, 'error', 'Upload Error');
            setIsUploading(false);
        }
    };

    // Switch camera
    const handleCameraSwitch = () => {
        setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
    };

    // Toggle flash
    const handleFlashToggle = () => {
        setFlashEnabled(prev => !prev);
    };

    // Setup camera when mode changes
    useEffect(() => {
        if (mode === 'camera') {
            setupCamera();
        }
        return () => {
            if (stream) {
                cleanupCamera(stream);
            }
        };
    }, [mode, facingMode, flashEnabled]);

    // Cleanup on unmount
    useEffect(() => {
        return () => {
            if (stream) {
                cleanupCamera(stream);
            }
            capturedImages.forEach(url => URL.revokeObjectURL(url));
        };
    }, []);

    // Show preview mode
    if (mode === 'preview') {
        return (
            <>
                <ReceiptPreview
                    capturedImages={capturedImages}
                    capturedFiles={capturedFiles}
                    onRetry={handleRetry}
                    onAddMore={handleAddMore}
                    onRemoveImage={handleRemoveImage}
                    onConfirm={handleConfirmUpload}
                    isUploading={isUploading}
                    error={error}
                    uploadResponse={uploadResponse}
                />

                {toast && (
                    <Toast
                        message={toast.message}
                        type={toast.type}
                        title={toast.title}
                        onClose={hideToast}
                        duration={toast.type === 'error' ? 5000 : 3000}
                        position="top-right"
                    />
                )}
            </>
        );
    }

    // Main camera view - Full screen camera with overlays
    return (
        <>
            <div
                className="relative bg-camera-overlay overflow-hidden"
                style={{
                    height: 'calc(100vh - 160px)' // Account for header and bottom nav
                }}
            >
                {/* Video Element - Full camera view */}
                <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="absolute inset-0 w-full h-full object-cover"
                />

                {/* Top Right Controls - Overlapping camera */}
                <div className="absolute top-4 right-4 z-50 flex flex-col gap-3">
                    <button
                        onClick={handleFlashToggle}
                        className={`p-3 rounded-xl transition-all duration-200 backdrop-blur-md border border-border shadow-lg ${
                            flashEnabled
                                ? 'bg-primary text-primary-contrast shadow-glow-primary'
                                : 'bg-glass-heavy text-content-inverse hover:bg-glass-primary'
                        }`}
                    >
                        {flashEnabled ? <Zap className="w-5 h-5" /> : <ZapOff className="w-5 h-5" />}
                    </button>
                    <button
                        onClick={handleCameraSwitch}
                        className="p-3 rounded-xl bg-glass-heavy hover:bg-glass-primary text-content-inverse transition-all duration-200 backdrop-blur-md border border-border shadow-lg"
                    >
                        <FlipHorizontal className="w-5 h-5" />
                    </button>
                </div>

                {/* Focus Frame - Simple rounded square in center */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-64 h-64 border-2 border-camera-frame rounded-2xl"></div>
                </div>

                {/* Instructions - Theme compatible glassmorphic */}
                <div className="absolute bottom-24 left-4 right-4 z-40 pointer-events-none">
                    <div className="bg-glass-heavy backdrop-blur-lg border border-border rounded-xl p-3 text-center shadow-lg">
                        <p className="text-sm font-medium text-content-inverse">
                            Position receipt within frame
                        </p>
                        <p className="text-xs text-content-inverse opacity-80 mt-1">
                            Images auto-compressed for efficient storage
                        </p>
                    </div>
                </div>

                {/* Bottom Right Controls - Overlapping camera */}
                <div className="absolute bottom-4 right-4 z-50 flex flex-col gap-3">
                    <button
                        onClick={() => fileInputRef.current?.click()}
                        className="flex items-center justify-center p-3 bg-glass-heavy hover:bg-glass-primary border border-border rounded-xl transition-all duration-200 backdrop-blur-md shadow-lg"
                    >
                        <Image className="w-5 h-5 text-content-inverse" />
                    </button>

                    <button
                        onClick={onShowHistory}
                        className="flex items-center justify-center p-3 bg-glass-heavy hover:bg-glass-primary border border-border rounded-xl transition-all duration-200 backdrop-blur-md shadow-lg"
                    >
                        <History className="w-5 h-5 text-content-inverse" />
                    </button>
                </div>

                {/* Hidden file input */}
                <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleGallerySelect}
                    className="hidden"
                />

                {/* Hidden canvas for capture */}
                <canvas ref={canvasRef} className="hidden" />
            </div>

            {/* Toast notification */}
            {toast && (
                <Toast
                    message={toast.message}
                    type={toast.type}
                    title={toast.title}
                    onClose={hideToast}
                    duration={toast.type === 'error' ? 5000 : 3000}
                    position="top-right"
                />
            )}
        </>
    );
};

export default ScanScreen;
