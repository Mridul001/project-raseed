import React, { useState } from 'react';
import { ArrowLeft, RotateCcw, Upload, Plus, X, Wallet, AlertCircle, CheckCircle } from 'lucide-react';
import receiptService from '@/services/receiptService';

const ReceiptPreview = ({
                            capturedImages = [],
                            capturedFiles = [],
                            onRetry,
                            onAddMore,
                            onRemoveImage,
                            onConfirm,
                            isUploading = false,
                            error = null,
                            uploadResponse = null
                        }) => {
    const [notes, setNotes] = useState('');
    const [isAddingToWallet, setIsAddingToWallet] = useState(false);
    const [showWalletConfirm, setShowWalletConfirm] = useState(false);
    const [currentImageIndex, setCurrentImageIndex] = useState(0);

    // Handle upload with notes
    const handleUpload = async () => {
        try {
            const response = await onConfirm(notes);
            // Response will be handled by parent component
        } catch (error) {
            console.error('Upload failed:', error);
        }
    };

    // Add to Wallet functionality
    const handleAddToWallet = async () => {
        if (!uploadResponse) return;

        try {
            setIsAddingToWallet(true);

            // Prepare data for wallet API
            const walletData = {
                category: uploadResponse.category,
                vendor: uploadResponse.vendor,
                items: uploadResponse.items,
                id: uploadResponse.id
            };

            const response = await receiptService.generatePass(walletData);

            if (response.success) {
                setIsAddingToWallet(false);
                setShowWalletConfirm(true);

                // Store wallet link for redirect
                window.walletRedirectUrl = response.walletLink;
            } else {
                throw new Error(response.error || 'Failed to generate wallet pass');
            }
        } catch (error) {
            console.error('Wallet generation failed:', error);
            setIsAddingToWallet(false);
            // Show error toast or message
        }
    };

    // Confirm wallet redirect
    const handleWalletConfirm = () => {
        if (window.walletRedirectUrl) {
            window.open(window.walletRedirectUrl, '_blank');
            setShowWalletConfirm(false);
        }
    };

    return (
        <div className="flex flex-col h-full bg-background overflow-hidden">
            {/* Header */}
            <div className="bg-glass-heavy backdrop-blur-lg border-b border-border p-4">
                <div className="flex items-center justify-between">
                    <button
                        onClick={onRetry}
                        className="flex items-center gap-2 px-3 py-2 bg-button-secondary hover:bg-button-secondary-hover rounded-xl text-button-secondary-text transition-colors border border-border"
                    >
                        <ArrowLeft className="w-5 h-5 flex-shrink-0" />
                        <span className="hidden sm:inline">Back</span>
                    </button>

                    <h1 className="text-lg font-semibold text-content-primary text-center flex-1 mx-4">
                        Preview Receipt{capturedImages.length > 1 ? 's' : ''}
                    </h1>

                    <button
                        onClick={onAddMore}
                        className="flex items-center gap-2 px-3 py-2 bg-primary hover:bg-primary-dark rounded-xl text-primary-contrast transition-colors shadow-glow-primary"
                    >
                        <Plus className="w-5 h-5 flex-shrink-0" />
                        <span className="hidden sm:inline">Add More</span>
                    </button>
                </div>
            </div>

            {/* Preview Area */}
            <div className="flex-1 p-4 overflow-y-auto">
                <div className="max-w-2xl mx-auto space-y-6">
                    {/* Images Grid/Carousel */}
                    <div className="space-y-4">
                        {/* Main Image Display */}
                        {capturedImages.length > 0 && (
                            <div className="relative">
                                <div className="relative bg-surface rounded-2xl border border-card-border overflow-hidden shadow-card">
                                    <img
                                        src={capturedImages[currentImageIndex]}
                                        alt={`Receipt ${currentImageIndex + 1}`}
                                        className="w-full h-auto max-h-96 object-contain"
                                        onError={(e) => {
                                            console.error('Image failed to load:', e);
                                        }}
                                    />

                                    {/* Remove Image Button */}
                                    <button
                                        onClick={() => onRemoveImage(currentImageIndex)}
                                        className="absolute top-3 right-3 w-10 h-10 bg-error hover:bg-error-dark rounded-full flex items-center justify-center transition-colors shadow-lg text-error-contrast"
                                    >
                                        <X className="w-5 h-5" />
                                    </button>

                                    {/* Image Counter */}
                                    {capturedImages.length > 1 && (
                                        <div className="absolute bottom-3 right-3 px-3 py-1 bg-glass-heavy backdrop-blur-lg rounded-full border border-border">
                                            <span className="text-sm font-medium text-content-inverse">
                                                {currentImageIndex + 1} / {capturedImages.length}
                                            </span>
                                        </div>
                                    )}
                                </div>

                                {/* Navigation arrows for multiple images */}
                                {capturedImages.length > 1 && (
                                    <>
                                        {currentImageIndex > 0 && (
                                            <button
                                                onClick={() => setCurrentImageIndex(prev => prev - 1)}
                                                className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-glass-heavy hover:bg-glass-secondary backdrop-blur-lg rounded-full flex items-center justify-center border border-border transition-colors"
                                            >
                                                <ArrowLeft className="w-5 h-5 text-content-inverse" />
                                            </button>
                                        )}
                                        {currentImageIndex < capturedImages.length - 1 && (
                                            <button
                                                onClick={() => setCurrentImageIndex(prev => prev + 1)}
                                                className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-glass-heavy hover:bg-glass-secondary backdrop-blur-lg rounded-full flex items-center justify-center border border-border transition-colors"
                                            >
                                                <ArrowLeft className="w-5 h-5 text-content-inverse rotate-180" />
                                            </button>
                                        )}
                                    </>
                                )}
                            </div>
                        )}

                        {/* Thumbnail Strip for Multiple Images */}
                        {capturedImages.length > 1 && (
                            <div className="flex gap-2 overflow-x-auto pb-2">
                                {capturedImages.map((image, index) => (
                                    <button
                                        key={index}
                                        onClick={() => setCurrentImageIndex(index)}
                                        className={`relative flex-shrink-0 w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${
                                            currentImageIndex === index
                                                ? 'border-primary shadow-glow-primary'
                                                : 'border-border hover:border-border-hover'
                                        }`}
                                    >
                                        <img
                                            src={image}
                                            alt={`Thumbnail ${index + 1}`}
                                            className="w-full h-full object-cover"
                                        />
                                        <div className="absolute inset-0 bg-overlay-dark opacity-0 hover:opacity-30 transition-opacity" />
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Notes Input */}
                    <div className="space-y-2">
                        <label className="block text-sm font-medium text-content-primary">
                            Add Notes (Optional)
                        </label>
                        <textarea
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            placeholder="Add any notes about this receipt..."
                            className="w-full p-3 bg-input border border-input-border hover:border-input-hover-border focus:border-input-focus-border focus:ring-2 focus:ring-input-focus-ring rounded-xl text-content-primary placeholder-input-placeholder transition-colors resize-none"
                            rows={3}
                        />
                    </div>

                    {/* Error Message */}
                    {error && (
                        <div className="p-4 bg-error-surface border border-error rounded-xl">
                            <div className="flex items-start gap-2">
                                <AlertCircle className="w-5 h-5 text-error flex-shrink-0 mt-0.5" />
                                <span className="text-error text-sm">{error}</span>
                            </div>
                        </div>
                    )}

                    {/* Success Message with Upload Response */}
                    {uploadResponse && (
                        <div className="p-4 bg-success-surface border border-success rounded-xl">
                            <div className="flex items-start gap-2 mb-3">
                                <CheckCircle className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                                <div>
                                    <p className="text-success font-medium">Upload Successful!</p>
                                    <p className="text-success-dark text-sm mt-1">
                                        Receipt processed from {uploadResponse.vendor} • {uploadResponse.category}
                                    </p>
                                </div>
                            </div>

                            {/* Receipt Summary */}
                            <div className="bg-glass-light border border-border rounded-xl p-3 mt-3">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="font-medium text-content-primary">Total Amount</span>
                                    <span className="font-bold text-primary">₹{uploadResponse.total}</span>
                                </div>
                                <div className="text-sm text-content-secondary">
                                    {uploadResponse.items?.length} item{uploadResponse.items?.length !== 1 ? 's' : ''} • {uploadResponse.date}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Action Buttons */}
                    <div className="space-y-3">
                        {!uploadResponse ? (
                            // Upload Buttons
                            <div className="flex gap-3">
                                <button
                                    onClick={onRetry}
                                    disabled={isUploading}
                                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-button-secondary hover:bg-button-secondary-hover disabled:bg-button-secondary-disabled rounded-xl text-button-secondary-text disabled:text-button-secondary-disabled-text transition-colors border border-border"
                                >
                                    <RotateCcw className="w-5 h-5" />
                                    <span>Retry</span>
                                </button>

                                <button
                                    onClick={handleUpload}
                                    disabled={isUploading || capturedImages.length === 0}
                                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-button-primary hover:bg-button-primary-hover disabled:bg-button-primary-disabled rounded-xl text-button-primary-text disabled:text-button-primary-disabled-text transition-colors shadow-glow-primary"
                                >
                                    {isUploading ? (
                                        <>
                                            <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                                            <span>Uploading...</span>
                                        </>
                                    ) : (
                                        <>
                                            <Upload className="w-5 h-5" />
                                            <span>Upload {capturedImages.length} Receipt{capturedImages.length !== 1 ? 's' : ''}</span>
                                        </>
                                    )}
                                </button>
                            </div>
                        ) : (
                            // Post-Upload Actions
                            <div className="flex gap-3">
                                <button
                                    onClick={onRetry}
                                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-button-secondary hover:bg-button-secondary-hover rounded-xl text-button-secondary-text transition-colors border border-border"
                                >
                                    <Plus className="w-5 h-5" />
                                    <span>New Receipt</span>
                                </button>

                                <button
                                    onClick={handleAddToWallet}
                                    disabled={isAddingToWallet}
                                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-secondary hover:bg-secondary-dark disabled:bg-secondary/50 rounded-xl text-secondary-contrast transition-colors shadow-glow-secondary"
                                >
                                    {isAddingToWallet ? (
                                        <>
                                            <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                                            <span>Adding...</span>
                                        </>
                                    ) : (
                                        <>
                                            <Wallet className="w-5 h-5" />
                                            <span>Add to Wallet</span>
                                        </>
                                    )}
                                </button>
                            </div>
                        )}
                    </div>

                    {/* Additional info text */}
                    <p className="text-center text-content-secondary text-sm">
                        {!uploadResponse
                            ? `Review your ${capturedImages.length} receipt${capturedImages.length !== 1 ? 's' : ''} and tap Upload to save.`
                            : 'Receipt saved successfully! Add to your digital wallet for easy access.'
                        }
                    </p>
                </div>
            </div>

            {/* Wallet Confirmation Modal */}
            {showWalletConfirm && (
                <div className="fixed inset-0 bg-overlay-modal flex items-center justify-center p-6 z-modal backdrop-blur-lg">
                    <div className="relative bg-gradient-to-br from-glass-heavy to-glass-secondary border border-border rounded-3xl p-6 max-w-sm w-full shadow-card backdrop-blur-2xl overflow-hidden">
                        {/* Background Pattern */}
                        <div className="absolute inset-0 opacity-10">
                            <div className="absolute top-0 left-0 w-full h-1 bg-secondary"></div>
                            <div className="absolute bottom-0 left-0 w-full h-1 bg-secondary"></div>
                            <div className="absolute top-4 left-4 w-2 h-2 bg-secondary rounded-full"></div>
                            <div className="absolute top-4 right-4 w-2 h-2 bg-secondary rounded-full"></div>
                            <div className="absolute bottom-4 left-4 w-2 h-2 bg-secondary rounded-full"></div>
                            <div className="absolute bottom-4 right-4 w-2 h-2 bg-secondary rounded-full"></div>
                        </div>

                        {/* Modal Content */}
                        <div className="relative z-10">
                            {/* Icon Header */}
                            <div className="text-center mb-6">
                                <div className="w-16 h-16 bg-secondary-surface rounded-2xl flex items-center justify-center mx-auto mb-4 border border-secondary/20">
                                    <Wallet className="w-8 h-8 text-secondary" />
                                </div>
                                <h3 className="text-lg font-semibold text-content-primary mb-2">Add to Wallet</h3>
                                <p className="text-content-tertiary text-sm leading-relaxed">
                                    This will open your wallet app to save the receipt pass. Continue?
                                </p>
                            </div>

                            {/* Action Buttons */}
                            <div className="flex gap-3">
                                <button
                                    onClick={() => setShowWalletConfirm(false)}
                                    className="flex-1 px-4 py-3 bg-button-secondary hover:bg-button-secondary-hover active:bg-button-secondary-active rounded-xl text-button-secondary-text transition-all duration-normal font-medium text-sm border border-border hover:border-border-hover backdrop-blur-sm"
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={handleWalletConfirm}
                                    className="flex-1 px-4 py-3 bg-secondary hover:bg-secondary-dark active:bg-secondary-dark rounded-xl text-secondary-contrast transition-all duration-normal font-medium text-sm shadow-glow-secondary hover:shadow-lg"
                                >
                                    Open Wallet
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ReceiptPreview;
