import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Trash2, Info, X, Calendar, HardDrive, ChevronLeft, ChevronRight, Images, Zap } from 'lucide-react';
import { getReceiptsFromStorage, deleteReceiptFromStorage } from '@/utils/receipt/receiptStorage.js';

const ReceiptHistory = ({ onBack = null, className = "" }) => {
    const [receipts, setReceipts] = useState([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [flippedStates, setFlippedStates] = useState({});
    const [imageIndices, setImageIndices] = useState({}); // Track current image for each receipt
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
    const [touchStart, setTouchStart] = useState(null);
    const [touchEnd, setTouchEnd] = useState(null);
    const [isDragging, setIsDragging] = useState(false);
    const [dragOffset, setDragOffset] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const containerRef = useRef(null);
    const flipTimeoutRefs = useRef({});

    // Load receipts from async storage
    useEffect(() => {
        const loadReceipts = async () => {
            try {
                setIsLoading(true);
                setError(null);
                const loadedReceipts = await getReceiptsFromStorage();
                setReceipts(loadedReceipts);
            } catch (err) {
                console.error('Failed to load receipts:', err);
                setError('Failed to load receipts. Please try again.');
                setReceipts([]);
            } finally {
                setIsLoading(false);
            }
        };

        loadReceipts();
    }, []);

    // Initialize image indices for all receipts
    useEffect(() => {
        const initialIndices = {};
        receipts.forEach(receipt => {
            initialIndices[receipt.id] = 0;
        });
        setImageIndices(initialIndices);
    }, [receipts]);

    // Auto flip back after 5 seconds for individual cards
    useEffect(() => {
        Object.keys(flippedStates).forEach(cardId => {
            if (flippedStates[cardId]) {
                flipTimeoutRefs.current[cardId] = setTimeout(() => {
                    setFlippedStates(prev => ({
                        ...prev,
                        [cardId]: false
                    }));
                }, 5000);
            } else {
                if (flipTimeoutRefs.current[cardId]) {
                    clearTimeout(flipTimeoutRefs.current[cardId]);
                    delete flipTimeoutRefs.current[cardId];
                }
            }
        });

        return () => {
            Object.values(flipTimeoutRefs.current).forEach(timeout => {
                if (timeout) clearTimeout(timeout);
            });
        };
    }, [flippedStates]);

    // Reset flip states when changing cards
    useEffect(() => {
        setFlippedStates({});
        Object.values(flipTimeoutRefs.current).forEach(timeout => {
            if (timeout) clearTimeout(timeout);
        });
        flipTimeoutRefs.current = {};
    }, [currentIndex]);

    // Enhanced delete function with async storage
    const handleDeleteReceipt = async (id) => {
        try {
            const updatedReceipts = await deleteReceiptFromStorage(id);
            setReceipts(updatedReceipts);

            if (currentIndex >= updatedReceipts.length && updatedReceipts.length > 0) {
                setCurrentIndex(updatedReceipts.length - 1);
            } else if (updatedReceipts.length === 0) {
                setCurrentIndex(0);
            }

            setShowDeleteConfirm(false);
        } catch (err) {
            console.error('Failed to delete receipt:', err);
            setError('Failed to delete receipt. Please try again.');
        }
    };

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    // Navigate between images within a receipt
    const handleImageNavigation = (receiptId, direction) => {
        const receipt = receipts.find(r => r.id === receiptId);
        if (!receipt || !receipt.images || receipt.images.length <= 1) return;

        setImageIndices(prev => {
            const currentImg = prev[receiptId] || 0;
            let newIndex;

            if (direction === 'next') {
                newIndex = currentImg >= receipt.images.length - 1 ? 0 : currentImg + 1;
            } else {
                newIndex = currentImg <= 0 ? receipt.images.length - 1 : currentImg - 1;
            }

            return {
                ...prev,
                [receiptId]: newIndex
            };
        });
    };

    const handleTouchStart = (e) => {
        setTouchEnd(null);
        setTouchStart(e.targetTouches[0].clientX);
        setIsDragging(true);
    };

    const handleTouchMove = (e) => {
        const currentTouch = e.targetTouches[0].clientX;
        setTouchEnd(currentTouch);

        if (touchStart && !flippedStates[receipts[currentIndex]?.id]) {
            const offset = currentTouch - touchStart;
            const maxOffset = 100;
            const clampedOffset = Math.max(-maxOffset, Math.min(maxOffset, offset));
            setDragOffset(clampedOffset);
        }
    };

    const handleTouchEnd = () => {
        if (!touchStart || !touchEnd || flippedStates[receipts[currentIndex]?.id]) {
            setIsDragging(false);
            setDragOffset(0);
            return;
        }

        const distance = touchStart - touchEnd;
        const isLeftSwipe = distance > 50;
        const isRightSwipe = distance < -50;

        if (isLeftSwipe && currentIndex < receipts.length - 1) {
            setCurrentIndex(currentIndex + 1);
        }
        if (isRightSwipe && currentIndex > 0) {
            setCurrentIndex(currentIndex - 1);
        }

        setIsDragging(false);
        setDragOffset(0);
    };

    const handleCardTap = (cardId) => {
        if (!flippedStates[cardId]) {
            setFlippedStates(prev => ({
                ...prev,
                [cardId]: true
            }));
        }
    };

    const handleInfoClose = (cardId) => {
        setFlippedStates(prev => ({
            ...prev,
            [cardId]: false
        }));
    };

    const goToIndex = (index) => {
        setCurrentIndex(index);
    };

    // Loading state
    if (isLoading) {
        return (
            <div className={`w-full flex flex-col overflow-hidden ${className}`}>
                <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
                    <div className="w-24 h-24 rounded-3xl bg-surface-200 border border-border flex items-center justify-center mb-6 animate-pulse">
                        <div className="w-12 h-12 rounded-2xl bg-surface-300" />
                    </div>
                    <h2 className="text-xl font-semibold text-content-primary mb-3">Loading Receipts...</h2>
                    <p className="text-content-tertiary text-center max-w-sm leading-relaxed">
                        Retrieving your receipts from storage...
                    </p>
                </div>
            </div>
        );
    }

    // Error state
    if (error) {
        return (
            <div className={`w-full flex flex-col overflow-hidden ${className}`}>
                <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
                    <div className="w-24 h-24 rounded-3xl bg-error-surface border border-error flex items-center justify-center mb-6">
                        <X className="w-12 h-12 text-error" />
                    </div>
                    <h2 className="text-xl font-semibold text-content-primary mb-3">Error Loading Receipts</h2>
                    <p className="text-content-tertiary text-center max-w-sm leading-relaxed mb-4">
                        {error}
                    </p>
                    <button
                        onClick={() => window.location.reload()}
                        className="px-6 py-3 bg-button-primary hover:bg-button-primary-hover text-button-primary-text rounded-xl transition-all duration-200 font-medium"
                    >
                        Try Again
                    </button>
                </div>
            </div>
        );
    }

    // Empty state
    if (receipts.length === 0) {
        return (
            <div className={`w-full flex flex-col overflow-hidden ${className}`}>
                <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
                    <div className="w-24 h-24 rounded-3xl bg-surface-200 border border-border flex items-center justify-center mb-6">
                        <div className="w-12 h-12 rounded-2xl bg-surface-300 opacity-60" />
                    </div>
                    <h2 className="text-xl font-semibold text-content-primary mb-3">No Receipts Yet</h2>
                    <p className="text-content-tertiary text-center max-w-sm leading-relaxed">
                        Start scanning receipts to see them here. All receipts are saved with automatic compression for efficient storage.
                    </p>
                    {onBack && (
                        <button
                            onClick={onBack}
                            className="mt-6 px-6 py-3 bg-button-primary hover:bg-button-primary-hover text-button-primary-text rounded-xl transition-all duration-200 font-medium"
                        >
                            Go Back
                        </button>
                    )}
                </div>
            </div>
        );
    }

    return (
        <div className={`w-full h-full flex flex-col relative overflow-hidden ${className}`}>
            {/* Floating Back Button */}
            {onBack && (
                <button
                    onClick={onBack}
                    className="absolute top-4 left-4 z-50 w-10 h-10 bg-glass-primary hover:bg-glass-secondary border border-border rounded-full flex items-center justify-center transition-all duration-200 backdrop-blur-md"
                >
                    <ArrowLeft className="w-5 h-5 text-content-primary" />
                </button>
            )}

            {/* Cards Container with Receipt Proportions */}
            <div className="flex-1 relative flex items-center justify-center py-8">
                <div
                    className="relative w-full max-w-sm mx-auto"
                    style={{ aspectRatio: '2/3', maxHeight: '70vh' }}
                    ref={containerRef}
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onTouchEnd={handleTouchEnd}
                >
                    {/* Floating Counter - At leftmost edge of card */}
                    <div className="absolute top-4 left-0 z-50 px-3 py-1.5 bg-glass-primary border border-border rounded-full backdrop-blur-md">
                        <span className="text-sm font-medium text-content-primary">
                            {currentIndex + 1} / {receipts.length}
                        </span>
                    </div>

                    {receipts.map((receipt, index) => {
                        const isActive = index === currentIndex;
                        const isPrevious = index === currentIndex - 1;
                        const isNext = index === currentIndex + 1;
                        const isVisible = isActive || isPrevious || isNext;
                        const isFlipped = flippedStates[receipt.id] || false;
                        const currentImageIndex = imageIndices[receipt.id] || 0;
                        const currentImage = receipt.images?.[currentImageIndex] || receipt.images?.[0];
                        const hasMultipleImages = receipt.images && receipt.images.length > 1;

                        if (!isVisible) return null;

                        let translateX = 0;
                        let scale = 1;
                        let opacity = 1;
                        let zIndex = 0;
                        let rotateY = 0;

                        if (isActive) {
                            translateX = isDragging ? dragOffset : 0;
                            scale = 1;
                            opacity = 1;
                            zIndex = 30;
                            rotateY = 0;
                        } else if (isPrevious) {
                            translateX = -120;
                            scale = 0.85;
                            opacity = 0.5;
                            zIndex = 10;
                            rotateY = 25;
                        } else if (isNext) {
                            translateX = 120;
                            scale = 0.85;
                            opacity = 0.5;
                            zIndex = 10;
                            rotateY = -25;
                        }

                        return (
                            <div
                                key={receipt.id}
                                className="absolute inset-0 transition-all duration-500 ease-out"
                                style={{
                                    transform: `translateX(${translateX}px) scale(${scale}) rotateY(${rotateY}deg)`,
                                    opacity,
                                    zIndex,
                                    transformStyle: 'preserve-3d',
                                    perspective: '1000px'
                                }}
                            >
                                {/* Card Container with flip animation */}
                                <div
                                    className="relative w-full h-full cursor-pointer"
                                    style={{
                                        transformStyle: 'preserve-3d',
                                        perspective: '1000px'
                                    }}
                                    onClick={isActive ? () => handleCardTap(receipt.id) : undefined}
                                >
                                    <div
                                        className="absolute inset-0 transition-transform duration-700 ease-in-out"
                                        style={{
                                            transform: isFlipped ? 'rotateY(-180deg)' : 'rotateY(0deg)',
                                            transformStyle: 'preserve-3d'
                                        }}
                                    >
                                        {/* Front of Card - Image */}
                                        <div
                                            className="absolute inset-0 rounded-3xl overflow-hidden shadow-card border border-border bg-surface"
                                            style={{
                                                backfaceVisibility: 'hidden',
                                                transform: 'rotateY(0deg)'
                                            }}
                                        >
                                            <img
                                                src={currentImage}
                                                alt={`Receipt ${currentImageIndex + 1}`}
                                                className="absolute inset-0 w-full h-full object-cover"
                                                style={{ imageRendering: 'crisp-edges' }}
                                            />

                                            {/* Compression Indicator */}
                                            {receipt.compressed && isActive && !isFlipped && (
                                                <div className="absolute top-4 left-4 z-40">
                                                    <div className="flex items-center gap-1.5 px-2 py-1 bg-glass-heavy backdrop-blur-lg border border-border rounded-full">
                                                        <Zap className="w-3 h-3 text-green-400" />
                                                        <span className="text-xs font-medium text-content-inverse">
                                                            Compressed
                                                        </span>
                                                    </div>
                                                </div>
                                            )}

                                            {/* Multiple Images Indicator */}
                                            {hasMultipleImages && isActive && !isFlipped && (
                                                <div className="absolute bottom-4 left-4 z-40">
                                                    <div className="flex items-center gap-2 px-3 py-1.5 bg-glass-heavy backdrop-blur-lg border border-border rounded-full">
                                                        <Images className="w-4 h-4 text-content-inverse" />
                                                        <span className="text-sm font-medium text-content-inverse">
                                                            {currentImageIndex + 1}/{receipt.images.length}
                                                        </span>
                                                    </div>
                                                </div>
                                            )}

                                            {/* Image Navigation Arrows */}
                                            {hasMultipleImages && isActive && !isFlipped && (
                                                <>
                                                    <button
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleImageNavigation(receipt.id, 'prev');
                                                        }}
                                                        className="absolute left-4 top-1/2 -translate-y-1/2 z-40 w-10 h-10 bg-glass-heavy hover:bg-glass-secondary backdrop-blur-lg border border-border rounded-full flex items-center justify-center transition-all duration-200"
                                                    >
                                                        <ChevronLeft className="w-5 h-5 text-content-inverse" />
                                                    </button>
                                                    <button
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            handleImageNavigation(receipt.id, 'next');
                                                        }}
                                                        className="absolute right-4 top-1/2 -translate-y-1/2 z-40 w-10 h-10 bg-glass-heavy hover:bg-glass-secondary backdrop-blur-lg border border-border rounded-full flex items-center justify-center transition-all duration-200"
                                                        style={{ marginRight: '60px' }} // Offset for action buttons
                                                    >
                                                        <ChevronRight className="w-5 h-5 text-content-inverse" />
                                                    </button>
                                                </>
                                            )}

                                            {/* Floating Action Buttons - Only on front */}
                                            {isActive && !isFlipped && (
                                                <div className="absolute top-4 right-4 flex flex-col gap-2 z-40">
                                                    <button
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            setFlippedStates(prev => ({
                                                                ...prev,
                                                                [receipt.id]: true
                                                            }));
                                                        }}
                                                        className="w-10 h-10 bg-glass-primary hover:bg-glass-secondary border border-border rounded-full flex items-center justify-center transition-all duration-200 backdrop-blur-md text-content-primary"
                                                    >
                                                        <Info className="w-5 h-5" />
                                                    </button>

                                                    <button
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            setShowDeleteConfirm(true);
                                                        }}
                                                        className="w-10 h-10 bg-glass-primary hover:bg-error-surface border border-border rounded-full flex items-center justify-center transition-all duration-200 backdrop-blur-md text-error hover:text-error-light"
                                                    >
                                                        <Trash2 className="w-5 h-5" />
                                                    </button>
                                                </div>
                                            )}
                                        </div>

                                        {/* Back of Card - Information (Enhanced for compression info) */}
                                        <div
                                            className="absolute inset-0 rounded-3xl overflow-hidden shadow-card border border-border bg-gradient-to-br from-glass-heavy to-glass-secondary backdrop-blur-lg"
                                            style={{
                                                backfaceVisibility: 'hidden',
                                                transform: 'rotateY(180deg)'
                                            }}
                                        >
                                            {/* Background Pattern */}
                                            <div className="absolute inset-0 opacity-10">
                                                <div className="absolute top-0 left-0 w-full h-1 bg-primary"></div>
                                                <div className="absolute bottom-0 left-0 w-full h-1 bg-primary"></div>
                                                <div className="absolute top-4 left-4 w-2 h-2 bg-primary rounded-full"></div>
                                                <div className="absolute top-4 right-4 w-2 h-2 bg-primary rounded-full"></div>
                                                <div className="absolute bottom-4 left-4 w-2 h-2 bg-primary rounded-full"></div>
                                                <div className="absolute bottom-4 right-4 w-2 h-2 bg-primary rounded-full"></div>
                                            </div>

                                            {/* Close Button */}
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleInfoClose(receipt.id);
                                                }}
                                                className="absolute top-4 right-4 z-40 w-10 h-10 bg-glass-primary hover:bg-glass-secondary border border-border rounded-full flex items-center justify-center transition-all duration-200 backdrop-blur-md text-content-primary"
                                            >
                                                <X className="w-5 h-5" />
                                            </button>

                                            {/* Card Info Content */}
                                            <div className="absolute inset-0 p-6 flex flex-col">
                                                {/* Receipt Header */}
                                                <div className="text-center mb-6 pt-4">
                                                    <div className="w-12 h-12 bg-primary-glass rounded-2xl flex items-center justify-center mx-auto mb-3">
                                                        {hasMultipleImages ? (
                                                            <Images className="w-6 h-6 text-primary" />
                                                        ) : (
                                                            <div className="w-6 h-6 bg-primary rounded-lg opacity-80"></div>
                                                        )}
                                                    </div>
                                                    <h3 className="text-lg font-semibold text-content-primary mb-1 line-clamp-2">
                                                        Receipt Details
                                                    </h3>
                                                    <p className="text-xs text-content-tertiary">
                                                        {hasMultipleImages ?
                                                            `${receipt.imageCount} images` :
                                                            receipt.filenames?.[0] || 'Receipt'
                                                        }
                                                    </p>
                                                </div>

                                                {/* Information Fields */}
                                                <div className="flex-1 space-y-4">
                                                    <div className="bg-glass-light rounded-2xl p-4 border border-border">
                                                        <div className="flex items-center gap-3">
                                                            <div className="w-10 h-10 bg-primary-glass rounded-xl flex items-center justify-center flex-shrink-0">
                                                                <Calendar className="w-5 h-5 text-primary" />
                                                            </div>
                                                            <div className="flex-1">
                                                                <div className="text-xs text-content-tertiary mb-1">Date Captured</div>
                                                                <div className="text-sm font-medium text-content-primary">
                                                                    {formatDate(receipt.capturedAt)}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="bg-glass-light rounded-2xl p-4 border border-border">
                                                        <div className="flex items-center gap-3">
                                                            <div className="w-10 h-10 bg-secondary-glass rounded-xl flex items-center justify-center flex-shrink-0">
                                                                <HardDrive className="w-5 h-5 text-secondary" />
                                                            </div>
                                                            <div className="flex-1">
                                                                <div className="text-xs text-content-tertiary mb-1">
                                                                    {hasMultipleImages ? 'Total Size' : 'File Size'}
                                                                </div>
                                                                <div className="text-sm font-medium text-content-primary">
                                                                    {formatFileSize(receipt.totalSize || receipt.sizes?.[0] || 0)}
                                                                </div>
                                                                {hasMultipleImages && (
                                                                    <div className="text-xs text-content-tertiary mt-1">
                                                                        {receipt.imageCount} images
                                                                    </div>
                                                                )}
                                                                {receipt.compressed && (receipt.totalCompressedSize || receipt.compressedSizes) && (
                                                                    <div className="flex items-center gap-1 mt-1">
                                                                        <Zap className="w-3 h-3 text-green-400" />
                                                                        <span className="text-xs text-green-400">
                                                                            Compressed ({Math.round((1 - (receipt.totalCompressedSize || receipt.compressedSizes[0]) / (receipt.totalSize || receipt.sizes[0])) * 100)}% smaller)
                                                                        </span>
                                                                    </div>
                                                                )}
                                                            </div>
                                                        </div>
                                                    </div>

                                                    {/* Notes Section */}
                                                    {receipt.notes && (
                                                        <div className="bg-glass-light rounded-2xl p-4 border border-border">
                                                            <div className="text-xs text-content-tertiary mb-2">Notes</div>
                                                            <div className="text-sm text-content-primary leading-relaxed">
                                                                {receipt.notes}
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>

                                                {/* Footer */}
                                                <div className="mt-4 pt-4 border-t border-border text-center">
                                                    <p className="text-xs text-content-tertiary">
                                                        Tap anywhere to flip back
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Bottom Navigation */}
            <div className="flex items-center justify-center py-3">
                <div className="flex items-center gap-2 px-4 py-2 bg-glass-primary border border-border rounded-full backdrop-blur-md">
                    {receipts.map((_, index) => (
                        <button
                            key={index}
                            onClick={() => goToIndex(index)}
                            className={`transition-all duration-200 ${
                                index === currentIndex
                                    ? 'w-6 h-2 bg-primary rounded-full'
                                    : 'w-2 h-2 bg-content-tertiary hover:bg-content-secondary rounded-full'
                            }`}
                        />
                    ))}
                </div>
            </div>

            {/* Updated Swipe Instructions with compression info */}
            <div className="text-center pb-3">
                <p className="text-xs text-content-tertiary bg-glass-primary px-3 py-1 rounded-full backdrop-blur-md mx-auto w-fit border border-border">
                    Swipe or tap info • {receipts.length} receipt{receipts.length !== 1 ? 's' : ''} • {receipts.reduce((sum, r) => sum + (r.imageCount || 1), 0)} image{receipts.reduce((sum, r) => sum + (r.imageCount || 1), 0) !== 1 ? 's' : ''} • Auto-compressed
                </p>
            </div>

            {/* Delete Confirmation Modal */}
            {showDeleteConfirm && (
                <div className="fixed inset-0 bg-overlay-modal flex items-center justify-center p-6 z-modal backdrop-blur-lg">
                    <div className="relative bg-gradient-to-br from-glass-heavy to-glass-secondary border border-border rounded-3xl p-6 max-w-sm w-full shadow-card backdrop-blur-2xl overflow-hidden">

                        {/* Background Pattern */}
                        <div className="absolute inset-0 opacity-10">
                            <div className="absolute top-0 left-0 w-full h-1 bg-error"></div>
                            <div className="absolute bottom-0 left-0 w-full h-1 bg-error"></div>
                            <div className="absolute top-4 left-4 w-2 h-2 bg-error rounded-full"></div>
                            <div className="absolute top-4 right-4 w-2 h-2 bg-error rounded-full"></div>
                            <div className="absolute bottom-4 left-4 w-2 h-2 bg-error rounded-full"></div>
                            <div className="absolute bottom-4 right-4 w-2 h-2 bg-error rounded-full"></div>
                        </div>

                        {/* Modal Content */}
                        <div className="relative z-10">
                            {/* Icon Header */}
                            <div className="text-center mb-6">
                                <div className="w-16 h-16 bg-error-surface rounded-2xl flex items-center justify-center mx-auto mb-4 border border-error/20">
                                    <svg className="w-8 h-8 text-error" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                    </svg>
                                </div>
                                <h3 className="text-lg font-semibold text-content-primary mb-2">Delete Receipt?</h3>
                                <p className="text-content-tertiary text-sm leading-relaxed">
                                    {receipts[currentIndex]?.imageCount > 1
                                        ? `This receipt batch with ${receipts[currentIndex]?.imageCount} images will be permanently deleted and cannot be recovered.`
                                        : 'This receipt will be permanently deleted and cannot be recovered.'
                                    }
                                </p>
                            </div>

                            {/* Action Buttons */}
                            <div className="flex gap-3">
                                <button
                                    onClick={() => setShowDeleteConfirm(false)}
                                    className="flex-1 px-4 py-3 bg-button-secondary hover:bg-button-secondary-hover active:bg-button-secondary-active rounded-xl text-button-secondary-text transition-all duration-normal font-medium text-sm border border-border hover:border-border-hover backdrop-blur-sm"
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={() => handleDeleteReceipt(receipts[currentIndex].id)}
                                    className="flex-1 px-4 py-3 bg-error hover:bg-error-dark active:bg-error-dark rounded-xl text-error-contrast transition-all duration-normal font-medium text-sm shadow-glow-error hover:shadow-lg"
                                >
                                    Delete
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ReceiptHistory;
