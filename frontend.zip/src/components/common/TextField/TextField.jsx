import React, { forwardRef } from 'react';

/**
 * TextField component
 * @param {Object} props
 * @param {string} [props.id] - Input id (required if label is provided)
 * @param {string} [props.label] - Label text
 * @param {string} [props.type='text'] - Input type
 * @param {string} [props.placeholder] - Placeholder text
 * @param {boolean} [props.required=false] - Whether input is required
 * @param {boolean} [props.disabled=false] - Whether input is disabled
 * @param {boolean} [props.error=false] - Whether input has an error
 * @param {string} [props.errorText] - Error message
 * @param {string} [props.helperText] - Helper text
 * @param {React.ReactNode} [props.leftIcon] - Icon to display on left
 * @param {React.ReactNode} [props.rightIcon] - Icon to display on right
 * @param {Function} [props.onChange] - Change handler
 * @param {Function} [props.onBlur] - Blur handler
 * @param {Function} [props.onFocus] - Focus handler
 */
const TextField = forwardRef(({
  id,
  label,
  type = 'text',
  placeholder,
  required = false,
  disabled = false,
  error = false,
  errorText,
  helperText,
  leftIcon,
  rightIcon,
  className = '',
  labelClassName = '',
  inputClassName = '',
  onChange,
  onBlur,
  onFocus,
  ...props
}, ref) => {
  // Generate an ID if one isn't provided
  const inputId = id || `input-${Math.random().toString(36).substr(2, 9)}`;
  
  // Base classes
  const containerClasses = `w-full ${className}`;
  
  // Label classes with font family from theme
  const labelClasses = `block text-sm font-medium text-content-primary dark:text-content-primary font-primary mb-1 ${labelClassName}`;
  
  // Input wrapper classes to handle icons
  const inputWrapperClasses = 'relative';
  
  // Input base classes with theme specs
  const baseInputClasses = 'w-full rounded-md px-4 py-2 transition-colors focus:outline-none';
  
  // Input state classes based on theme colors
  const inputStateClasses = error
    ? 'border-error focus:border-error focus:ring-2 focus:ring-error-light'
    : disabled
      ? 'bg-input-disabled border-input-disabled-border text-content-disabled cursor-not-allowed'
      : 'border-input-border hover:border-input-hover-border focus:border-input-focus-border focus:ring-2 focus:ring-primary-light focus:ring-opacity-20';
  
  // Input appearance classes with font family from theme
  const inputAppearanceClasses = 'bg-input dark:bg-surface-700 text-content-primary dark:text-content-primary border font-primary text-base';
  
  // Icon padding classes
  const iconPaddingClasses = leftIcon ? 'pl-10' : rightIcon ? 'pr-10' : '';
  
  // Placeholder styling
  const placeholderClasses = 'placeholder:text-input-placeholder placeholder:opacity-70';
  
  const finalInputClasses = `${baseInputClasses} ${inputStateClasses} ${inputAppearanceClasses} ${iconPaddingClasses} ${placeholderClasses} ${inputClassName}`;

  return (
    <div className={containerClasses}>
      {label && (
        <label htmlFor={inputId} className={labelClasses}>
          {label}
          {required && <span className="text-error ml-1">*</span>}
        </label>
      )}
      
      <div className={inputWrapperClasses}>
        {leftIcon && (
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-input-icon">
            {leftIcon}
          </div>
        )}
        
        <input
          id={inputId}
          ref={ref}
          type={type}
          placeholder={placeholder}
          disabled={disabled}
          required={required}
          className={finalInputClasses}
          onChange={onChange}
          onBlur={onBlur}
          onFocus={onFocus}
          {...props}
        />
        
        {rightIcon && (
          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-input-icon">
            {rightIcon}
          </div>
        )}
      </div>
      
      {(errorText || helperText) && (
        <div className={`mt-1 text-sm font-primary ${error ? 'text-error' : 'text-content-tertiary'}`}>
          {error ? errorText : helperText}
        </div>
      )}
    </div>
  );
});

TextField.displayName = 'TextField';

export default TextField;