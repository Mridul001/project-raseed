import React, { Component } from 'react';
import Card from './Card';
import Typography from './Typography';
import Button from './Button';

/**
 * ErrorBoundary component that catches errors in its child components
 */
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
    };
  }

  // Static method to derive state from error
  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  // Lifecycle method to catch errors
  componentDidCatch(error, errorInfo) {
    this.setState({
      error: error,
      errorInfo: errorInfo,
    });

    // Log the error to an error reporting service
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    } else {
      console.error('Error caught by ErrorBoundary:', error, errorInfo);
    }
  }

  // Reset the error state
  handleReset = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
    });
  };

  render() {
    const { fallback, children } = this.props;
    const { hasError, error, errorInfo } = this.state;

    // If there's an error, render the fallback UI
    if (hasError) {
      // If a custom fallback is provided, use it
      if (fallback) {
        return typeof fallback === 'function'
          ? fallback(error, errorInfo, this.handleReset)
          : fallback;
      }

      // Otherwise, render the default error UI
      return (
        <Card variant="outlined" className="mt-4 mb-4">
          <Card.Header>
            <Typography.Heading variant="h4" color="error">Something went wrong</Typography.Heading>
          </Card.Header>
          <Card.Body>
            <Typography.Text className="mb-4">
              An error occurred in this component. Please try again or contact support if the problem persists.
            </Typography.Text>
            {process.env.NODE_ENV !== 'production' && error && (
              <div className="mb-4">
                <Typography.Text variant="small" className="font-mono bg-gray-100 dark:bg-gray-800 p-3 rounded block overflow-auto">
                  {error.toString()}
                </Typography.Text>
                {errorInfo && (
                  <Typography.Text variant="small" className="font-mono bg-gray-100 dark:bg-gray-800 p-3 mt-2 rounded block overflow-auto">
                    <pre>{errorInfo.componentStack}</pre>
                  </Typography.Text>
                )}
              </div>
            )}
            <Button variant="primary" onClick={this.handleReset}>
              Try Again
            </Button>
          </Card.Body>
        </Card>
      );
    }

    // If there's no error, render the children
    return children;
  }
}

export default ErrorBoundary;