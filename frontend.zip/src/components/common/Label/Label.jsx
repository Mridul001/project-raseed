import React from 'react';

/**
 * Label component
 * @param {Object} props
 * @param {string} props.htmlFor - ID of associated form element
 * @param {boolean} [props.required=false] - Whether the field is required
 * @param {React.ReactNode} props.children - Label content
 */
const Label = ({
  htmlFor,
  required = false,
  children,
  className = '',
  ...props
}) => {
  return (
    <label
      htmlFor={htmlFor}
      className={`block text-sm font-medium text-content-primary dark:text-content-primary mb-1 ${className}`}
      {...props}
    >
      {children}
      {required && <span className="text-error ml-1">*</span>}
    </label>
  );
};

export default Label;