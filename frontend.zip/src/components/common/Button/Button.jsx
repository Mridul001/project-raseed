import React from 'react';

/**
 * Button component
 * @param {Object} props
 * @param {string} [props.variant='primary'] - Button variant (primary, secondary, tertiary, danger)
 * @param {string} [props.size='md'] - Button size (sm, md, lg)
 * @param {boolean} [props.fullWidth=false] - Whether button should take full width
 * @param {boolean} [props.isLoading=false] - Loading state
 * @param {boolean} [props.disabled=false] - Whether button is disabled
 * @param {React.ReactNode} [props.leftIcon] - Icon to display on left
 * @param {React.ReactNode} [props.rightIcon] - Icon to display on right
 * @param {React.ReactNode} props.children - Button content
 * @param {string} [props.type='button'] - Button type
 * @param {Function} [props.onClick] - Click handler
 */
const Button = ({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  isLoading = false,
  disabled = false,
  leftIcon,
  rightIcon,
  children,
  type = 'button',
  onClick,
  className = '',
  ...props
}) => {
  // Base button classes
  const baseClasses = 'relative inline-flex items-center justify-center rounded-md font-medium transition-colors font-primary focus:outline-none focus:ring-2 focus:ring-offset-2';
  
  // Width classes
  const widthClasses = fullWidth ? 'w-full' : '';
  
  // Size classes
  const sizeClasses = {
    sm: 'text-sm px-3 py-1.5',
    md: 'text-base px-4 py-2',
    lg: 'text-lg px-6 py-3',
  }[size];
  
  // Variant classes (for non-disabled state)
  const variantClasses = {
    primary: 'bg-button-primary hover:bg-button-primary-hover active:bg-button-primary-active text-button-primary-text',
    secondary: 'bg-button-secondary hover:bg-button-secondary-hover active:bg-button-secondary-active text-button-secondary-text',
    tertiary: 'bg-button-tertiary hover:bg-button-tertiary-hover active:bg-button-tertiary-active text-button-tertiary-text',
    danger: 'bg-button-danger hover:bg-button-danger-hover active:bg-button-danger-active text-button-danger-text',
  }[variant];
  
  // Disabled classes
  const disabledClasses = disabled || isLoading
    ? {
        primary: 'bg-button-primary-disabled text-button-primary-disabled-text',
        secondary: 'bg-button-secondary-disabled text-button-secondary-disabled-text',
        tertiary: 'bg-button-tertiary-disabled text-button-tertiary-disabled-text',
        danger: 'bg-button-danger-disabled text-button-danger-disabled-text',
      }[variant]
    : '';
  
  // Focus ring classes
  const focusRingClasses = {
    primary: 'focus:ring-primary-light',
    secondary: 'focus:ring-muted',
    tertiary: 'focus:ring-muted',
    danger: 'focus:ring-error-light',
  }[variant];
  
  // Shadow classes based on variant
  const shadowClasses = {
    primary: 'shadow-sm',
    secondary: 'shadow-sm',
    tertiary: '',
    danger: 'shadow-sm',
  }[variant];
  
  const cursorClasses = disabled ? 'cursor-not-allowed' : isLoading ? 'cursor-wait' : '';
  
  // Dark mode adaptations
  const darkModeClasses = {
    primary: 'dark:bg-button-primary dark:hover:bg-button-primary-hover dark:active:bg-button-primary-active dark:text-button-primary-text',
    secondary: 'dark:bg-button-secondary dark:hover:bg-button-secondary-hover dark:text-button-secondary-text',
    tertiary: 'dark:bg-button-tertiary dark:hover:bg-button-tertiary-hover dark:text-button-tertiary-text',
    danger: 'dark:bg-button-danger dark:hover:bg-button-danger-hover dark:text-button-danger-text',
  }[variant];
  
  return (
    <button
      type={type}
      disabled={disabled || isLoading}
      className={`${baseClasses} ${widthClasses} ${sizeClasses} ${variantClasses} ${disabledClasses} ${focusRingClasses} ${shadowClasses} ${cursorClasses} ${darkModeClasses} ${className}`}
      onClick={onClick}
      {...props}
    >
      {isLoading && (
        <span className="absolute inset-0 flex items-center justify-center">
          <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        </span>
      )}
      
      <span className={`flex items-center ${isLoading ? 'invisible' : ''}`}>
        {leftIcon && <span className="mr-2">{leftIcon}</span>}
        {children}
        {rightIcon && <span className="ml-2">{rightIcon}</span>}
      </span>
    </button>
  );
};

export default Button;