import React from 'react';

/**
 * Social Login Button component
 * @param {Object} props
 * @param {string} props.provider - Provider name (google, github, etc.)
 * @param {React.ReactNode} props.icon - Provider icon
 * @param {string} [props.text] - Button text
 * @param {Function} props.onClick - Click handler
 */
const SocialButton = ({
  provider,
  icon,
  text,
  onClick,
  className = '',
  ...props
}) => {
  const baseClasses = 'flex items-center justify-center w-full px-4 py-2 text-base font-medium rounded-md transition-colors border focus:outline-none focus:ring-2 focus:ring-offset-2';
  
  // Provider-specific classes
  const providerClasses = {
    google: 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50 focus:ring-primary',
    github: 'border-gray-700 bg-gray-800 text-white hover:bg-gray-700 focus:ring-gray-500',
    twitter: 'border-blue-400 bg-blue-400 text-white hover:bg-blue-500 focus:ring-blue-400',
    facebook: 'border-blue-600 bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500',
    // Add more providers as needed
  }[provider] || 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50 focus:ring-primary';

  return (
    <button
      type="button"
      className={`${baseClasses} ${providerClasses} ${className}`}
      onClick={onClick}
      {...props}
    >
      {icon && <span className="mr-2">{icon}</span>}
      {text || `Continue with ${provider.charAt(0).toUpperCase() + provider.slice(1)}`}
    </button>
  );
};

export default SocialButton;