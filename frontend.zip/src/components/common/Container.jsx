import React from 'react';
import { useThemeValue } from '../../hooks/useTheme';

/**
 * Container component that adapts to the theme
 * Provides a responsive container for layout
 */
const Container = ({
  children,
  maxWidth = 'lg', // sm, md, lg, xl, 2xl, or none
  fluid = false,
  className = '',
  as = 'div',
  ...rest
}) => {
  // Get theme values
  const baseStyles = useThemeValue('components.container.base');
  const maxWidths = useThemeValue('components.container.maxWidths');

  // Determine container max-width class based on props
  let maxWidthClass = '';
  if (!fluid && maxWidth !== 'none') {
    maxWidthClass = getMaxWidthClass(maxWidth);
  }

  // Combine classes based on theme and props
  const containerClasses = `mx-auto px-4 sm:px-6 lg:px-8 ${maxWidthClass} ${className}`;

  // Use the specified element or default to div
  const Component = as;

  return (
    <Component className={containerClasses} {...rest}>
      {children}
    </Component>
  );
};

// Helper function to get Tailwind max-width class
const getMaxWidthClass = (maxWidth) => {
  switch (maxWidth) {
    case 'sm':
      return 'max-w-sm';
    case 'md':
      return 'max-w-md';
    case 'lg':
      return 'max-w-lg';
    case 'xl':
      return 'max-w-xl';
    case '2xl':
      return 'max-w-2xl';
    case '3xl':
      return 'max-w-3xl';
    case '4xl':
      return 'max-w-4xl';
    case '5xl':
      return 'max-w-5xl';
    case '6xl':
      return 'max-w-6xl';
    case '7xl':
      return 'max-w-7xl';
    default:
      return 'max-w-lg';
  }
};

export default Container;