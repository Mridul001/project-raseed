import React, { forwardRef } from 'react';
import { useThemeValue } from '../../hooks/useTheme';

/**
 * Input component that adapts to the theme
 */
const Input = forwardRef(({
  type = 'text',
  placeholder,
  value,
  onChange,
  disabled = false,
  error = false,
  helperText,
  label,
  size = 'md',
  fullWidth = true,
  className = '',
  ...rest
}, ref) => {
  // Get theme values
  const baseStyles = useThemeValue('components.input.base');
  const focusStyles = useThemeValue('components.input.focus');
  const errorStyles = useThemeValue('components.input.error');
  const disabledStyles = useThemeValue('components.input.disabled');
  const sizeStyles = useThemeValue(`components.input.sizes.${size}`);

  // Build class names
  const baseClasses = 'block border rounded-md shadow-sm transition-all focus:outline-none';
  const sizeClasses = getSizeClasses(size);
  const stateClasses = getStateClasses({ disabled, error });
  const widthClasses = fullWidth ? 'w-full' : '';

  // Combine all classes
  const inputClasses = `${baseClasses} ${sizeClasses} ${stateClasses} ${widthClasses} ${className}`;

  // Generate unique ID for the input
  const id = rest.id || `input-${Math.random().toString(36).substr(2, 9)}`;

  return (
    <div className={`${fullWidth ? 'w-full' : ''}`}>
      {label && (
        <label 
          htmlFor={id} 
          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
        >
          {label}
        </label>
      )}
      
      <input
        id={id}
        ref={ref}
        type={type}
        value={value}
        onChange={onChange}
        disabled={disabled}
        placeholder={placeholder}
        className={inputClasses}
        {...rest}
      />
      
      {helperText && (
        <p className={`mt-1 text-sm ${error ? 'text-error' : 'text-gray-500 dark:text-gray-400'}`}>
          {helperText}
        </p>
      )}
    </div>
  );
});

// Helper functions to get Tailwind classes
const getSizeClasses = (size) => {
  switch (size) {
    case 'sm':
      return 'px-3 py-1.5 text-sm';
    case 'md':
      return 'px-4 py-2 text-base';
    case 'lg':
      return 'px-5 py-3 text-lg';
    default:
      return 'px-4 py-2 text-base';
  }
};

const getStateClasses = ({ disabled, error }) => {
  if (disabled) {
    return 'bg-gray-100 border-gray-200 text-gray-500 cursor-not-allowed dark:bg-gray-700 dark:border-gray-600';
  }
  
  if (error) {
    return 'border-error focus:ring-error focus:border-error dark:border-error';
  }
  
  return 'border-gray-300 focus:ring-primary focus:border-primary dark:border-gray-600 dark:bg-gray-800 dark:text-white';
};

// Add display name for easier debugging
Input.displayName = 'Input';

export default Input;