import React, { useState, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { SuccessIcon, ErrorIcon, WarningIcon, InfoIcon, CloseIcon } from '../../../assets/svg/icons/icons.jsx';

/**
 * Toast component for displaying notifications
 *
 * @component
 */
const Toast = ({
                 message,
                 title,
                 type = 'info',
                 duration = 3000,
                 onClose,
                 position = 'top-right'
               }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isExiting, setIsExiting] = useState(false);

  // Get the appropriate icon based on type
  const getIcon = useCallback(() => {
    const iconProps = { size: 22, color: 'currentColor' };

    switch (type) {
      case 'success':
        return (
            <div className="h-8 w-8 rounded-full bg-success-light flex items-center justify-center text-success-contrast">
              <SuccessIcon {...iconProps} />
            </div>
        );
      case 'error':
        return (
            <div className="h-8 w-8 rounded-full bg-error-light flex items-center justify-center text-error-contrast">
              <ErrorIcon {...iconProps} />
            </div>
        );
      case 'warning':
        return (
            <div className="h-8 w-8 rounded-full bg-warning-light flex items-center justify-center text-warning-contrast">
              <WarningIcon {...iconProps} />
            </div>
        );
      case 'info':
      default:
        return (
            <div className="h-8 w-8 rounded-full bg-info-light flex items-center justify-center text-info-contrast">
              <InfoIcon {...iconProps} />
            </div>
        );
    }
  }, [type]);

  // Get background styles based on toast type
  const getBackgroundStyles = useCallback(() => {
    return 'bg-surface border border-border';
  }, []);

  // Get the top border color based on toast type
  const getTopBorderColor = useCallback(() => {
    switch (type) {
      case 'success':
        return 'bg-success';
      case 'error':
        return 'bg-error';
      case 'warning':
        return 'bg-warning';
      case 'info':
      default:
        return 'bg-info';
    }
  }, [type]);

  // Get header text color (ensure contrast with theme)
  const getHeaderTextColor = useCallback(() => {
    switch (type) {
      case 'success':
        return 'text-success-dark';
      case 'error':
        return 'text-error-dark';
      case 'warning':
        return 'text-warning-dark';
      case 'info':
      default:
        return 'text-info-dark';
    }
  }, [type]);

  // Get position styles
  const getPositionStyles = useCallback(() => {
    switch (position) {
      case 'top-left':
        return 'top-4 left-4';
      case 'top-center':
        return 'top-4 left-1/2 transform -translate-x-1/2';
      case 'top-right':
        return 'top-4 right-4';
      case 'bottom-left':
        return 'bottom-4 left-4';
      case 'bottom-center':
        return 'bottom-4 left-1/2 transform -translate-x-1/2';
      case 'bottom-right':
        return 'bottom-4 right-4';
      default:
        return 'top-4 right-4';
    }
  }, [position]);

  // Get transform for entry/exit animations
  const getTransformStyles = useCallback(() => {
    // Determine entry/exit direction based on position
    if (position.startsWith('top')) {
      return isExiting ? 'translate-y-[-15px]' : 'translate-y-0';
    } else {
      return isExiting ? 'translate-y-[15px]' : 'translate-y-0';
    }
  }, [position, isExiting]);

  // Close the toast
  const closeToast = useCallback(() => {
    setIsExiting(true);
    setTimeout(() => {
      setIsVisible(false);
      if (onClose) onClose();
    }, 300); // Allow time for the exit animation
  }, [onClose]);

  // Handle auto-closing the toast
  useEffect(() => {
    if (duration === 0) return; // Don't auto-close if duration is 0

    const timer = setTimeout(() => {
      closeToast();
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, closeToast]);

  if (!isVisible) return null;

  // Get the title to display
  const displayTitle = title || {
    success: 'Success',
    error: 'Error',
    warning: 'Warning',
    info: 'Information'
  }[type] || 'Notification';

  // Render the toast in a portal
  return createPortal(
      <div
          className={`fixed ${getPositionStyles()} z-tooltip transition-all duration-normal ease-out transform ${getTransformStyles()} ${isExiting ? 'opacity-0' : 'opacity-100'}`}
          role="alert"
          aria-live="assertive"
          style={{
            minWidth: '260px',
            maxWidth: '370px'
          }}
      >
        <div
            className={`rounded-lg shadow-lg ${getBackgroundStyles()} overflow-hidden backdrop-blur-md`}
        >
          {/* Top border color based on type */}
          <div className={`h-1 w-full ${getTopBorderColor()}`}></div>

          <div className="p-md flex items-start">
            {/* Icon */}
            <div className="flex-shrink-0 mr-sm">
              {getIcon()}
            </div>

            {/* Content */}
            <div className="flex-grow min-w-0">
              <h3 className={`text-base font-semibold ${getHeaderTextColor()} font-secondary truncate`}>
                {displayTitle}
              </h3>
              <p className="text-sm text-content-secondary mt-xs font-primary line-clamp-2">
                {message}
              </p>
            </div>

            {/* Close button */}
            <button
                onClick={closeToast}
                className="flex-shrink-0 ml-xs -mr-xs text-content-tertiary hover:text-content-secondary focus:outline-none focus:ring-1 focus:ring-primary rounded-full p-xs transition-colors duration-fast"
                aria-label="Close"
            >
              <CloseIcon size={18} />
            </button>
          </div>
        </div>
      </div>,
      document.body
  );
};

export default Toast;
