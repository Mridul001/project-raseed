import React from 'react';
import { useThemeValue } from '../../hooks/useTheme';

/**
 * Button component that adapts to the theme
 */
const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  onClick,
  type = 'button',
  className = '',
  ...rest
}) => {
  // Get theme values
  const baseStyles = useThemeValue('components.button.base');
  const variantStyles = useThemeValue(`components.button.variants.${variant}`);
  const sizeStyles = useThemeValue(`components.button.sizes.${size}`);
  
  // Combine styles from theme with Tailwind classes
  const baseClasses = 'inline-flex items-center justify-center font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2';
  const variantClasses = getVariantClasses(variant);
  const sizeClasses = getSizeClasses(size);
  const disabledClasses = disabled ? 'opacity-50 cursor-not-allowed' : '';
  const widthClasses = fullWidth ? 'w-full' : '';
  
  // Combine all classes
  const buttonClasses = `${baseClasses} ${variantClasses} ${sizeClasses} ${disabledClasses} ${widthClasses} ${className}`;

  return (
    <button
      type={type}
      className={buttonClasses}
      disabled={disabled}
      onClick={onClick}
      {...rest}
    >
      {children}
    </button>
  );
};

// Helper functions to get Tailwind classes based on variants and sizes
const getVariantClasses = (variant) => {
  switch (variant) {
    case 'primary':
      return 'bg-primary text-white hover:bg-primary-dark focus:ring-primary';
    case 'secondary':
      return 'bg-secondary text-white hover:bg-secondary-dark focus:ring-secondary';
    case 'outline':
      return 'bg-transparent border border-primary text-primary hover:bg-primary hover:text-white focus:ring-primary';
    case 'ghost':
      return 'bg-transparent text-primary hover:bg-primary-light hover:text-white focus:ring-primary';
    default:
      return 'bg-primary text-white hover:bg-primary-dark focus:ring-primary';
  }
};

const getSizeClasses = (size) => {
  switch (size) {
    case 'sm':
      return 'px-3 py-1.5 text-sm rounded';
    case 'md':
      return 'px-4 py-2 text-base rounded-md';
    case 'lg':
      return 'px-6 py-3 text-lg rounded-md';
    default:
      return 'px-4 py-2 text-base rounded-md';
  }
};

export default Button;