import React, { useState, useEffect } from 'react';
import { Calendar, HardDrive, Images, ChevronRight } from 'lucide-react';
import { getReceiptsFromStorage, getStorageInfo } from '@/utils/receipt/receiptStorage.js';

const ReceiptHistoryWidget = ({
                                  onReceiptClick = null,
                                  maxItems = 5,
                                  showStorageInfo = true,
                                  className = ""
                              }) => {
    const [receipts, setReceipts] = useState([]);
    const [storageInfo, setStorageInfo] = useState(null);

    useEffect(() => {
        const loadData = () => {
            const receiptData = getReceiptsFromStorage();
            setReceipts(receiptData.slice(0, maxItems));

            if (showStorageInfo) {
                setStorageInfo(getStorageInfo());
            }
        };

        loadData();

        // Listen for storage changes
        const handleStorageChange = () => {
            loadData();
        };

        window.addEventListener('storage', handleStorageChange);
        return () => {
            window.removeEventListener('storage', handleStorageChange);
        };
    }, [maxItems, showStorageInfo]);

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    };

    const handleReceiptClick = (receipt) => {
        if (onReceiptClick) {
            onReceiptClick(receipt);
        }
    };

    if (receipts.length === 0) {
        return (
            <div className={`p-6 bg-surface border border-card-border rounded-2xl ${className}`}>
                <div className="text-center">
                    <div className="w-16 h-16 bg-surface-200 rounded-2xl flex items-center justify-center mx-auto mb-4">
                        <div className="w-8 h-8 bg-surface-300 rounded-lg opacity-60" />
                    </div>
                    <h3 className="text-lg font-semibold text-content-primary mb-2">No Receipts Yet</h3>
                    <p className="text-content-tertiary text-sm">
                        Start scanning receipts to see them here.
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div className={`bg-surface border border-card-border rounded-2xl overflow-hidden ${className}`}>
            {/* Header with Storage Info */}
            <div className="p-4 border-b border-card-border">
                <div className="flex items-center justify-between">
                    <div>
                        <h3 className="text-lg font-semibold text-content-primary">Recent Receipts</h3>
                        {showStorageInfo && storageInfo && (
                            <p className="text-sm text-content-tertiary mt-1">
                                {storageInfo.totalReceipts} receipt{storageInfo.totalReceipts !== 1 ? 's' : ''} • {storageInfo.totalImages} image{storageInfo.totalImages !== 1 ? 's' : ''}
                            </p>
                        )}
                    </div>
                    {showStorageInfo && storageInfo && (
                        <div className="text-right">
                            <div className="text-sm font-medium text-content-primary">
                                {formatFileSize(storageInfo.totalSize)}
                            </div>
                            <div className="text-xs text-content-tertiary">
                                {storageInfo.averageImagesPerReceipt} avg/receipt
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Receipt List */}
            <div className="divide-y divide-card-border">
                {receipts.map((receipt) => {
                    const hasMultipleImages = receipt.images && receipt.images.length > 1;
                    const firstImage = receipt.images?.[0];

                    return (
                        <div
                            key={receipt.id}
                            onClick={() => handleReceiptClick(receipt)}
                            className="p-4 hover:bg-surface-hover transition-colors cursor-pointer group"
                        >
                            <div className="flex items-center gap-4">
                                {/* Receipt Thumbnail */}
                                <div className="relative flex-shrink-0">
                                    <div className="w-12 h-16 bg-surface-200 rounded-lg overflow-hidden border border-border">
                                        {firstImage ? (
                                            <img
                                                src={firstImage}
                                                alt="Receipt thumbnail"
                                                className="w-full h-full object-cover"
                                            />
                                        ) : (
                                            <div className="w-full h-full bg-surface-300 flex items-center justify-center">
                                                <div className="w-6 h-6 bg-surface opacity-60 rounded" />
                                            </div>
                                        )}
                                    </div>

                                    {/* Multiple Images Badge */}
                                    {hasMultipleImages && (
                                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center border-2 border-surface">
                                            <Images className="w-3 h-3 text-primary-contrast" />
                                        </div>
                                    )}
                                </div>

                                {/* Receipt Info */}
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-2">
                                        <div className="flex-1 min-w-0">
                                            {/* Title */}
                                            <div className="flex items-center gap-2 mb-1">
                                                <h4 className="font-medium text-content-primary truncate">
                                                    {receipt.type === 'batch' && hasMultipleImages
                                                        ? `Receipt Batch (${receipt.imageCount})`
                                                        : receipt.filenames?.[0] || 'Receipt'
                                                    }
                                                </h4>
                                                {hasMultipleImages && (
                                                    <span className="px-2 py-0.5 bg-primary-glass text-primary text-xs rounded-full flex-shrink-0">
                                                        {receipt.imageCount}
                                                    </span>
                                                )}
                                            </div>

                                            {/* Date and Size */}
                                            <div className="flex items-center gap-4 text-sm text-content-tertiary">
                                                <div className="flex items-center gap-1">
                                                    <Calendar className="w-4 h-4" />
                                                    <span>{formatDate(receipt.capturedAt)}</span>
                                                </div>
                                                <div className="flex items-center gap-1">
                                                    <HardDrive className="w-4 h-4" />
                                                    <span>{formatFileSize(receipt.totalSize || receipt.sizes?.[0] || 0)}</span>
                                                </div>
                                            </div>

                                            {/* Notes Preview */}
                                            {receipt.notes && (
                                                <div className="mt-1">
                                                    <p className="text-sm text-content-secondary truncate">
                                                        {receipt.notes}
                                                    </p>
                                                </div>
                                            )}
                                        </div>

                                        {/* Arrow */}
                                        <ChevronRight className="w-5 h-5 text-content-tertiary group-hover:text-content-secondary transition-colors flex-shrink-0" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* View All Footer */}
            {receipts.length > 0 && (
                <div className="p-4 border-t border-card-border bg-surface-100">
                    <button
                        onClick={() => onReceiptClick?.('view-all')}
                        className="w-full text-center text-primary hover:text-primary-dark font-medium text-sm transition-colors"
                    >
                        View All Receipts
                    </button>
                </div>
            )}
        </div>
    );
};

export default ReceiptHistoryWidget;
