import React from 'react';
import { useThemeValue } from '../../hooks/useTheme';

/**
 * Heading component for titles and subtitles
 */
export const Heading = ({
  children,
  variant = 'h1', // h1, h2, h3, h4, h5, h6
  className = '',
  color,
  as,
  ...rest
}) => {
  // Get theme values
  const baseStyles = useThemeValue('components.heading.base');
  const variantStyles = useThemeValue(`components.heading.variants.${variant}`);

  // Determine which HTML element to use based on variant or as prop
  const Component = as || variant;

  // Combine classes based on theme and props
  const headingClasses = `${getHeadingClasses(variant)} ${color ? `text-${color}` : ''} ${className}`;

  return (
    <Component className={headingClasses} {...rest}>
      {children}
    </Component>
  );
};

/**
 * Text component for paragraphs and other text content
 */
export const Text = ({
  children,
  variant = 'body', // body, lead, small, tiny
  className = '',
  color,
  as = 'p',
  ...rest
}) => {
  // Get theme values
  const baseStyles = useThemeValue('components.text.base');
  const variantStyles = useThemeValue(`components.text.variants.${variant}`);

  // Determine which HTML element to use
  const Component = as;

  // Combine classes based on theme and props
  const textClasses = `${getTextClasses(variant)} ${color ? `text-${color}` : ''} ${className}`;

  return (
    <Component className={textClasses} {...rest}>
      {children}
    </Component>
  );
};

// Helper functions to get Tailwind classes
const getHeadingClasses = (variant) => {
  switch (variant) {
    case 'h1':
      return 'text-4xl font-bold font-serif';
    case 'h2':
      return 'text-3xl font-bold font-serif';
    case 'h3':
      return 'text-2xl font-bold font-serif';
    case 'h4':
      return 'text-xl font-bold font-serif';
    case 'h5':
      return 'text-lg font-bold font-serif';
    case 'h6':
      return 'text-base font-bold font-serif';
    default:
      return 'text-4xl font-bold font-serif';
  }
};

const getTextClasses = (variant) => {
  switch (variant) {
    case 'body':
      return 'text-base font-normal';
    case 'lead':
      return 'text-lg font-semibold';
    case 'small':
      return 'text-sm font-normal';
    case 'tiny':
      return 'text-xs font-normal';
    default:
      return 'text-base font-normal';
  }
};

// Additional text components
export const Label = (props) => <Text as="label" variant="small" {...props} />;
export const Caption = (props) => <Text as="span" variant="tiny" {...props} />;

// Export all in a single object
const Typography = {
  Heading,
  Text,
  Label,
  Caption,
};

export default Typography;