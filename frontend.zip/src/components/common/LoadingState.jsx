import React from 'react';
import Typography from './Typography';

/**
 * LoadingState component to display loading indicators
 */
const LoadingState = ({
  type = 'spinner', // spinner, dots, skeleton, text
  text = 'Loading...',
  size = 'md',
  color = 'primary',
  fullScreen = false,
  transparent = false,
  className = '',
  ...rest
}) => {
  // Combine classes based on props
  const containerClasses = `flex items-center justify-center 
    ${fullScreen ? 'fixed inset-0 z-50' : 'w-full h-full'} 
    ${transparent ? 'bg-transparent' : 'bg-white bg-opacity-80 dark:bg-gray-900 dark:bg-opacity-80'} 
    ${className}`;

  // Get the appropriate loading indicator
  const loadingIndicator = getLoadingIndicator(type, size, color);

  return (
    <div className={containerClasses} {...rest}>
      <div className="flex flex-col items-center justify-center space-y-3">
        {loadingIndicator}
        {text && (
          <Typography.Text className="animate-pulse">{text}</Typography.Text>
        )}
      </div>
    </div>
  );
};

// Spinner component
export const Spinner = ({ size = 'md', color = 'primary', className = '', ...rest }) => {
  const sizeClasses = {
    sm: 'w-4 h-4 border-2',
    md: 'w-8 h-8 border-3',
    lg: 'w-12 h-12 border-4',
  };

  const colorClasses = {
    primary: 'border-primary',
    secondary: 'border-secondary',
    accent: 'border-accent',
    gray: 'border-gray-500',
    white: 'border-white',
  };

  const spinnerClasses = `inline-block rounded-full border-t-transparent animate-spin ${
    sizeClasses[size] || sizeClasses.md
  } ${colorClasses[color] || colorClasses.primary} ${className}`;

  return <div className={spinnerClasses} {...rest} />;
};

// Dots loading component
export const LoadingDots = ({ size = 'md', color = 'primary', className = '', ...rest }) => {
  const sizeClasses = {
    sm: 'w-1 h-1 mx-0.5',
    md: 'w-2 h-2 mx-1',
    lg: 'w-3 h-3 mx-1.5',
  };

  const colorClasses = {
    primary: 'bg-primary',
    secondary: 'bg-secondary',
    accent: 'bg-accent',
    gray: 'bg-gray-500',
    white: 'bg-white',
  };

  const dotClass = `rounded-full ${sizeClasses[size] || sizeClasses.md} ${
    colorClasses[color] || colorClasses.primary
  }`;

  return (
    <div className={`flex items-center ${className}`} {...rest}>
      <div className={`${dotClass} animate-bounce`} style={{ animationDelay: '0ms' }} />
      <div className={`${dotClass} animate-bounce`} style={{ animationDelay: '150ms' }} />
      <div className={`${dotClass} animate-bounce`} style={{ animationDelay: '300ms' }} />
    </div>
  );
};

// Skeleton loading component
export const Skeleton = ({ height, width, rounded = 'md', className = '', ...rest }) => {
  const roundedClasses = {
    none: 'rounded-none',
    sm: 'rounded-sm',
    md: 'rounded-md',
    lg: 'rounded-lg',
    full: 'rounded-full',
  };

  const skeletonClasses = `animate-pulse bg-gray-200 dark:bg-gray-700 ${
    roundedClasses[rounded] || roundedClasses.md
  } ${className}`;

  return (
    <div
      className={skeletonClasses}
      style={{
        height: height || '1rem',
        width: width || '100%',
      }}
      {...rest}
    />
  );
};

// Helper function to get the appropriate loading indicator
const getLoadingIndicator = (type, size, color) => {
  switch (type) {
    case 'spinner':
      return <Spinner size={size} color={color} />;
    case 'dots':
      return <LoadingDots size={size} color={color} />;
    case 'skeleton':
      return <Skeleton height="2rem" width="200px" />;
    case 'text':
      return null; // Text-only loading will show just the text message
    default:
      return <Spinner size={size} color={color} />;
  }
};

// Named exports for individual components
export { Spinner, LoadingDots, Skeleton };

export default LoadingState;