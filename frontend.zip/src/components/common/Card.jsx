import React from 'react';
import { useThemeValue } from '../../hooks/useTheme';

/**
 * Card component that adapts to the theme
 */
const Card = ({
  children,
  variant = 'default',
  className = '',
  ...rest
}) => {
  // Get theme values
  const baseStyles = useThemeValue('components.card.base');
  const variantStyles = useThemeValue(`components.card.variants.${variant}`);

  // Combine classes based on theme and variants
  const baseClasses = 'rounded-lg overflow-hidden';
  const variantClasses = getVariantClasses(variant);
  
  // Combine all classes
  const cardClasses = `${baseClasses} ${variantClasses} ${className}`;

  return (
    <div className={cardClasses} {...rest}>
      {children}
    </div>
  );
};

// Card Header
Card.Header = ({ children, className = '', ...rest }) => {
  return (
    <div className={`px-6 py-4 border-b border-gray-200 dark:border-gray-700 ${className}`} {...rest}>
      {children}
    </div>
  );
};

// Card Body
Card.Body = ({ children, className = '', ...rest }) => {
  return (
    <div className={`px-6 py-4 ${className}`} {...rest}>
      {children}
    </div>
  );
};

// Card Footer
Card.Footer = ({ children, className = '', ...rest }) => {
  return (
    <div className={`px-6 py-4 border-t border-gray-200 dark:border-gray-700 ${className}`} {...rest}>
      {children}
    </div>
  );
};

// Helper function to get Tailwind classes based on variants
const getVariantClasses = (variant) => {
  switch (variant) {
    case 'elevated':
      return 'bg-white dark:bg-gray-800 shadow-lg';
    case 'outlined':
      return 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700';
    case 'flat':
      return 'bg-white dark:bg-gray-800';
    default:
      return 'bg-white dark:bg-gray-800 shadow-md';
  }
};

export default Card;