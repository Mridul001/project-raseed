import { useTheme } from '@/hooks/useTheme.js';
import { MoonIcon, SunIcon } from "@/assets/svg/icons/icons.jsx";

const ThemeToggle = ({ className }) => {
    const { themeName, toggleTheme } = useTheme();

    // Determine if current theme is dark
    const isDark = themeName === 'dark';

    return (
        <div className={className}>
            <button
                onClick={toggleTheme}
                className="relative flex items-center w-16 h-8 rounded-full transition-colors duration-normal focus:outline-none bg-surface glass glass-border"
                aria-label={`Switch to ${isDark ? 'light' : 'dark'} mode`}
            >
                {/* Left side - Sun icon */}
                <div className="absolute left-1 top-1 w-6 h-6 flex items-center justify-center z-10">
                    <SunIcon
                        size={16}
                        filled={!isDark}
                        className={isDark ? 'text-content-tertiary' : 'text-foreground'}
                    />
                </div>

                {/* Right side - Moon icon */}
                <div className="absolute right-1 top-1 w-6 h-6 flex items-center justify-center z-10">
                    <MoonIcon
                        size={16}
                        filled={isDark}
                        className={isDark ? 'text-foreground' : 'text-content-tertiary'}
                    />
                </div>

                {/* Toggle circle */}
                <span
                    className={`absolute w-6 h-6 rounded-full bg-foreground shadow-md transform transition-transform duration-normal ${
                        isDark ? 'translate-x-9' : 'translate-x-1'
                    }`}
                ></span>
            </button>
        </div>
    );
};

export default ThemeToggle;
