import {BrowserRouter as Router, Routes, Route, Navigate} from 'react-router-dom';
import {Toaster} from 'react-hot-toast';
import {ThemeProvider} from './providers/ThemeProvider';
import {SidebarProvider} from './context/SidebarContext';
import {AuthProvider} from './context/AuthContext';
import {AnimationProvider} from './animations/AnimationProvider';
import ProtectedRoute from './components/ProtectedRoute';
import PublicRoute from './components/PublicRoute';
import Login from './pages/Auth/Login';
import routes from './routes/routes';
import './styles/index.css';
import './styles/fonts.css';
import NotFoundPage from "@/pages/notFoundPage/NotFoundPage.jsx";
import {ToastProvider} from "@/context/ToastContext.jsx";

// import NotFoundPage from "@/pages/notFoundPage/NotFoundPage.jsx";

function App() {
    // Separate public and protected routes from your routes configuration
    const publicRoutes = routes.filter(route => route.public);
    const protectedRoutes = routes.filter(route => !route.public);

    return (
        <Router>
            <AnimationProvider config={{
                respectReducedMotion: true,
                defaultEase: 'power2.out',
                defaultDuration: 0.4
            }}>
                <ThemeProvider>
                    <ToastProvider>
                        <AuthProvider>
                            <SidebarProvider>
                                <Toaster position="top-center"/>
                                <Routes>
                                    {/* Default route redirects to dashboard */}
                                    <Route path="/" element={<Navigate to="/home" replace/>}/>

                                    {/* Public Routes - Login and registration routes */}
                                    <Route element={<PublicRoute/>}>
                                        <Route path="/login" element={<Login/>}/>

                                        {/* Map additional public routes from routes.js */}
                                        {publicRoutes.map((route) => (
                                            <Route
                                                key={route.path}
                                                path={route.path}
                                                element={<route.element/>}
                                            />
                                        ))}
                                    </Route>

                                    {/* Protected Routes - All wrapped with Layout via ProtectedRoute */}
                                    <Route element={<ProtectedRoute/>}>
                                        {/* Map protected routes from routes.js */}
                                        {protectedRoutes.map((route) => (
                                            <Route
                                                key={route.path}
                                                path={route.path}
                                                element={<route.element/>}
                                            />
                                        ))}

                                        {/* Catch all route for 404 pages */}
                                        <Route path="*" element={
                                            <NotFoundPage/>
                                        }/>
                                    </Route>
                                </Routes>
                            </SidebarProvider>
                        </AuthProvider>
                    </ToastProvider>
                </ThemeProvider>
            </AnimationProvider>
        </Router>
    );
}

export default App;
