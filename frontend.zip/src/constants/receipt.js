export const CAMERA_CONSTRAINTS = {
    video: {
        width: { ideal: 1920 },
        height: { ideal: 1080 }
    }
};

export const CAPTURE_QUALITY = 0.9;
export const IMAGE_FORMAT = 'image/jpeg';
export const STORAGE_KEY = 'receipts';

// Enhanced UI configurations for better mobile experience
export const UI_CONFIG = {
    overlay: {
        // Clip path for the scanning overlay (creates the rectangular cutout)
        clipPath: 'polygon(0% 0%, 0% 100%, 20% 100%, 20% 15%, 80% 15%, 80% 100%, 100% 100%, 100% 0%)',
        opacity: 0.6
    },

    scanFrame: {
        aspectRatio: [3, 4], // Width:Height ratio for receipt frame
        borderWidth: 4,
        cornerSize: 32, // Size of corner indicators
    },

    buttons: {
        captureButton: {
            size: 80, // Main capture button size
            iconSize: 32
        },
        secondaryButton: {
            size: 56, // Gallery and history button size
            iconSize: 24
        }
    },

    zIndex: {
        video: 0,
        overlay: 20,
        controls: 40,
        header: 50
    }
};

// Animation configurations
export const ANIMATIONS = {
    scanLine: {
        duration: '2s',
        ease: 'ease-in-out'
    },

    buttonPress: {
        duration: '150ms',
        scale: {
            active: 0.95,
            hover: 1.05
        }
    }
};

// Error messages
export const ERROR_MESSAGES = {
    cameraNotSupported: 'Camera is not supported on this device',
    cameraPermissionDenied: 'Camera access denied. Please enable camera permissions.',
    captureFailure: 'Failed to capture image. Please try again.',
    uploadFailure: 'Upload failed. Please check your connection and try again.',
    fileNotSupported: 'File type not supported. Please select an image file.'
};
