const config = {

    backendApiUrl: import.meta.env.VITE_BACKEND_URL

};

export default config;
