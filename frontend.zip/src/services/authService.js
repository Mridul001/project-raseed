import api from '../utils/api';
import {cookies} from "@/utils/constants.js";

const COOKIE_NAME = cookies.baseCookie;

const authService = {

  login: async (email, password) => {
    try {
      // const response = await api.public.post('/auth/login', {
      //   email,
      //   password
      // });

      const response = {
        success: true,
        data: {
          token: "mock token",
          user: {
            id: 1,
            email: "shuklapriyanshu9@gmail.com",
            name: "Priyanshu",
            role: "admin",
            avatar: "https://avatars.dicebear.com/api/human/example.svg",
            createdAt: "2021-09-20T12:00:00.000Z",
            updatedAt: "2021-09-20T12:00:00.000Z"
          },
        },
      }

      // If login successful, save token in cookie
      if (response.success) {
        const cookieData = {
          token: response.data.token,
          user: response.data.user,
          expiry: response.data.tokenExpiry || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // Default 7 days if no expiry
        };

        // Set cookie with 7-day expiration by default
        document.cookie = `${COOKIE_NAME}=${JSON.stringify(cookieData)}; path=/; max-age=${7 * 24 * 60 * 60}`;
      }

      return response;
    } catch (error) {
      console.error("Login error:", error);
      throw error;
    }
  },

  logout: () => {
    // Simply clear the auth cookie
    document.cookie = `${COOKIE_NAME}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
    // Also clear with domain just to be safe
    document.cookie = `${COOKIE_NAME}=; path=/; domain=${window.location.hostname}; expires=Thu, 01 Jan 1970 00:00:00 GMT`;

    return true;
  },

  checkAuth: () => {
    if (typeof window === "undefined") return { isAuthenticated: false, user: null };

    try {
      const cookies = document.cookie.split(";");
      const tokenCookie = cookies.find((cookie) =>
        cookie.trim().startsWith(`${COOKIE_NAME}=`)
      );

      if (!tokenCookie) return { isAuthenticated: false, user: null };

      const tokenValue = decodeURIComponent(tokenCookie.split("=")[1].trim());
      const tokenData = JSON.parse(tokenValue);

      // Validate token data structure
      if (!tokenData.token || !tokenData.user) {
        return { isAuthenticated: false, user: null };
      }

      // Check if token is expired
      if (tokenData.expiry) {
        const expiryDate = new Date(tokenData.expiry);
        const now = new Date();

        if (expiryDate < now) {
          // Clear expired cookie
          document.cookie = `${COOKIE_NAME}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
          return { isAuthenticated: false, user: null, expired: true };
        }
      }

      return { isAuthenticated: true, user: tokenData.user, token: tokenData.token };
    } catch (error) {
      console.error("Error checking authentication:", error);
      return { isAuthenticated: false, user: null, error };
    }
  },

  getToken: () => {
    try {
      const { isAuthenticated, token } = authService.checkAuth();
      return isAuthenticated ? token : null;
    } catch (error) {
      console.error("Error getting token:", error);
      return null;
    }
  },

  clearAuthCookie: () => {
    document.cookie = `${COOKIE_NAME}=; Max-Age=0; path=/;`;
    document.cookie = `${COOKIE_NAME}=; path=/; domain=${window.location.hostname}; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
  }
};

export default authService;
