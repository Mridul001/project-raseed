import api from '../utils/api';

const chatService = {
    // Chat API for asking queries
    sendMessage: async (message, sessionId = null) => {
        try {
            // Prepare request payload
            const payload = {
                message: message
            };

            // Only include sessionId if it exists (not for the first message)
            if (sessionId) {
                payload.sessionId = sessionId;
            }

            // Make API call to send message
            const response = await api.post('/receipt/chat', payload);

            return {
                success: true,
                data: response,
            };
        } catch (error) {
            console.error("Chat message error:", error);

            // Return error response
            return {
                success: false,
                error: error.data?.message || error.statusText || 'Failed to send message',
                status: error.status || 500,
            };
        }
    },
    getInsights: async (message, sessionId = null) => {
        try {
            // Prepare request payload
            const payload = {
                message: message
            };

            // Only include sessionId if it exists (not for the first message)
            if (sessionId) {
                payload.sessionId = sessionId;
            }

            // Make API call to send message
            const response = await api.post('/receipt/chat?insight=true', payload);

            return {
                success: true,
                data: response,
            };
        } catch (error) {
            console.error("Chat message error:", error);

            // Return error response
            return {
                success: false,
                error: error.data?.message || error.statusText || 'Failed to send message',
                status: error.status || 500,
            };
        }
    }
};

export default chatService;
