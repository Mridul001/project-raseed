// receiptService.js - Updated to use api interceptor

import api from '../utils/api';

const receiptService = {

    async uploadReceipt(file, notes = '') {
        try {
            const formData = new FormData();
            formData.append('receipt', file);

            if (notes.trim()) {
                formData.append('notes', notes.trim());
            }

            const response = await api.post('/receipt/upload', formData);

            return {
                success: true,
                data: response.data || response
            };

        } catch (error) {
            console.error('Receipt upload failed:', error);
            return {
                success: false,
                error: error.data?.message || error.statusText || 'Failed to upload receipt',
                status: error.status || 500
            };
        }
    },

    async generatePass(receiptData) {
        try {
            const payload = {
                category: receiptData.category,
                vendor: receiptData.vendor,
                items: receiptData.items,
                id: receiptData.id
            };

            const response = await api.post('/receipt/generatePass', payload);

            return {
                success: true,
                objectId: response.objectId,
                walletLink: response.walletLink,
                message: response.message
            };

        } catch (error) {
            console.error('Wallet pass generation failed:', error);
            return {
                success: false,
                error: error.data?.message || error.statusText || 'Failed to generate wallet pass',
                status: error.status || 500
            };
        }
    },

    async generateInsightsPass(insights) {
        try {
            // Format insights for the pass - each insight as "• title - content"
            const formattedInsights = insights.map(insight =>
                `• ${insight.title} - ${insight.insight}`
            ).join('\n');

            const payload = {
                id: "1234",
                passData: {
                    objectData: {
                        cardTitle: "Insights",
                        header: "Your Insights",
                        textModuleHeader: "Here are your insights based on your expenses",
                        textModuleBody: formattedInsights,
                        barcodeValue: "https://random-cc7fb.web.app/login",
                        backgroundColor: "#1976d2"
                    }
                }
            };

            const response = await api.post('/receipt/pass/edit-or-create?insight=true', payload);

            return {
                success: true,
                data: response.data || response
            };

        } catch (error) {
            console.error('Insights pass generation failed:', error);
            return {
                success: false,
                error: error.data?.message || error.statusText || 'Failed to generate insights pass',
                status: error.status || 500
            };
        }
    },
};

export default receiptService;
