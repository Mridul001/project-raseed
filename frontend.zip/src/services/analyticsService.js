import api from '../utils/api';

const analyticsService = {
    // Get monthly category-wise expenses
    getMonthlyCategoryData: async () => {
        try {
            const response = await api.get('/receipt/analytics/monthly-category-wise-total');

            return {
                success: true,
                data: response,
            };
        } catch (error) {
            console.error("Analytics data fetch error:", error);

            return {
                success: false,
                error: error.data?.message || error.statusText || 'Failed to fetch analytics data',
                status: error.status || 500,
            };
        }
    },

    // Process raw data for charts and calculations
    processAnalyticsData: (rawData) => {
        if (!rawData || !rawData.data) {
            return {
                monthlyData: [],
                categoryTotals: {},
                totalExpenses: 0,
                monthlyTotals: [],
                categoryBreakdown: []
            };
        }

        const data = rawData.data;
        const monthlyData = [];
        const categoryTotals = {};
        const monthlyTotals = [];
        let totalExpenses = 0;

        // Sort months chronologically
        const sortedMonths = Object.keys(data).sort((a, b) => {
            const [yearA, monthA] = a.split('-').map(Number);
            const [yearB, monthB] = b.split('-').map(Number);
            return yearA - yearB || monthA - monthB;
        });

        // Process each month
        sortedMonths.forEach(month => {
            const monthData = data[month];
            const monthTotal = Object.values(monthData).reduce((sum, amount) => sum + amount, 0);

            // Format month for display
            const [year, monthNum] = month.split('-');
            const monthName = new Date(year, monthNum - 1).toLocaleDateString('en-IN', {
                month: 'short',
                year: 'numeric'
            });

            // Build monthly data for line chart
            const monthEntry = {
                month: monthName,
                rawMonth: month,
                total: monthTotal,
                ...monthData
            };

            monthlyData.push(monthEntry);
            monthlyTotals.push({ month: monthName, total: monthTotal });

            // Accumulate category totals
            Object.entries(monthData).forEach(([category, amount]) => {
                categoryTotals[category] = (categoryTotals[category] || 0) + amount;
                totalExpenses += amount;
            });
        });

        // Create category breakdown for pie chart
        const categoryBreakdown = Object.entries(categoryTotals).map(([category, total]) => ({
            name: category,
            value: total,
            percentage: ((total / totalExpenses) * 100).toFixed(1)
        })).sort((a, b) => b.value - a.value);

        return {
            monthlyData,
            categoryTotals,
            totalExpenses,
            monthlyTotals,
            categoryBreakdown,
            totalMonths: sortedMonths.length,
            averageMonthlySpend: totalExpenses / sortedMonths.length || 0,
            highestSpendingCategory: categoryBreakdown[0]?.name || 'N/A',
            highestSpendingMonth: monthlyTotals.reduce((max, current) =>
                    current.total > max.total ? current : max,
                { month: 'N/A', total: 0 }
            )
        };
    },

    // Filter data by date range
    filterDataByDateRange: (processedData, range) => {
        const { monthlyData } = processedData;

        if (range === 'all' || !monthlyData.length) {
            return processedData;
        }

        const now = new Date();
        let startDate;

        switch (range) {
            case '3m':
                startDate = new Date(now.getFullYear(), now.getMonth() - 3, 1);
                break;
            case '6m':
                startDate = new Date(now.getFullYear(), now.getMonth() - 6, 1);
                break;
            case '1y':
                startDate = new Date(now.getFullYear() - 1, now.getMonth(), 1);
                break;
            default:
                return processedData;
        }

        const filteredMonthlyData = monthlyData.filter(item => {
            const [year, month] = item.rawMonth.split('-').map(Number);
            const itemDate = new Date(year, month - 1, 1);
            return itemDate >= startDate;
        });

        // Recalculate totals for filtered data
        return analyticsService.processAnalyticsData({ data:
                filteredMonthlyData.reduce((acc, item) => {
                    const { month, rawMonth, total, ...categories } = item;
                    acc[rawMonth] = categories;
                    return acc;
                }, {})
        });
    },

    // Format currency for display
    formatCurrency: (amount) => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    },

    // Format large numbers
    formatNumber: (number) => {
        if (number >= 10000000) {
            return (number / 10000000).toFixed(1) + 'Cr';
        } else if (number >= 100000) {
            return (number / 100000).toFixed(1) + 'L';
        } else if (number >= 1000) {
            return (number / 1000).toFixed(1) + 'K';
        }
        return number.toFixed(0);
    }
};

export default analyticsService;
