const cookies = {

    baseCookie: "admin-auth-token"

};

export {cookies};
