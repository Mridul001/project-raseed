// receiptStorage.js - Enhanced with IndexedDB, compression, and quota management

const DB_NAME = 'ReceiptStorage';
const DB_VERSION = 1;
const RECEIPT_STORE = 'receipts';
const FALLBACK_STORAGE_KEY = 'receipts_metadata';

// Compression settings
const IMAGE_QUALITY = 0.8; // JPEG quality (0.1 - 1.0)
const MAX_IMAGE_WIDTH = 1200; // Max width for compression
const MAX_IMAGE_HEIGHT = 1600; // Max height for compression

/**
 * Initialize IndexedDB
 */
const initDB = () => {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onerror = () => {
            console.error('Failed to open IndexedDB:', request.error);
            reject(request.error);
        };

        request.onsuccess = () => {
            resolve(request.result);
        };

        request.onupgradeneeded = (event) => {
            const db = event.target.result;

            // Create receipts store if it doesn't exist
            if (!db.objectStoreNames.contains(RECEIPT_STORE)) {
                const store = db.createObjectStore(RECEIPT_STORE, { keyPath: 'id' });
                store.createIndex('capturedAt', 'capturedAt', { unique: false });
                store.createIndex('imageCount', 'imageCount', { unique: false });
            }
        };
    });
};

/**
 * Compress image file to reduce storage space
 */
const compressImage = (file) => {
    return new Promise((resolve, reject) => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const img = new Image();

        img.onload = () => {
            // Calculate new dimensions
            let { width, height } = img;

            if (width > MAX_IMAGE_WIDTH || height > MAX_IMAGE_HEIGHT) {
                const ratio = Math.min(MAX_IMAGE_WIDTH / width, MAX_IMAGE_HEIGHT / height);
                width *= ratio;
                height *= ratio;
            }

            canvas.width = width;
            canvas.height = height;

            // Draw and compress
            ctx.drawImage(img, 0, 0, width, height);

            canvas.toBlob(
                (blob) => {
                    if (blob) {
                        // Convert to base64 for storage
                        const reader = new FileReader();
                        reader.onload = () => resolve(reader.result);
                        reader.onerror = reject;
                        reader.readAsDataURL(blob);
                    } else {
                        reject(new Error('Failed to compress image'));
                    }
                },
                'image/jpeg',
                IMAGE_QUALITY
            );
        };

        img.onerror = reject;
        img.src = URL.createObjectURL(file);
    });
};

/**
 * Generate a unique ID for a receipt
 */
const generateReceiptId = () => {
    return `receipt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

/**
 * Migrate data from localStorage to IndexedDB
 */
const migrateFromLocalStorage = async () => {
    try {
        const oldData = localStorage.getItem('receipts');
        if (!oldData) return;

        const receipts = JSON.parse(oldData);
        if (receipts.length === 0) return;

        console.log(`Migrating ${receipts.length} receipts from localStorage to IndexedDB...`);

        const db = await initDB();
        const transaction = db.transaction([RECEIPT_STORE], 'readwrite');
        const store = transaction.objectStore(RECEIPT_STORE);

        // Check if any data already exists
        const existingCount = await new Promise((resolve, reject) => {
            const countRequest = store.count();
            countRequest.onsuccess = () => resolve(countRequest.result);
            countRequest.onerror = () => reject(countRequest.error);
        });

        if (existingCount > 0) {
            console.log('IndexedDB already has data, skipping migration');
            return;
        }

        // Migrate each receipt
        for (const receipt of receipts) {
            const migratedReceipt = {
                ...receipt,
                migratedFromLocalStorage: true,
                migratedAt: new Date().toISOString()
            };

            await new Promise((resolve, reject) => {
                const request = store.add(migratedReceipt);
                request.onsuccess = () => resolve();
                request.onerror = () => reject(request.error);
            });
        }

        // Backup old data and clear localStorage
        localStorage.setItem('receipts_backup', oldData);
        localStorage.removeItem('receipts');

        console.log('Migration completed successfully');
    } catch (error) {
        console.error('Migration failed:', error);
        // Don't throw - app should still work with localStorage fallback
    }
};

/**
 * Save to fallback localStorage (metadata only)
 */
const saveToFallbackStorage = (receipt) => {
    try {
        const fallbackReceipts = getFallbackReceipts();
        const metadataOnly = {
            ...receipt,
            images: [], // Remove images for metadata-only storage
            fallbackStorage: true,
            storageError: 'Images stored in IndexedDB'
        };

        fallbackReceipts.unshift(metadataOnly);

        // Keep only last 50 for fallback
        if (fallbackReceipts.length > 50) {
            fallbackReceipts.splice(50);
        }

        localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(fallbackReceipts));
        return metadataOnly;
    } catch (error) {
        console.error('Fallback storage failed:', error);
        throw error;
    }
};

/**
 * Get fallback receipts from localStorage
 */
const getFallbackReceipts = () => {
    try {
        const data = localStorage.getItem(FALLBACK_STORAGE_KEY);
        return data ? JSON.parse(data) : [];
    } catch (error) {
        console.error('Failed to get fallback receipts:', error);
        return [];
    }
};

/**
 * Save single receipt to storage with compression
 */
export const saveReceiptToStorage = async (file) => {
    try {
        // Compress the image first
        const compressedImage = await compressImage(file);

        const receipt = {
            id: generateReceiptId(),
            images: [compressedImage],
            filenames: [file.name],
            sizes: [file.size],
            compressedSizes: [compressedImage.length],
            capturedAt: new Date().toISOString(),
            imageCount: 1,
            compressed: true
        };

        // Try IndexedDB first
        try {
            const db = await initDB();
            const transaction = db.transaction([RECEIPT_STORE], 'readwrite');
            const store = transaction.objectStore(RECEIPT_STORE);

            await new Promise((resolve, reject) => {
                const request = store.add(receipt);
                request.onsuccess = () => resolve();
                request.onerror = () => reject(request.error);
            });

            return receipt;
        } catch (dbError) {
            console.warn('IndexedDB save failed, using fallback:', dbError);
            return saveToFallbackStorage(receipt);
        }
    } catch (error) {
        console.error('Failed to save receipt:', error);
        throw new Error(`Failed to save receipt: ${error.message}`);
    }
};

/**
 * Save multiple receipts as a single batch entry with compression
 */
export const saveReceiptBatchToStorage = async (files, notes = '') => {
    try {
        // Compress all images
        const compressedImages = await Promise.all(
            files.map(file => compressImage(file))
        );

        const receipt = {
            id: generateReceiptId(),
            images: compressedImages,
            filenames: files.map(file => file.name),
            sizes: files.map(file => file.size),
            compressedSizes: compressedImages.map(img => img.length),
            totalSize: files.reduce((sum, file) => sum + file.size, 0),
            totalCompressedSize: compressedImages.reduce((sum, img) => sum + img.length, 0),
            capturedAt: new Date().toISOString(),
            imageCount: files.length,
            notes: notes.trim() || null,
            type: 'batch',
            compressed: true
        };

        // Try IndexedDB first
        try {
            const db = await initDB();
            const transaction = db.transaction([RECEIPT_STORE], 'readwrite');
            const store = transaction.objectStore(RECEIPT_STORE);

            await new Promise((resolve, reject) => {
                const request = store.add(receipt);
                request.onsuccess = () => resolve();
                request.onerror = () => reject(request.error);
            });

            return receipt;
        } catch (dbError) {
            console.warn('IndexedDB batch save failed, using fallback:', dbError);
            return saveToFallbackStorage(receipt);
        }
    } catch (error) {
        console.error('Failed to save receipt batch:', error);
        throw new Error(`Failed to save receipt batch: ${error.message}`);
    }
};

/**
 * Get all receipts from storage
 */
export const getReceiptsFromStorage = async () => {
    try {
        // Try migration first
        await migrateFromLocalStorage();

        // Try IndexedDB first
        try {
            const db = await initDB();
            const transaction = db.transaction([RECEIPT_STORE], 'readonly');
            const store = transaction.objectStore(RECEIPT_STORE);
            const index = store.index('capturedAt');

            const receipts = await new Promise((resolve, reject) => {
                const request = index.getAll();
                request.onsuccess = () => {
                    // Sort by capturedAt descending (newest first)
                    const sorted = request.result.sort((a, b) =>
                        new Date(b.capturedAt) - new Date(a.capturedAt)
                    );
                    resolve(sorted);
                };
                request.onerror = () => reject(request.error);
            });

            // Migrate old format receipts if needed
            return receipts.map(receipt => {
                if (receipt.image && !receipt.images) {
                    return {
                        ...receipt,
                        images: [receipt.image],
                        filenames: [receipt.filename || 'receipt.jpg'],
                        sizes: [receipt.size || 0],
                        imageCount: 1,
                        image: undefined,
                        filename: undefined,
                        size: undefined
                    };
                }
                return receipt;
            }).filter(receipt => receipt.images && receipt.images.length > 0);

        } catch (dbError) {
            console.warn('IndexedDB read failed, using fallback:', dbError);
            return getFallbackReceipts();
        }
    } catch (error) {
        console.error('Failed to get receipts from storage:', error);
        return [];
    }
};

/**
 * Delete receipt from storage
 */
export const deleteReceiptFromStorage = async (id) => {
    try {
        // Try IndexedDB first
        try {
            const db = await initDB();
            const transaction = db.transaction([RECEIPT_STORE], 'readwrite');
            const store = transaction.objectStore(RECEIPT_STORE);

            await new Promise((resolve, reject) => {
                const request = store.delete(id);
                request.onsuccess = () => resolve();
                request.onerror = () => reject(request.error);
            });
        } catch (dbError) {
            console.warn('IndexedDB delete failed, trying fallback:', dbError);

            // Fallback: remove from localStorage metadata
            const fallbackReceipts = getFallbackReceipts();
            const updatedReceipts = fallbackReceipts.filter(receipt => receipt.id !== id);
            localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(updatedReceipts));
        }

        return await getReceiptsFromStorage();
    } catch (error) {
        console.error('Failed to delete receipt:', error);
        return await getReceiptsFromStorage();
    }
};

/**
 * Update receipt in storage
 */
export const updateReceiptInStorage = async (id, updates) => {
    try {
        // Try IndexedDB first
        try {
            const db = await initDB();
            const transaction = db.transaction([RECEIPT_STORE], 'readwrite');
            const store = transaction.objectStore(RECEIPT_STORE);

            // Get existing receipt
            const existing = await new Promise((resolve, reject) => {
                const request = store.get(id);
                request.onsuccess = () => resolve(request.result);
                request.onerror = () => reject(request.error);
            });

            if (existing) {
                const updated = { ...existing, ...updates };
                await new Promise((resolve, reject) => {
                    const request = store.put(updated);
                    request.onsuccess = () => resolve();
                    request.onerror = () => reject(request.error);
                });
            }
        } catch (dbError) {
            console.warn('IndexedDB update failed, trying fallback:', dbError);

            // Fallback: update in localStorage metadata
            const fallbackReceipts = getFallbackReceipts();
            const updatedReceipts = fallbackReceipts.map(receipt =>
                receipt.id === id ? { ...receipt, ...updates } : receipt
            );
            localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(updatedReceipts));
        }

        return await getReceiptsFromStorage();
    } catch (error) {
        console.error('Failed to update receipt:', error);
        return await getReceiptsFromStorage();
    }
};

/**
 * Get storage usage information
 */
export const getStorageInfo = async () => {
    try {
        const receipts = await getReceiptsFromStorage();
        const totalReceipts = receipts.length;
        const totalImages = receipts.reduce((sum, receipt) => sum + (receipt.imageCount || 1), 0);

        // Calculate sizes
        const totalOriginalSize = receipts.reduce((sum, receipt) => {
            if (receipt.totalSize) return sum + receipt.totalSize;
            if (receipt.sizes) return sum + receipt.sizes.reduce((s, size) => s + size, 0);
            return sum + (receipt.size || 0);
        }, 0);

        const totalCompressedSize = receipts.reduce((sum, receipt) => {
            if (receipt.totalCompressedSize) return sum + receipt.totalCompressedSize;
            if (receipt.compressedSizes) return sum + receipt.compressedSizes.reduce((s, size) => s + size, 0);
            return sum;
        }, 0);

        const compressionRatio = totalOriginalSize > 0 ?
            ((totalOriginalSize - totalCompressedSize) / totalOriginalSize * 100).toFixed(1) : 0;

        // Check storage quota if available
        let storageQuota = null;
        if ('storage' in navigator && 'estimate' in navigator.storage) {
            try {
                const estimate = await navigator.storage.estimate();
                storageQuota = {
                    used: estimate.usage,
                    total: estimate.quota,
                    available: estimate.quota - estimate.usage,
                    usedPercentage: ((estimate.usage / estimate.quota) * 100).toFixed(1)
                };
            } catch (error) {
                console.warn('Failed to get storage estimate:', error);
            }
        }

        return {
            totalReceipts,
            totalImages,
            totalOriginalSize,
            totalCompressedSize,
            compressionRatio: parseFloat(compressionRatio),
            averageImagesPerReceipt: totalReceipts > 0 ? (totalImages / totalReceipts).toFixed(1) : 0,
            storageQuota,
            usingIndexedDB: true
        };
    } catch (error) {
        console.error('Failed to get storage info:', error);
        return {
            totalReceipts: 0,
            totalImages: 0,
            totalOriginalSize: 0,
            totalCompressedSize: 0,
            compressionRatio: 0,
            averageImagesPerReceipt: 0,
            storageQuota: null,
            usingIndexedDB: false
        };
    }
};

/**
 * Clear all storage (for debugging/reset)
 */
export const clearAllStorage = async () => {
    try {
        // Clear IndexedDB
        try {
            const db = await initDB();
            const transaction = db.transaction([RECEIPT_STORE], 'readwrite');
            const store = transaction.objectStore(RECEIPT_STORE);
            await new Promise((resolve, reject) => {
                const request = store.clear();
                request.onsuccess = () => resolve();
                request.onerror = () => reject(request.error);
            });
        } catch (dbError) {
            console.warn('Failed to clear IndexedDB:', dbError);
        }

        // Clear localStorage
        localStorage.removeItem('receipts');
        localStorage.removeItem(FALLBACK_STORAGE_KEY);
        localStorage.removeItem('receipts_backup');

        console.log('All storage cleared');
    } catch (error) {
        console.error('Failed to clear storage:', error);
        throw error;
    }
};
