import { CAMERA_CONSTRAINTS, CAPTURE_QUALITY, IMAGE_FORMAT, ERROR_MESSAGES } from '@/constants/receipt.js';

/**
 * Initialize camera with given constraints
 * @param {Object} options - Camera options
 * @returns {Promise<MediaStream>} Camera stream
 */
export const initializeCamera = async (options = {}) => {
    const {
        facingMode = 'environment',
        flashEnabled = false
    } = options;

    // Check if camera is supported
    if (!isCameraSupported()) {
        throw new Error(ERROR_MESSAGES.cameraNotSupported);
    }

    const constraints = {
        video: {
            ...CAMERA_CONSTRAINTS.video,
            facingMode: facingMode
        }
    };

    // Add flash constraint if supported and enabled
    if (flashEnabled && await isFlashSupported()) {
        constraints.video.torch = true;
    }

    try {
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        return stream;
    } catch (error) {
        console.error('Camera initialization error:', error);

        // Provide more specific error messages
        if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
            throw new Error(ERROR_MESSAGES.cameraPermissionDenied);
        } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
            throw new Error('No camera found on this device.');
        } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
            throw new Error('Camera is already in use by another application.');
        } else {
            throw new Error(ERROR_MESSAGES.cameraNotSupported);
        }
    }
};

/**
 * Cleanup camera stream
 * @param {MediaStream} stream - Camera stream to cleanup
 */
export const cleanupCamera = (stream) => {
    if (stream && stream.getTracks) {
        stream.getTracks().forEach(track => {
            if (track.readyState === 'live') {
                track.stop();
            }
        });
    }
};

/**
 * Capture image from video element
 * @param {HTMLVideoElement} videoElement - Video element
 * @param {HTMLCanvasElement} canvasElement - Canvas element
 * @returns {Promise<File>} Captured image file
 */
export const captureImageFromVideo = (videoElement, canvasElement) => {
    return new Promise((resolve, reject) => {
        try {
            if (!videoElement || !canvasElement) {
                throw new Error('Video or canvas element not available');
            }

            if (videoElement.videoWidth === 0 || videoElement.videoHeight === 0) {
                throw new Error('Video not ready for capture');
            }

            const context = canvasElement.getContext('2d');

            // Set canvas dimensions to match video
            canvasElement.width = videoElement.videoWidth;
            canvasElement.height = videoElement.videoHeight;

            // Draw video frame to canvas
            context.drawImage(videoElement, 0, 0);

            // Convert to blob and create file
            canvasElement.toBlob((blob) => {
                if (!blob) {
                    reject(new Error(ERROR_MESSAGES.captureFailure));
                    return;
                }

                const file = new File([blob], `receipt-${Date.now()}.jpg`, {
                    type: IMAGE_FORMAT,
                    lastModified: Date.now()
                });
                resolve(file);
            }, IMAGE_FORMAT, CAPTURE_QUALITY);

        } catch (error) {
            console.error('Capture error:', error);
            reject(new Error(ERROR_MESSAGES.captureFailure));
        }
    });
};

/**
 * Check if camera is supported
 * @returns {boolean} True if camera is supported
 */
export const isCameraSupported = () => {
    return !!(
        navigator.mediaDevices &&
        navigator.mediaDevices.getUserMedia &&
        typeof navigator.mediaDevices.getUserMedia === 'function'
    );
};

/**
 * Check if flash/torch is supported
 * @returns {Promise<boolean>} True if flash is supported
 */
export const isFlashSupported = async () => {
    try {
        if (!isCameraSupported()) return false;

        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = devices.filter(device => device.kind === 'videoinput');

        // Check if any video device supports torch
        for (const device of videoDevices) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({
                    video: { deviceId: device.deviceId, torch: true }
                });
                const track = stream.getVideoTracks()[0];
                const capabilities = track.getCapabilities();

                // Cleanup
                track.stop();

                if (capabilities.torch) {
                    return true;
                }
            } catch (e) {
                // Continue checking other devices
                continue;
            }
        }

        return false;
    } catch (error) {
        console.error('Error checking flash support:', error);
        return false;
    }
};

/**
 * Get available camera devices
 * @returns {Promise<Array>} Array of camera devices
 */
export const getAvailableCameras = async () => {
    try {
        if (!isCameraSupported()) return [];

        const devices = await navigator.mediaDevices.enumerateDevices();
        return devices
            .filter(device => device.kind === 'videoinput')
            .map(device => ({
                deviceId: device.deviceId,
                label: device.label || `Camera ${device.deviceId.slice(0, 8)}`,
                facingMode: device.label.toLowerCase().includes('front') ? 'user' : 'environment'
            }));
    } catch (error) {
        console.error('Error getting camera devices:', error);
        return [];
    }
};

/**
 * Validate image file
 * @param {File} file - File to validate
 * @returns {boolean} True if file is valid
 */
export const validateImageFile = (file) => {
    if (!file) return false;

    // Check file type
    if (!file.type.startsWith('image/')) {
        throw new Error(ERROR_MESSAGES.fileNotSupported);
    }

    // Check file size (max 10MB)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
        throw new Error('File size too large. Please select an image under 10MB.');
    }

    return true;
};

/**
 * Get device orientation
 * @returns {string} Device orientation
 */
export const getDeviceOrientation = () => {
    if (screen.orientation) {
        return screen.orientation.angle === 0 || screen.orientation.angle === 180
            ? 'portrait'
            : 'landscape';
    }

    // Fallback for older browsers
    return window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
};
