import axios from 'axios';
import toast from 'react-hot-toast';
import config from "@/config/config.js";

const API_BASE_URL = config.backendApiUrl;

// Track if we've already shown the toast to prevent multiple toasts
let authErrorToastShown = false;

// Function to show toast and redirect to login
export const redirectToLogin = () => {
  if (window.location.pathname !== '/login') {
    // Show a toast message and then redirect
    toast.error('Session expired. Please log in again.', {
      duration: 1500 // 1.5 seconds
    });

    // Redirect after a short delay to allow toast to be seen
    setTimeout(() => {
      window.location.href = '/login';
    }, 1000); // 1 second delay
  }
};

// This function will be replaced after authService is imported
// to avoid circular dependency
let getTokenFromCookies = () => {
  const COOKIE_NAME = "admin-auth-token";
  try {
    const cookies = document.cookie.split(";");
    const tokenCookie = cookies.find((cookie) =>
        cookie.trim().startsWith(`${COOKIE_NAME}=`)
    );

    if (!tokenCookie) return null;

    const tokenValue = decodeURIComponent(tokenCookie.split("=")[1].trim());
    const tokenData = JSON.parse(tokenValue);

    // Check expiry
    if (tokenData.expiry && new Date(tokenData.expiry) < new Date()) {
      return null;
    }

    return tokenData.token;
  } catch (error) {
    console.error("Error getting token:", error);
    return null;
  }
};

// Create axios instance with base configuration
const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000, // 30 seconds timeout
});

// Request interceptor to add auth headers
axiosInstance.interceptors.request.use(
    (config) => {
      // Don't add auth headers if skipAuth is set
      if (!config.skipAuth) {
        const token = getTokenFromCookies();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
      }

      // Log request for debugging in development
      if (import.meta.env.DEV) {
        console.debug(`API Request to ${config.url}`, {
          method: config.method?.toUpperCase(),
          headers: config.headers,
          data: config.data instanceof FormData ? 'FormData' : config.data
        });
      }

      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
);

// Response interceptor to handle errors
axiosInstance.interceptors.response.use(
    (response) => {
      // Return just the data for successful responses
      return response.data;
    },
    (error) => {
      console.error('API request failed:', error);

      // Handle authentication errors (401 Unauthorized or 403 Forbidden)
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        console.error(`Authentication error: ${error.response.status} ${error.response.statusText}`);

        // Don't redirect or clear cookies for login-related endpoints
        const isAuthEndpoint = error.config.url.includes('/auth/') ||
            error.config.url.includes('/login') ||
            error.config.url.includes('/register');

        if (!isAuthEndpoint && !error.config.skipAuth && !authErrorToastShown) {
          authErrorToastShown = true; // Prevent multiple toasts

          // Import authService dynamically to avoid circular dependency
          import('../services/authService').then(module => {
            const authService = module.default;
            authService.clearAuthCookie();
            redirectToLogin();
          });

          // Reset the toast flag after some time
          setTimeout(() => {
            authErrorToastShown = false;
          }, 5000);

          return Promise.reject({
            status: error.response.status,
            statusText: error.response.statusText,
            data: { message: 'Authentication failed. Please log in again.' }
          });
        }
      }

      // Format error for consistent handling
      const formattedError = {
        status: error.response?.status || 500,
        statusText: error.response?.statusText || 'Unknown Error',
        data: error.response?.data || { message: error.message || 'Request failed' }
      };

      return Promise.reject(formattedError);
    }
);

// Function to create headers (kept for backward compatibility)
export const createHeaders = (additionalHeaders = {}, isFormData = false) => {
  const headers = {
    ...additionalHeaders
  };

  // Only add Content-Type for non-FormData requests
  if (!isFormData) {
    headers['Content-Type'] = 'application/json';
  }

  const token = getTokenFromCookies();
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  return headers;
};

// Main API request function using axios
export const apiRequest = async (endpoint, options = {}) => {
  const { skipAuth, isFormData, ...axiosOptions } = options;

  try {
    const config = {
      url: endpoint,
      skipAuth,
      ...axiosOptions
    };

    // Set Content-Type for non-FormData requests
    if (!isFormData && axiosOptions.data && !(axiosOptions.data instanceof FormData)) {
      config.headers = {
        'Content-Type': 'application/json',
        ...(axiosOptions.headers || {})
      };
    }

    const response = await axiosInstance(config);
    return response;
  } catch (error) {
    throw error;
  }
};

// Reset the toast flag after some time to allow future toasts
// This prevents the flag from being stuck if for some reason the page doesn't reload
setTimeout(() => {
  authErrorToastShown = false;
}, 5000); // Reset after 5 seconds

// API object with methods for different HTTP operations
export const api = {
  get: (endpoint, options = {}) =>
      apiRequest(endpoint, { ...options, method: 'GET' }),

  post: (endpoint, data, options = {}) => {
    const isFormData = data instanceof FormData;
    return apiRequest(endpoint, {
      ...options,
      method: 'POST',
      data,
      isFormData
    });
  },

  put: (endpoint, data, options = {}) => {
    const isFormData = data instanceof FormData;
    return apiRequest(endpoint, {
      ...options,
      method: 'PUT',
      data,
      isFormData
    });
  },

  patch: (endpoint, data, options = {}) => {
    const isFormData = data instanceof FormData;
    return apiRequest(endpoint, {
      ...options,
      method: 'PATCH',
      data,
      isFormData
    });
  },

  delete: (endpoint, options = {}) =>
      apiRequest(endpoint, { ...options, method: 'DELETE' }),

  public: {
    get: (endpoint, options = {}) =>
        apiRequest(endpoint, { ...options, method: 'GET', skipAuth: true }),

    post: (endpoint, data, options = {}) => {
      const isFormData = data instanceof FormData;
      return apiRequest(endpoint, {
        ...options,
        method: 'POST',
        data,
        skipAuth: true,
        isFormData
      });
    },

    put: (endpoint, data, options = {}) => {
      const isFormData = data instanceof FormData;
      return apiRequest(endpoint, {
        ...options,
        method: 'PUT',
        data,
        skipAuth: true,
        isFormData
      });
    },

    patch: (endpoint, data, options = {}) => {
      const isFormData = data instanceof FormData;
      return apiRequest(endpoint, {
        ...options,
        method: 'PATCH',
        data,
        skipAuth: true,
        isFormData
      });
    },

    delete: (endpoint, options = {}) =>
        apiRequest(endpoint, { ...options, method: 'DELETE', skipAuth: true })
  }
};

// Setup function to initialize with authService
// Call this after authService is imported to avoid circular dependencies
export const setupApiWithAuthService = (service) => {
  if (service && typeof service.getToken === 'function') {
    getTokenFromCookies = service.getToken;
  }
};

export default api;
