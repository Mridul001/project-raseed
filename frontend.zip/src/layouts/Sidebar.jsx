import { useSidebar } from "../hooks/useSidebar";
import { useEffect, useState, useRef } from "react";
import { useLocation, Link } from "react-router-dom";
import { gsap } from "gsap";
import { useAnimationContext } from "@/animations/AnimationProvider";
import {
  HomeIcon,
  MenuIcon,
  ArrowLeftIcon,
  HelpIcon,
  LogoutIcon, ChatIcon
} from "@/assets/svg/icons/icons.jsx";
import {HistoryIcon, ScanIcon, ShoppingBagIcon, ChartColumnStacked} from "lucide-react";

// Updated menu items with sections to match the image
const menuSections = [
  {
    title: "Pages",
    items: [
      {
        title: "Home",
        icon: (active) => <HomeIcon size={20} filled={active} />,
        path: "/home",
        badge: null
      },
      {
        title: "Scan Receipt",
        icon: (active) => <ScanIcon size={20} filled={active} />,
        path: "/scan-receipt",
        badge: null
      },
      {
        title: "Ask Queries",
        icon: (active) => <ChatIcon size={20} filled={active} />,
        path: "/ask-queries",
        badge: null
      },
      {
        title: "History",
        icon: (active) => <HistoryIcon size={20} filled={active} />,
        path: "/history",
        badge: null
      },
      {
        title: "Shopping List",
        icon: (active) => <ShoppingBagIcon size={20} filled={active} />,
        path: "/shopping-list",
        badge: null
      },
      {
        title: "Analytics",
        icon: (active) => <ChartColumnStacked size={20} filled={active} />,
        path: "/stats",
        badge: null
      }
    ]
  }
];

// Footer menu items separated from main menu to match the image
const footerItems = [
  {
    title: "Help",
    icon: (active) => <HelpIcon size={20} filled={active} />,
    path: "/help",
    badge: null
  },
  {
    title: "Logout",
    icon: (active) => <LogoutIcon size={20} filled={active} />,
    path: "/logout",
    badge: null
  }
];

const Sidebar = () => {
  const { isOpen, setIsOpen, toggleSidebar } = useSidebar();
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const location = useLocation();
  const [activeItem, setActiveItem] = useState(location.pathname);
  const { isEnabled } = useAnimationContext();

  // Refs for animation targets
  const sidebarRef = useRef(null);
  const [animating, setAnimating] = useState(false);
  const [hasAnimatedOnce, setHasAnimatedOnce] = useState(false);

  // Handle sidebar animation
  useEffect(() => {
    if (!sidebarRef.current || !isEnabled) return;

    setAnimating(true);

    // Create GSAP timeline for better synchronization
    const tl = gsap.timeline({
      onComplete: () => setAnimating(false)
    });

    // Create GSAP context for automatic cleanup
    const ctx = gsap.context(() => {
      if (isOpen) {
        // When opening
        // 1. First set the sidebar width instantly
        gsap.set(sidebarRef.current, {
          width: isMobile ? "16rem" : "16rem"
        });

        // 2. Get all menu items
        const menuItems = document.querySelectorAll('.sidebar-menu-content');

        // 3. Animate both icons and text together
        if (menuItems.length > 0) {
          tl.fromTo(menuItems,
              { opacity: 0, x: -10 },
              {
                opacity: 1,
                x: 0,
                duration: 0.3,
                stagger: 0.03,
                ease: "power1.out"
              }
          );
        }
      } else {
        // When closing - just animate the sidebar width
        tl.to(sidebarRef.current, {
          width: isMobile ? "0rem" : "4rem",
          duration: 0.3,
          ease: "power2.inOut"
        });
      }
    }, sidebarRef);

    // Set that we've animated at least once
    if (!hasAnimatedOnce) {
      setHasAnimatedOnce(true);
    }

    // Return cleanup function
    return () => {
      ctx.revert();
      setAnimating(false);
    };
  }, [isOpen, isMobile, isEnabled]);

  // Initial load animation
  useEffect(() => {
    if (!sidebarRef.current || !isEnabled || hasAnimatedOnce) return;

    // Create GSAP context
    const ctx = gsap.context(() => {
      // Set initial sidebar width
      gsap.set(sidebarRef.current, {
        width: isMobile ? (isOpen ? "16rem" : "0rem") : (isOpen ? "16rem" : "4rem")
      });

      // Only animate if sidebar is open on initial load
      if (isOpen) {
        const menuItems = document.querySelectorAll('.sidebar-menu-content');

        gsap.fromTo(menuItems,
            { opacity: 0, x: -10 },
            {
              opacity: 1,
              x: 0,
              duration: 0.4,
              stagger: 0.03,
              ease: "power1.out",
              delay: 0.2
            }
        );
      }
    }, sidebarRef);

    return () => ctx.revert();
  }, [isEnabled, hasAnimatedOnce]);

  // Detect mobile screen size
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    // Initial check
    checkMobile();

    // Add resize listener
    window.addEventListener('resize', checkMobile);

    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  // Update active item when location changes
  useEffect(() => {
    setActiveItem(location.pathname);
  }, [location]);

  // Close sidebar automatically on mobile when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      const sidebar = document.getElementById('sidebar');
      const headerToggle = document.getElementById('header-mobile-toggle');

      // Don't close if clicking the header toggle button
      if (headerToggle && headerToggle.contains(event.target)) {
        return;
      }

      if (sidebar && !sidebar.contains(event.target) && isMobile && isOpen) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, setIsOpen, isMobile]);

  // Prevent scrolling on body when mobile sidebar is open
  useEffect(() => {
    if (isMobile && isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }

    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, isMobile]);

  // Prepare menu items - making them either visible or "ready to animate"
  const renderMenuItems = () => {
    return menuSections.map((section, sectionIndex) => (
        <div key={sectionIndex} className="mb-6">
          {/* Section title - only show when sidebar is open */}
          {isOpen && (
              <h3 className="sidebar-menu-content mb-3 px-4 text-xs font-medium uppercase tracking-wider" style={{
                color: 'var(--color-sidebar-text)',
                fontWeight: 'var(--font-weight-medium)'
              }}>
                {section.title}
              </h3>
          )}

          {/* Section items */}
          <nav className="flex flex-col gap-1">
            {section.items.map((item, itemIndex) => {
              const isActive = activeItem === item.path;
              return (
                  <Link
                      key={itemIndex}
                      to={item.path}
                      className={`
                  sidebar-menu-item group
                  flex items-center justify-between rounded-xl transition-all duration-fast
                  ${isOpen ? 'mx-3 px-3 py-2.5 text-left' : 'mx-2 px-2 py-2.5 justify-center'}
                  ${isActive
                          ? 'shadow-sm'
                          : ''
                      }
                `}
                      style={{
                        background: isActive ? 'var(--color-sidebar-active)' : 'transparent',
                        color: isActive ? 'var(--color-sidebar-text-active)' : 'var(--color-sidebar-text)'
                      }}
                      onMouseEnter={(e) => {
                        if (!isActive) {
                          e.target.style.background = 'var(--color-sidebar-hover)';
                          e.target.style.color = 'var(--color-sidebar-text-active)';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (!isActive) {
                          e.target.style.background = 'transparent';
                          e.target.style.color = 'var(--color-sidebar-text)';
                        }
                      }}
                      title={!isOpen && !isMobile ? item.title : ''}
                  >
                    <div className="flex items-center sidebar-menu-content">
                  <span className={`transition-colors duration-fast`} style={{
                    color: isActive ? 'var(--color-sidebar-icon-active)' : 'var(--color-sidebar-icon)'
                  }}>
                    {item.icon(isActive)}
                  </span>
                      {isOpen && (
                          <span className="ml-3 font-medium" style={{
                            fontFamily: 'var(--font-primary)',
                            fontWeight: 'var(--font-weight-medium)'
                          }}>
                      {item.title}
                    </span>
                      )}
                    </div>

                    {/* Badge indicator if present */}
                    {isOpen && item.badge && (
                        <span className="inline-flex items-center justify-center px-2 py-0.5 text-xs font-medium leading-none text-white rounded-full" style={{
                          background: 'var(--color-primary)'
                        }}>
                    {item.badge}
                  </span>
                    )}

                    {/* Show badge in collapsed mode */}
                    {!isOpen && item.badge && (
                        <span className="absolute -top-1 -right-1 inline-flex items-center justify-center w-4 h-4 text-xs font-medium leading-none text-white rounded-full" style={{
                          background: 'var(--color-primary)'
                        }}>
                    {item.badge}
                  </span>
                    )}
                  </Link>
              );
            })}
          </nav>
        </div>
    ));
  };

  // Prepare footer items
  const renderFooterItems = () => {
    return (
        <nav className="flex flex-col gap-1">
          {footerItems.map((item, index) => {
            const isActive = activeItem === item.path;
            return (
                <Link
                    key={index}
                    to={item.path}
                    className={`
                sidebar-footer-item group
                flex items-center rounded-xl transition-all duration-fast
                ${isOpen ? 'mx-3 px-3 py-2.5 text-left' : 'mx-2 px-2 py-2.5 justify-center'}
                ${isActive ? 'shadow-sm' : ''}
              `}
                    style={{
                      background: isActive ? 'var(--color-sidebar-active)' : 'transparent',
                      color: isActive ? 'var(--color-sidebar-text-active)' : 'var(--color-sidebar-text)'
                    }}
                    onMouseEnter={(e) => {
                      if (!isActive) {
                        e.target.style.background = 'var(--color-sidebar-hover)';
                        e.target.style.color = 'var(--color-sidebar-text-active)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!isActive) {
                        e.target.style.background = 'transparent';
                        e.target.style.color = 'var(--color-sidebar-text)';
                      }
                    }}
                    title={item.title}
                >
                  <div className="sidebar-menu-content flex items-center">
                <span className={`transition-colors duration-fast`} style={{
                  color: isActive ? 'var(--color-sidebar-icon-active)' : 'var(--color-sidebar-icon)'
                }}>
                  {item.icon(isActive)}
                </span>
                    {isOpen && (
                        <span className="ml-3 font-medium" style={{
                          fontFamily: 'var(--font-primary)',
                          fontWeight: 'var(--font-weight-medium)'
                        }}>
                    {item.title}
                  </span>
                    )}
                  </div>
                </Link>
            );
          })}
        </nav>
    );
  };

  return (
      <>
        {/* Mobile overlay when sidebar is open */}
        {isOpen && isMobile && (
            <div
                className="fixed inset-0 z-30 transition-opacity md:hidden"
                style={{
                  background: 'var(--color-overlay-modal)'
                }}
                onClick={() => setIsOpen(false)}
                aria-hidden="true"
            />
        )}

        {/* Sidebar - always visible on desktop (expanded or collapsed), hidden/showing on mobile */}
        <aside
            id="sidebar"
            ref={sidebarRef}
            style={{
              width: !isEnabled ? (isMobile ? (isOpen ? "16rem" : "0") : (isOpen ? "16rem" : "4rem")) : undefined,
              zIndex: '1500', // Higher than header (z-40)
              background: 'var(--color-sidebar)',
              backdropFilter: "blur(16px)",
              borderRightColor: 'var(--color-sidebar-border)',
              boxShadow: 'var(--shadow-xl)',
              fontFamily: 'var(--font-primary)'
            }}
            className={`
          fixed inset-y-0 left-0
          ${isMobile && !isOpen ? '-translate-x-full' : 'translate-x-0'}
          overflow-hidden border-r
          flex flex-col
          transition-transform duration-normal
        `}
            aria-label="Sidebar"
        >
          {/* Sidebar header with logo and toggle button */}
          <div className={`flex items-center ${isOpen ? 'justify-between' : 'justify-center'} h-16 px-4 border-b`} style={{
            borderBottomColor: 'var(--color-sidebar-border)'
          }}>
            {isOpen ? (
                <div className="sidebar-menu-content flex items-center">
                  <div className="flex items-center justify-center w-8 h-8 rounded-lg shadow-sm" style={{
                    background: 'var(--color-primary)'
                  }}>
                    <span className="text-white font-bold text-sm">R</span>
                  </div>
                  <h1 className="ml-3 text-lg font-semibold" style={{
                    color: 'var(--color-sidebar-text-active)',
                    fontFamily: 'var(--font-primary)'
                  }}>Raseed</h1>
                </div>
            ) : (
                <div className="flex items-center justify-center w-8 h-8 rounded-lg shadow-sm" style={{
                  background: 'var(--color-primary)'
                }}>

                </div>
            )}

            {/* Toggle button - only show on desktop or when sidebar is open on mobile */}
            {(!isMobile || isOpen) && (
                <button
                    onClick={toggleSidebar}
                    className="p-2 rounded-lg focus:outline-none focus:ring-2 transition-all duration-fast"
                    style={{
                      color: 'var(--color-sidebar-icon)',
                      background: 'transparent'
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.background = 'var(--color-sidebar-hover)';
                      e.target.style.color = 'var(--color-sidebar-icon-active)';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.background = 'transparent';
                      e.target.style.color = 'var(--color-sidebar-icon)';
                    }}
                    aria-label="Toggle sidebar"
                >
                  {isOpen ? (
                      <ArrowLeftIcon size={18} filled={false} />
                  ) : (
                      <MenuIcon size={18} filled={false} />
                  )}
                </button>
            )}
          </div>

          {/* Menu items - main navigation with sections */}
          <div className={`flex-1 py-4 overflow-y-auto ${!isOpen && !isMobile ? 'flex flex-col items-center' : ''}`}>
            {isOpen ? (
                // If open, render the animated content
                renderMenuItems()
            ) : (
                // If closed, render icons only without animation
                menuSections.map((section, sectionIndex) => (
                    <div key={sectionIndex} className="mb-6">
                      <nav className="flex flex-col gap-1">
                        {section.items.map((item, itemIndex) => {
                          const isActive = activeItem === item.path;
                          return (
                              <Link
                                  key={itemIndex}
                                  to={item.path}
                                  className={`
                          sidebar-menu-item group relative
                          flex items-center justify-center rounded-xl transition-all duration-fast
                          mx-2 px-2 py-2.5
                        `}
                                  style={{
                                    background: isActive ? 'var(--color-sidebar-active)' : 'transparent',
                                    color: isActive ? 'var(--color-sidebar-text-active)' : 'var(--color-sidebar-text)'
                                  }}
                                  onMouseEnter={(e) => {
                                    if (!isActive) {
                                      e.target.style.background = 'var(--color-sidebar-hover)';
                                      e.target.style.color = 'var(--color-sidebar-text-active)';
                                    }
                                  }}
                                  onMouseLeave={(e) => {
                                    if (!isActive) {
                                      e.target.style.background = 'transparent';
                                      e.target.style.color = 'var(--color-sidebar-text)';
                                    }
                                  }}
                                  title={item.title}
                              >
                                <div className="flex items-center">
                          <span className={`transition-colors duration-fast`} style={{
                            color: isActive ? 'var(--color-sidebar-icon-active)' : 'var(--color-sidebar-icon)'
                          }}>
                            {item.icon(isActive)}
                          </span>
                                </div>

                                {/* Show badge in collapsed mode */}
                                {item.badge && (
                                    <span className="absolute -top-1 -right-1 inline-flex items-center justify-center w-4 h-4 text-xs font-medium leading-none text-white rounded-full" style={{
                                      background: 'var(--color-primary)'
                                    }}>
                            {item.badge}
                          </span>
                                )}
                              </Link>
                          );
                        })}
                      </nav>
                    </div>
                ))
            )}
          </div>

          {/* Footer items */}
          <div className={`p-4 mt-auto border-t ${!isOpen && !isMobile ? 'flex flex-col items-center' : ''}`} style={{
            borderTopColor: 'var(--color-sidebar-border)'
          }}>
            {isOpen ? (
                // If open, render animated footer items
                renderFooterItems()
            ) : (
                // If closed, render footer icons only without animation
                <nav className="flex flex-col gap-1">
                  {footerItems.map((item, index) => {
                    const isActive = activeItem === item.path;
                    return (
                        <Link
                            key={index}
                            to={item.path}
                            className={`
                      sidebar-footer-item group
                      flex items-center justify-center rounded-xl transition-all duration-fast
                      px-2 py-2.5
                    `}
                            style={{
                              background: isActive ? 'var(--color-sidebar-active)' : 'transparent',
                              color: isActive ? 'var(--color-sidebar-text-active)' : 'var(--color-sidebar-text)'
                            }}
                            onMouseEnter={(e) => {
                              if (!isActive) {
                                e.target.style.background = 'var(--color-sidebar-hover)';
                                e.target.style.color = 'var(--color-sidebar-text-active)';
                              }
                            }}
                            onMouseLeave={(e) => {
                              if (!isActive) {
                                e.target.style.background = 'transparent';
                                e.target.style.color = 'var(--color-sidebar-text)';
                              }
                            }}
                            title={item.title}
                        >
                    <span className={`transition-colors duration-fast`} style={{
                      color: isActive ? 'var(--color-sidebar-icon-active)' : 'var(--color-sidebar-icon)'
                    }}>
                      {item.icon(isActive)}
                    </span>
                        </Link>
                    );
                  })}
                </nav>
            )}
          </div>
        </aside>
      </>
  );
};

export default Sidebar;
