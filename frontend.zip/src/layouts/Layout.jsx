import { useEffect, useState } from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import BottomNav from './BottomNav';
import { useSidebar } from '../hooks/useSidebar';

const Layout = ({ children }) => {
  const { isOpen, setIsOpen } = useSidebar();
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);
  const isMobile = windowWidth < 768;

  // Handle resize events to adjust layout
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);

    // Handle ESC key to close sidebar on mobile
    const handleEscKey = (event) => {
      if (event.key === 'Escape' && isMobile) {
        setIsOpen(false);
      }
    };

    window.addEventListener('keydown', handleEscKey);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('keydown', handleEscKey);
    };
  }, [setIsOpen, isMobile]);

  return (
      <div className="flex h-screen overflow-hidden relative" style={{
        background: 'var(--color-background)'
      }}>
        {/* Full-height sidebar on the left */}
        <Sidebar />

        {/* Right side content */}
        <div className={`flex flex-col flex-1 min-w-0 w-full transition-all duration-normal ${
            isMobile
                ? 'ml-0'  // No margin on mobile - sidebar overlays
                : isOpen ? 'ml-64' : 'ml-16'  // Responsive margin on desktop
        }`}>
          {/* Header at the top */}
          <Header />

          {/* Main content below header with padding for bottom nav */}
          <main
              className="flex-1 overflow-y-auto backdrop-blur-md"
              style={{
                background: 'var(--color-surface)',
                paddingBottom: isMobile ? '5rem' : '0', // Add padding for mobile bottom nav
              }}
          >
            <div className="container mx-auto p-4 sm:p-6 lg:p-8">
              {children}
            </div>
          </main>

          {/* Bottom Navigation - only show on mobile */}
          {isMobile && <BottomNav />}
        </div>
      </div>
  );
};

export default Layout;
