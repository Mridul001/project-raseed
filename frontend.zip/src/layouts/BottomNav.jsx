import { useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { gsap } from 'gsap';
import { useAnimationContext } from '@/animations/AnimationProvider';
import {ChartIcon, HistoryIcon, ScanIcon, ChatIcon, HomeIcon} from "@/assets/svg/icons/icons.jsx";

const navItems = [
    { id: 'chat', path: '/ask-queries', icon: ChatIcon, label: 'Chat' },
    { id: 'history', path: '/history', icon: HistoryIcon, label: 'History' },
    { id: 'scan', path: '/scan-receipt', icon: ScanIcon, label: 'Scan', isCenter: true },
    { id: 'stats', path: '/stats', icon: ChartIcon, label: 'Stats' },
    { id: 'Home', path: '/home', icon: HomeIcon, label: 'Home' },
];

const BottomNav = () => {
    const location = useLocation();
    const { isEnabled } = useAnimationContext();
    const [activeItem, setActiveItem] = useState(location.pathname);
    const navRef = useRef(null);
    const indicatorRef = useRef(null);
    const itemRefs = useRef({});
    const svgRef = useRef(null);

    // Update active item when location changes
    useEffect(() => {
        setActiveItem(location.pathname);
    }, [location]);

    // Function to position indicator (exclude center button)
    const positionIndicator = (immediate = false) => {
        if (!indicatorRef.current) return;

        const activeNavItem = navItems.find(item => item.path === activeItem && !item.isCenter);

        // If center item is active or no valid item found, hide indicator
        if (!activeNavItem || activeItem === '/scan-receipt') {
            if (immediate) {
                gsap.set(indicatorRef.current, { opacity: 0 });
            } else {
                gsap.to(indicatorRef.current, {
                    opacity: 0,
                    duration: 0.3,
                    ease: "power2.out"
                });
            }
            return;
        }

        const activeElement = itemRefs.current[activeNavItem.id];
        if (activeElement) {
            const navContainer = navRef.current.querySelector('.nav-items-container');
            const iconContainer = activeElement.querySelector('.icon-container');

            if (navContainer && iconContainer) {
                const containerRect = navContainer.getBoundingClientRect();
                const iconRect = iconContainer.getBoundingClientRect();

                // Calculate center position of the icon
                const iconCenter = iconRect.left + (iconRect.width / 2);
                const containerLeft = containerRect.left;

                // Position indicator centered under the icon (14px = half of 28px indicator width)
                const leftPosition = iconCenter - containerLeft - 14;

                if (immediate) {
                    gsap.set(indicatorRef.current, { x: leftPosition, opacity: 1 });
                } else {
                    gsap.to(indicatorRef.current, {
                        x: leftPosition,
                        opacity: 1,
                        duration: 0.4,
                        ease: "power2.out"
                    });
                }
            }
        }
    };

    // Set initial indicator position
    useEffect(() => {
        const timer = setTimeout(() => {
            positionIndicator(true);
        }, 300);

        return () => clearTimeout(timer);
    }, []);

    // Animate indicator position when active item changes
    useEffect(() => {
        if (!isEnabled) return;
        const timer = setTimeout(() => {
            positionIndicator();
        }, 50);

        return () => clearTimeout(timer);
    }, [activeItem, isEnabled]);

    // Initial animation on mount
    useEffect(() => {
        if (!navRef.current || !isEnabled) return;

        const ctx = gsap.context(() => {
            gsap.fromTo(navRef.current,
                { y: 100, opacity: 0 },
                { y: 0, opacity: 1, duration: 0.5, ease: "power2.out" }
            );

            const items = navRef.current.querySelectorAll('.nav-item');
            gsap.fromTo(items,
                { y: 20, opacity: 0 },
                {
                    y: 0,
                    opacity: 1,
                    duration: 0.4,
                    stagger: 0.05,
                    delay: 0.2,
                    ease: "power2.out",
                    onComplete: () => {
                        setTimeout(() => positionIndicator(true), 100);
                    }
                }
            );
        }, navRef);

        return () => ctx.revert();
    }, [isEnabled]);

    const handleNavClick = (item) => {
        if (item.isCenter) {
            const button = itemRefs.current[item.id];
            if (!button) return;

            const ripple = document.createElement('span');
            ripple.style.cssText = `
                position: absolute;
                border-radius: 50% / 25%;
                width: 120px;
                height: 60px;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) scale(0);
                pointer-events: none;
                background: var(--color-primary-glass);
            `;

            button.appendChild(ripple);

            gsap.to(ripple, {
                scale: 2,
                opacity: 0,
                duration: 0.6,
                ease: "power2.out",
                onComplete: () => ripple.remove()
            });

            // Dispatch custom event for scan button click when already on scan page
            if (location.pathname === '/scan-receipt') {
                const event = new CustomEvent('bottomNavClick', {
                    detail: 'scan'
                });
                window.dispatchEvent(event);
            }
        }

        if (isEnabled && itemRefs.current[item.id]) {
            gsap.fromTo(itemRefs.current[item.id],
                { scale: 1 },
                {
                    scale: 1.2,
                    duration: 0.1,
                    yoyo: true,
                    repeat: 1,
                    ease: "power2.inOut"
                }
            );
        }
    };

    return (
        <nav
            ref={navRef}
            className="fixed bottom-0 left-0 right-0 pb-safe"
            style={{
                marginBottom: 'var(--spacing-sm)',
                zIndex: 'var(--z-50)',
            }}
        >
            <div
                className="relative mx-auto"
                style={{
                    padding: '0 var(--spacing-md)',
                    maxWidth: '28rem'
                }}
            >
                <div className="relative">
                    <svg
                        ref={svgRef}
                        width="100%"
                        viewBox="0 0 100 35"
                        className="absolute bottom-0 left-0 w-full"
                        preserveAspectRatio="none"
                        style={{
                            filter: 'drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1))',
                            height: 'calc(var(--spacing-6xl) + var(--spacing-lg))',
                        }}
                    >
                        <path
                            d="M 5 12
                               L 32 12
                               Q 36 12 38 10
                               Q 42 8 45 6
                               Q 48 4 50 4
                               Q 52 4 55 6
                               Q 58 8 62 10
                               Q 64 12 68 12
                               L 95 12
                               Q 100 12 100 17
                               L 100 30
                               Q 100 35 95 35
                               L 5 35
                               Q 0 35 0 30
                               L 0 17
                               Q 0 12 5 12 Z"
                            fill="var(--color-glass-heavy)"
                            style={{
                                backdropFilter: 'var(--glass-backdrop-blur)',
                            }}
                        />
                    </svg>

                    <div
                        className="nav-items-container relative"
                        style={{
                            zIndex: 'var(--z-10)',
                            paddingBottom: 'var(--spacing-sm)',
                            paddingTop: 'var(--spacing-sm)',
                        }}
                    >
                        <ul
                            className="flex items-center"
                            style={{
                                justifyContent: 'space-around',
                                width: '100%',
                                paddingLeft: 'var(--spacing-md)',
                                paddingRight: 'var(--spacing-md)',
                            }}
                        >
                            {navItems.map((item, index) => {
                                const isActive = activeItem === item.path;
                                const Icon = item.icon;

                                if (item.isCenter) {
                                    return (
                                        <li
                                            key={item.id}
                                            className="nav-item relative flex justify-center"
                                            style={{
                                                transform: 'translateY(calc(-1 * var(--spacing-2xl)))',
                                                flex: '0 0 auto',
                                            }}
                                        >
                                            <Link
                                                ref={(el) => itemRefs.current[item.id] = el}
                                                to={item.path}
                                                onClick={() => handleNavClick(item)}
                                                className="icon-container relative flex items-center justify-center rounded-full shadow-lg transition-all duration-300 hover:scale-110"
                                                style={{
                                                    width: 'calc(var(--spacing-4xl) + var(--spacing-xs))',
                                                    height: 'calc(var(--spacing-4xl) + var(--spacing-xs))',
                                                    background: 'var(--gradient-primary-gradient)',
                                                    boxShadow: 'var(--shadow-glow-primary)',
                                                    color: 'var(--color-primary-contrast)',
                                                }}
                                            >
                                                <Icon size={30} />
                                            </Link>
                                        </li>
                                    );
                                }

                                return (
                                    <li
                                        key={item.id}
                                        className="nav-item relative flex justify-center"
                                        style={{
                                            minWidth: '60px',
                                        }}
                                    >
                                        <Link
                                            ref={(el) => itemRefs.current[item.id] = el}
                                            to={item.path}
                                            onClick={() => handleNavClick(item)}
                                            className="group flex flex-col items-center justify-center transition-all duration-300"
                                            style={{
                                                padding: 'var(--spacing-xs)',
                                                color: isActive ? 'var(--color-primary)' : 'var(--color-content-tertiary)',
                                                minHeight: 'calc(var(--spacing-3xl) + var(--spacing-md))',
                                            }}
                                            onMouseEnter={(e) => {
                                                if (!isActive && isEnabled) {
                                                    gsap.to(e.currentTarget, {
                                                        scale: 1.05,
                                                        duration: 0.2,
                                                        ease: "power2.out"
                                                    });
                                                    e.currentTarget.style.color = 'var(--color-primary-light)';
                                                }
                                            }}
                                            onMouseLeave={(e) => {
                                                if (!isActive && isEnabled) {
                                                    gsap.to(e.currentTarget, {
                                                        scale: 1,
                                                        duration: 0.2,
                                                        ease: "power2.out"
                                                    });
                                                    e.currentTarget.style.color = 'var(--color-content-tertiary)';
                                                }
                                            }}
                                        >
                                            <div
                                                className="icon-container relative flex items-center justify-center"
                                                style={{
                                                    filter: isActive && !item.isCenter ? 'drop-shadow(0 0 8px var(--color-primary-glow))' : 'none',
                                                    transition: 'filter 0.3s ease',
                                                    marginBottom: 'var(--spacing-xs)',
                                                    width: '22px',
                                                    height: '22px',
                                                }}
                                            >
                                                <Icon size={22} />
                                            </div>
                                            <span
                                                className="text-xs font-medium transition-opacity duration-200"
                                                style={{
                                                    fontFamily: 'var(--font-primary)',
                                                    fontSize: 'var(--font-size-xs)',
                                                    opacity: isActive ? 1 : 0.7,
                                                    whiteSpace: 'nowrap',
                                                }}
                                            >
                                                {item.label}
                                            </span>
                                        </Link>
                                    </li>
                                );
                            })}
                        </ul>

                        {/* Active indicator - only for non-center items */}
                        <div
                            ref={indicatorRef}
                            className="absolute transition-all duration-300"
                            style={{
                                width: '28px',
                                height: 'var(--spacing-xs)',
                                background: 'var(--color-primary)',
                                borderRadius: 'var(--radius-full)',
                                boxShadow: '0 0 12px var(--color-primary-glow)',
                                bottom: 'var(--spacing-sm)',
                                left: '0px',
                                opacity: 0,
                            }}
                        />
                    </div>
                </div>
            </div>
        </nav>
    );
};

export default BottomNav;
