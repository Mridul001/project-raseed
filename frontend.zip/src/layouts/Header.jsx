import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import ThemeToggle from '../components/ui/ThemeToggle';
import { gsap } from 'gsap';
import { useAnimationContext } from '@/animations/AnimationProvider';
import { useSidebar } from "../hooks/useSidebar";
import {
    NotificationIcon,
    AvatarIcon,
    ArrowDownIcon,
    MenuIcon
} from "@/assets/svg/icons/icons.jsx";
import { useTheme } from '../hooks/useTheme';
import { MoonIcon, SunIcon } from "@/assets/svg/icons/icons.jsx";
import { Link } from 'react-router-dom';

const Header = () => {
    const { themeName, toggleTheme } = useTheme();
    const { user, logout } = useAuth();
    const { isOpen, toggleSidebar } = useSidebar();
    const [showUserMenu, setShowUserMenu] = useState(false);
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
    const menuRef = useRef(null);
    const headerRef = useRef(null);
    const { isEnabled } = useAnimationContext();

    // Handle signout click
    const handleSignOut = () => {
        logout();
    };

    // Detect mobile screen size
    useEffect(() => {
        const checkMobile = () => {
            setIsMobile(window.innerWidth < 768);
        };

        // Initial check
        checkMobile();

        // Add resize listener
        window.addEventListener('resize', checkMobile);

        return () => {
            window.removeEventListener('resize', checkMobile);
        };
    }, []);

    // Initial animation on page load
    useEffect(() => {
        if (!headerRef.current || !isEnabled) return;

        const ctx = gsap.context(() => {
            // Get all header elements that should be animated
            const elements = [
                headerRef.current.querySelector('.header-menu-toggle'),
                headerRef.current.querySelector('.header-title'),
                headerRef.current.querySelector('.header-theme-toggle'),
                headerRef.current.querySelector('.header-notification'),
                headerRef.current.querySelector('.header-profile')
            ].filter(Boolean);

            // Set initial state
            gsap.set(elements, {
                y: -20,
                opacity: 0
            });

            // Animate header elements
            gsap.to(elements, {
                y: 0,
                opacity: 1,
                duration: 0.5,
                stagger: 0.1,
                ease: "power2.out",
                delay: 0.2
            });

        }, headerRef);

        return () => ctx.revert();
    }, [isEnabled]);

    // User menu animation
    useEffect(() => {
        if (!menuRef.current || !isEnabled) return;

        const dropdown = menuRef.current.querySelector('.user-dropdown');
        if (!dropdown) return;

        const ctx = gsap.context(() => {
            if (showUserMenu) {
                // Set initial state
                gsap.set(dropdown, {
                    opacity: 0,
                    y: 10,
                    scale: 0.95,
                    transformOrigin: 'top right'
                });

                // Animate menu opening
                gsap.to(dropdown, {
                    opacity: 1,
                    y: 0,
                    scale: 1,
                    duration: 0.2,
                    ease: "power2.out"
                });
            }
        }, menuRef);

        return () => ctx.revert();
    }, [showUserMenu, isEnabled]);

    // Close menu when clicking outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (menuRef.current && !menuRef.current.contains(event.target)) {
                setShowUserMenu(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    return (
        <header
            ref={headerRef}
            className="sticky top-0 z-40 flex items-center justify-between w-full h-16 px-4 sm:px-6 lg:px-8 backdrop-blur-md transition-all duration-normal"
            style={{
                background: 'var(--color-surface)'
            }}
        >
            {/* Left side - Menu Toggle and Title */}
            <div className="flex items-center space-x-3 sm:space-x-4">
                {/* Menu Toggle Button - Only visible on mobile */}
                {isMobile && (
                    <button
                        id="header-mobile-toggle"
                        className="header-menu-toggle p-2 rounded-lg focus:outline-none focus:ring-2 transition-colors duration-fast"
                        style={{
                            color: 'var(--color-content-tertiary)',
                            background: 'transparent'
                        }}
                        onMouseEnter={(e) => {
                            e.target.style.background = 'var(--color-surface-hover)';
                        }}
                        onMouseLeave={(e) => {
                            e.target.style.background = 'transparent';
                        }}
                        onClick={toggleSidebar}
                        aria-label="Toggle sidebar"
                    >
                        <MenuIcon size={20} />
                    </button>
                )}

                {/* Title */}
                <Link to="/home" className="flex-shrink-0">
                    <h1 className="header-title text-xl sm:text-2xl font-semibold" style={{
                        color: 'var(--color-content-primary)',
                        fontFamily: 'var(--font-primary)'
                    }}>
                        Raseed
                    </h1>
                </Link>
            </div>

            {/* Right side - Theme Toggle, Notification and User Profile */}
            <div className="flex items-center space-x-2 sm:space-x-4">
                {/* Theme Toggle - Mobile version */}
                {isMobile && (
                    <button
                        onClick={toggleTheme}
                        className="header-theme-toggle p-2 rounded-lg focus:outline-none focus:ring-2 transition-colors duration-fast"
                        style={{
                            background: 'var(--color-surface-100)',
                            color: 'var(--color-content-secondary)'
                        }}
                        onMouseEnter={(e) => {
                            e.target.style.background = 'var(--color-surface-hover)';
                        }}
                        onMouseLeave={(e) => {
                            e.target.style.background = 'var(--color-surface-100)';
                        }}
                        aria-label="Toggle theme"
                    >
                        {themeName === 'dark' ? (
                            <MoonIcon
                                size={18}
                                filled={true}
                                style={{color: 'var(--color-content-primary)'}}
                            />
                        ) : (
                            <SunIcon
                                size={18}
                                filled={false}
                                style={{color: 'var(--color-content-primary)'}}
                            />
                        )}
                    </button>
                )}

                {/* Theme Toggle - Desktop version */}
                {!isMobile && (
                    <div className="header-theme-toggle">
                        <ThemeToggle />
                    </div>
                )}

                {/* Notification Bell - Desktop only */}
                {!isMobile && (
                    <button
                        className="header-notification relative p-2 rounded-lg focus:outline-none focus:ring-2 transition-colors duration-fast"
                        style={{
                            color: 'var(--color-content-tertiary)',
                            background: 'transparent'
                        }}
                        onMouseEnter={(e) => {
                            e.target.style.background = 'var(--color-surface-hover)';
                        }}
                        onMouseLeave={(e) => {
                            e.target.style.background = 'transparent';
                        }}
                        aria-label="Notifications"
                    >
                        <NotificationIcon size={20} />
                        {/* Notification badge - example */}
                        <span className="absolute -top-1 -right-1 inline-flex items-center justify-center w-4 h-4 text-xs font-bold leading-none text-white rounded-full" style={{
                            background: 'var(--color-error)'
                        }}>
                            3
                        </span>
                    </button>
                )}

                {/* User profile dropdown */}
                <div className="header-profile relative" ref={menuRef}>
                    <button
                        onClick={() => setShowUserMenu(!showUserMenu)}
                        className="flex items-center space-x-2 p-1 rounded-lg focus:outline-none focus:ring-2 transition-colors duration-fast"
                        style={{
                            background: 'transparent'
                        }}
                        onMouseEnter={(e) => {
                            e.target.style.background = 'var(--color-surface-hover)';
                        }}
                        onMouseLeave={(e) => {
                            e.target.style.background = 'transparent';
                        }}
                        aria-label="User menu"
                    >
                        {/* User avatar */}
                        <div className="w-8 h-8 overflow-hidden rounded-full border flex items-center justify-center" style={{
                            background: 'var(--color-surface-200)',
                            borderColor: 'var(--color-border)'
                        }}>
                            {user && user.avatar ? (
                                <img
                                    src={user.avatar}
                                    alt="User avatar"
                                    className="w-full h-full object-cover"
                                />
                            ) : (
                                <AvatarIcon size={18} color="var(--color-content-tertiary)" />
                            )}
                        </div>

                        {/* Username - Hide on mobile */}
                        {!isMobile && (
                            <span className="text-sm font-medium" style={{
                                color: 'var(--color-content-primary)',
                                fontFamily: 'var(--font-primary)'
                            }}>
                                {user?.name || "Admin User"}
                            </span>
                        )}

                        {/* Dropdown arrow */}
                        <ArrowDownIcon
                            size={16}
                            className={`transition-transform duration-fast ${
                                showUserMenu ? 'rotate-180' : ''
                            }`}
                            style={{
                                color: 'var(--color-content-tertiary)'
                            }}
                        />
                    </button>

                    {/* Dropdown menu */}
                    {showUserMenu && (
                        <div className="user-dropdown absolute right-0 w-48 py-2 mt-2 rounded-lg shadow-lg z-50" style={{
                            background: 'var(--color-surface)',
                            backdropFilter: "blur(16px)",
                            borderColor: 'var(--color-border)',
                            borderWidth: '1px'
                        }}>
                            <a
                                href="#profile"
                                className="block px-4 py-2 text-sm transition-colors duration-fast"
                                style={{
                                    color: 'var(--color-content-secondary)'
                                }}
                                onMouseEnter={(e) => {
                                    e.target.style.background = 'var(--color-surface-hover)';
                                    e.target.style.color = 'var(--color-content-primary)';
                                }}
                                onMouseLeave={(e) => {
                                    e.target.style.background = 'transparent';
                                    e.target.style.color = 'var(--color-content-secondary)';
                                }}
                                onClick={() => setShowUserMenu(false)}
                            >
                                Your Profile
                            </a>
                            <a
                                href="#settings"
                                className="block px-4 py-2 text-sm transition-colors duration-fast"
                                style={{
                                    color: 'var(--color-content-secondary)'
                                }}
                                onMouseEnter={(e) => {
                                    e.target.style.background = 'var(--color-surface-hover)';
                                    e.target.style.color = 'var(--color-content-primary)';
                                }}
                                onMouseLeave={(e) => {
                                    e.target.style.background = 'transparent';
                                    e.target.style.color = 'var(--color-content-secondary)';
                                }}
                                onClick={() => setShowUserMenu(false)}
                            >
                                Settings
                            </a>
                            {/* Mobile only - Notifications */}
                            {isMobile && (
                                <a
                                    href="#notifications"
                                    className="block px-4 py-2 text-sm transition-colors duration-fast"
                                    style={{
                                        color: 'var(--color-content-secondary)'
                                    }}
                                    onMouseEnter={(e) => {
                                        e.target.style.background = 'var(--color-surface-hover)';
                                        e.target.style.color = 'var(--color-content-primary)';
                                    }}
                                    onMouseLeave={(e) => {
                                        e.target.style.background = 'transparent';
                                        e.target.style.color = 'var(--color-content-secondary)';
                                    }}
                                    onClick={() => setShowUserMenu(false)}
                                >
                                    Notifications
                                </a>
                            )}
                            <div className="border-t my-1" style={{
                                borderColor: 'var(--color-border)'
                            }}></div>
                            <button
                                onClick={handleSignOut}
                                className="w-full text-left block px-4 py-2 text-sm transition-colors duration-fast"
                                style={{
                                    color: 'var(--color-error)',
                                    background: 'transparent',
                                    border: 'none'
                                }}
                                onMouseEnter={(e) => {
                                    e.target.style.background = 'var(--color-error-surface)';
                                    e.target.style.color = 'var(--color-error)';
                                }}
                                onMouseLeave={(e) => {
                                    e.target.style.background = 'transparent';
                                    e.target.style.color = 'var(--color-error)';
                                }}
                            >
                                Sign out
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
};

export default Header;
