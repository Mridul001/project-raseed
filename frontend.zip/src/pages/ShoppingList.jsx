import React, { useState, useRef, useEffect } from 'react';
import { Check, Plus, Trash2, Loader2, ShoppingCart } from 'lucide-react';
import { gsap } from 'gsap';

const ShoppingList = () => {
    const [prompt, setPrompt] = useState('');
    const [items, setItems] = useState([]);
    const [isGenerating, setIsGenerating] = useState(false);
    const [isUpdatingWallet, setIsUpdatingWallet] = useState(false);
    const [showAddInput, setShowAddInput] = useState(false);
    const [newItem, setNewItem] = useState('');
    const [toast, setToast] = useState(null);

    // Mock API call to generate items based on prompt
    const generateItems = async (userPrompt) => {
        setIsGenerating(true);

        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1500));

        // Mock response based on prompt keywords
        const mockItems = [];
        const prompt_lower = userPrompt.toLowerCase();

        if (prompt_lower.includes('breakfast') || prompt_lower.includes('morning')) {
            mockItems.push('Bread', 'Eggs', 'Milk', 'Butter', 'Orange Juice', 'Cereal');
        } else if (prompt_lower.includes('dinner') || prompt_lower.includes('evening')) {
            mockItems.push('Chicken', 'Rice', 'Vegetables', 'Garlic', 'Onions', 'Olive Oil');
        } else if (prompt_lower.includes('fruit') || prompt_lower.includes('healthy')) {
            mockItems.push('Apples', 'Bananas', 'Oranges', 'Berries', 'Spinach', 'Carrots');
        } else if (prompt_lower.includes('party') || prompt_lower.includes('snack')) {
            mockItems.push('Chips', 'Soda', 'Pizza', 'Ice Cream', 'Cookies', 'Popcorn');
        } else {
            // Default items
            mockItems.push('Tomatoes', 'Pasta', 'Cheese', 'Bread', 'Milk', 'Chicken');
        }

        setIsGenerating(false);
        return mockItems.map(item => ({ name: item, checked: false, id: Date.now() + Math.random() }));
    };

    // Mock API call to update wallet
    const updateWallet = async () => {
        setIsUpdatingWallet(true);

        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));

        setIsUpdatingWallet(false);
        return { success: true };
    };

    // Show toast notification
    const showToast = (message, type = 'success') => {
        setToast({ message, type });
        setTimeout(() => setToast(null), 3000);
    };

    // Handle prompt submission
    const handleSubmitPrompt = async () => {
        if (!prompt.trim()) return;

        try {
            const newItems = await generateItems(prompt);

            // Merge with existing items (avoid duplicates)
            setItems(prevItems => {
                const existingNames = prevItems.map(item => item.name.toLowerCase());
                const filteredNewItems = newItems.filter(
                    item => !existingNames.includes(item.name.toLowerCase())
                );
                return [...prevItems, ...filteredNewItems];
            });

            setPrompt('');
            showToast(`Added ${newItems.length} items to your list!`);
        } catch (error) {
            showToast('Failed to generate items. Please try again.', 'error');
        }
    };

    // Handle item checkbox toggle
    const toggleItem = (id) => {
        setItems(prevItems =>
            prevItems.map(item =>
                item.id === id ? { ...item, checked: !item.checked } : item
            )
        );
    };

    // Handle swipe to delete
    const handleSwipeDelete = (id) => {
        const itemElement = document.querySelector(`[data-item-id="${id}"]`);

        gsap.to(itemElement, {
            x: -300,
            opacity: 0,
            duration: 0.3,
            ease: "power2.out",
            onComplete: () => {
                setItems(prevItems => prevItems.filter(item => item.id !== id));
                showToast('Item removed from list');
            }
        });
    };

    // Handle add new item
    const handleAddItem = () => {
        if (!newItem.trim()) return;

        const newItemObj = {
            id: Date.now() + Math.random(),
            name: newItem.trim(),
            checked: false
        };

        setItems(prevItems => [...prevItems, newItemObj]);
        setNewItem('');
        setShowAddInput(false);
        showToast('Item added successfully!');
    };

    // Handle update wallet
    const handleUpdateWallet = async () => {
        const checkedItems = items.filter(item => item.checked);

        if (checkedItems.length === 0) {
            showToast('Please select items to update wallet', 'error');
            return;
        }

        try {
            await updateWallet();

            // Remove checked items from list
            setItems(prevItems => prevItems.filter(item => !item.checked));
            showToast(`Updated wallet with ${checkedItems.length} items!`);
        } catch (error) {
            showToast('Failed to update wallet. Please try again.', 'error');
        }
    };

    // Swipe handlers
    const handleTouchStart = (e, id) => {
        const touch = e.touches[0];
        const element = e.currentTarget;
        element.dataset.startX = touch.clientX;
        element.dataset.startY = touch.clientY;
        element.dataset.isSwiping = 'false';
    };

    const handleTouchMove = (e, id) => {
        const touch = e.touches[0];
        const element = e.currentTarget;
        const startX = parseFloat(element.dataset.startX);
        const startY = parseFloat(element.dataset.startY);
        const currentX = touch.clientX;
        const currentY = touch.clientY;

        const deltaX = currentX - startX;
        const deltaY = currentY - startY;

        // Only start swiping if horizontal movement is greater than vertical
        if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 10) {
            element.dataset.isSwiping = 'true';
            e.preventDefault();

            if (deltaX < 0) { // Swiping left
                gsap.set(element, { x: Math.max(deltaX, -100) });

                // Show delete indicator
                const deleteIndicator = element.querySelector('.delete-indicator');
                if (deleteIndicator) {
                    gsap.set(deleteIndicator, {
                        opacity: Math.min(Math.abs(deltaX) / 100, 1),
                        x: Math.max(deltaX + 100, 0)
                    });
                }
            }
        }
    };

    const handleTouchEnd = (e, id) => {
        const element = e.currentTarget;
        const startX = parseFloat(element.dataset.startX);
        const isSwiping = element.dataset.isSwiping === 'true';

        if (isSwiping) {
            const currentX = e.changedTouches[0].clientX;
            const deltaX = currentX - startX;

            if (deltaX < -80) { // Threshold for delete
                handleSwipeDelete(id);
            } else {
                // Snap back
                gsap.to(element, { x: 0, duration: 0.3, ease: "power2.out" });
                const deleteIndicator = element.querySelector('.delete-indicator');
                if (deleteIndicator) {
                    gsap.to(deleteIndicator, { opacity: 0, x: 0, duration: 0.3 });
                }
            }
        }

        element.dataset.isSwiping = 'false';
    };

    return (
        <div className="min-h-screen p-4 bg-background">
            <div className="max-w-md mx-auto">
                {/* Header */}
                <div className="mb-6">
                    <h1 className="text-2xl font-bold text-content-primary mb-2 flex items-center gap-2">
                        <ShoppingCart className="w-6 h-6 text-primary" />
                        Smart Shopping List
                    </h1>
                    <p className="text-content-secondary text-sm">
                        Generate your shopping list with AI assistance
                    </p>
                </div>

                {/* Input Section */}
                <div className="mb-6">
                    <div className="relative">
                        <input
                            type="text"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="What do you need? (e.g., 'breakfast items', 'dinner party')"
                            className="w-full px-4 py-3 pr-12 rounded-chat-input bg-glass-primary backdrop-blur-md border border-border-light text-content-primary placeholder-input-placeholder focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all duration-300"
                            onKeyDown={(e) => e.key === 'Enter' && handleSubmitPrompt()}
                            disabled={isGenerating}
                        />
                        {prompt.trim() && (
                            <button
                                onClick={handleSubmitPrompt}
                                disabled={isGenerating}
                                className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1.5 bg-primary hover:bg-primary-dark text-primary-contrast rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {isGenerating ? (
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                    <Check className="w-4 h-4" />
                                )}
                            </button>
                        )}
                    </div>
                </div>

                {/* Items List */}
                {items.length > 0 && (
                    <div className="mb-6">
                        <div className="bg-glass-primary backdrop-blur-md rounded-xl border border-border-light p-4 shadow-card">
                            <h3 className="text-lg font-semibold text-content-primary mb-4 flex items-center gap-2">
                                Shopping Items
                                <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded-full">
                  {items.length}
                </span>
                            </h3>

                            <div className="space-y-2">
                                {items.map((item) => (
                                    <div
                                        key={item.id}
                                        data-item-id={item.id}
                                        className="relative flex items-center gap-3 p-3 bg-surface-100 rounded-lg border border-border-light transition-all duration-200 hover:bg-surface-hover select-none overflow-hidden"
                                        onTouchStart={(e) => handleTouchStart(e, item.id)}
                                        onTouchMove={(e) => handleTouchMove(e, item.id)}
                                        onTouchEnd={(e) => handleTouchEnd(e, item.id)}
                                    >
                                        {/* Delete Indicator */}
                                        <div className="delete-indicator absolute right-0 top-0 h-full w-20 bg-error flex items-center justify-center opacity-0 pointer-events-none">
                                            <Trash2 className="w-5 h-5 text-error-contrast" />
                                        </div>

                                        {/* Checkbox */}
                                        <input
                                            type="checkbox"
                                            checked={item.checked}
                                            onChange={() => toggleItem(item.id)}
                                            className="w-4 h-4 text-primary border-border rounded focus:ring-primary focus:ring-2"
                                        />

                                        {/* Item Name */}
                                        <span className={`flex-1 text-content-primary ${item.checked ? 'line-through opacity-60' : ''} transition-all duration-200`}>
                      {item.name}
                    </span>

                                        {/* Desktop Delete Button */}
                                        <button
                                            onClick={() => handleSwipeDelete(item.id)}
                                            className="hidden sm:flex w-8 h-8 items-center justify-center text-error hover:bg-error/20 rounded-lg transition-all duration-200"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {/* Add Item Section */}
                <div className="mb-6">
                    {showAddInput ? (
                        <div className="bg-glass-primary backdrop-blur-md rounded-xl border border-border-light p-4">
                            <div className="flex gap-2">
                                <input
                                    type="text"
                                    value={newItem}
                                    onChange={(e) => setNewItem(e.target.value)}
                                    placeholder="Enter item name"
                                    className="flex-1 px-3 py-2 rounded-lg bg-input border border-input-border text-content-primary placeholder-input-placeholder focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                                    onKeyDown={(e) => e.key === 'Enter' && handleAddItem()}
                                    autoFocus
                                />
                                <button
                                    onClick={handleAddItem}
                                    className="px-3 py-2 bg-primary hover:bg-primary-dark text-primary-contrast rounded-lg transition-all duration-200"
                                >
                                    <Check className="w-4 h-4" />
                                </button>
                                <button
                                    onClick={() => {
                                        setShowAddInput(false);
                                        setNewItem('');
                                    }}
                                    className="px-3 py-2 bg-surface-200 hover:bg-surface-hover text-content-secondary rounded-lg transition-all duration-200"
                                >
                                    ✕
                                </button>
                            </div>
                        </div>
                    ) : (
                        <button
                            onClick={() => setShowAddInput(true)}
                            className="w-full p-4 border-2 border-dashed border-border-light rounded-xl bg-glass-light hover:bg-glass-primary hover:border-primary/50 text-content-secondary hover:text-content-primary transition-all duration-300 flex items-center justify-center gap-2"
                        >
                            <Plus className="w-5 h-5" />
                            Add Item
                        </button>
                    )}
                </div>

                {/* Update Wallet Button */}
                {items.some(item => item.checked) && (
                    <div className="mb-6">
                        <button
                            onClick={handleUpdateWallet}
                            disabled={isUpdatingWallet}
                            className="w-full py-4 bg-primary hover:bg-primary-dark text-primary-contrast rounded-xl font-medium transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-glow-primary"
                        >
                            {isUpdatingWallet ? (
                                <>
                                    <Loader2 className="w-5 h-5 animate-spin" />
                                    Updating Wallet...
                                </>
                            ) : (
                                <>
                                    <ShoppingCart className="w-5 h-5" />
                                    Update Wallet ({items.filter(item => item.checked).length} items)
                                </>
                            )}
                        </button>
                    </div>
                )}

                {/* Empty State */}
                {items.length === 0 && !isGenerating && (
                    <div className="text-center py-12 bg-glass-light rounded-xl border border-border-light">
                        <ShoppingCart className="w-12 h-12 text-content-tertiary mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-content-primary mb-2">
                            No items yet
                        </h3>
                        <p className="text-content-secondary text-sm">
                            Enter a prompt above to generate your shopping list
                        </p>
                    </div>
                )}

                {/* Toast Notification */}
                {toast && (
                    <div className={`fixed bottom-4 left-4 right-4 mx-auto max-w-md p-4 rounded-lg backdrop-blur-md border transition-all duration-300 z-50 ${
                        toast.type === 'error'
                            ? 'bg-error/90 border-error text-error-contrast'
                            : 'bg-success/90 border-success text-success-contrast'
                    }`}>
                        <div className="flex items-center gap-2">
                            {toast.type === 'error' ? (
                                <div className="w-2 h-2 bg-error-contrast rounded-full"></div>
                            ) : (
                                <Check className="w-4 h-4" />
                            )}
                            <span className="text-sm font-medium">{toast.message}</span>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ShoppingList;
