import React, { useState, useEffect } from 'react';
import { LineChart, Line, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { DollarSign, BarChart3, Trophy, TrendingUp } from 'lucide-react';
import analyticsService from '../services/analyticsService';

// Chart colors from theme
const CHART_COLORS = {
    Restaurant: 'var(--color-primary)',
    Grocery: 'var(--color-secondary)',
    Clothing: 'var(--color-accent)',
    Electricity: 'var(--color-success)',
    Others: 'var(--color-warning)'
};

const FALLBACK_COLORS = [
    'var(--color-primary)',
    'var(--color-secondary)',
    'var(--color-accent)',
    'var(--color-success)',
    'var(--color-warning)',
    'var(--color-error)'
];

const DATE_RANGES = [
    { value: '3m', label: '3 Months' },
    { value: '6m', label: '6 Months' },
    { value: '1y', label: '1 Year' },
    { value: 'all', label: 'All Time' }
];

// Icons
const TotalIcon = () => <DollarSign className="w-5 h-5 sm:w-6 sm:h-6" />;
const AverageIcon = () => <BarChart3 className="w-5 h-5 sm:w-6 sm:h-6" />;
const TopIcon = () => <Trophy className="w-5 h-5 sm:w-6 sm:h-6" />;
const TrendIcon = () => <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6" />;

const AnalyticsDashboard = () => {
    const [data, setData] = useState(null);
    const [processedData, setProcessedData] = useState(null);
    const [filteredData, setFilteredData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedRange, setSelectedRange] = useState('6m');
    const [selectedCategories, setSelectedCategories] = useState(new Set());

    useEffect(() => {
        fetchAnalyticsData();
    }, []);

    useEffect(() => {
        if (processedData) {
            const filtered = analyticsService.filterDataByDateRange(processedData, selectedRange);
            setFilteredData(filtered);
        }
    }, [processedData, selectedRange]);

    const fetchAnalyticsData = async () => {
        setLoading(true);
        setError(null);

        try {
            const response = await analyticsService.getMonthlyCategoryData();

            if (response.success) {
                setData(response.data);
                const processed = analyticsService.processAnalyticsData(response.data);
                setProcessedData(processed);

                // Initialize with all categories selected
                const categories = Object.keys(processed.categoryTotals);
                setSelectedCategories(new Set(categories));
            } else {
                setError(response.error);
            }
        } catch (err) {
            setError('Failed to load analytics data');
        } finally {
            setLoading(false);
        }
    };

    const toggleCategory = (category) => {
        const newSelected = new Set(selectedCategories);
        if (newSelected.has(category)) {
            newSelected.delete(category);
        } else {
            newSelected.add(category);
        }
        setSelectedCategories(newSelected);
    };

    // Filter data by selected categories
    const getFilteredChartData = () => {
        if (!filteredData) return { monthlyData: [], categoryBreakdown: [] };

        const filteredMonthlyData = filteredData.monthlyData.map(month => {
            const filtered = { month: month.month, rawMonth: month.rawMonth };
            let total = 0;

            Object.keys(month).forEach(key => {
                if (key !== 'month' && key !== 'rawMonth' && key !== 'total') {
                    if (selectedCategories.has(key)) {
                        filtered[key] = month[key];
                        total += month[key] || 0;
                    }
                }
            });

            filtered.total = total;
            return filtered;
        });

        const filteredCategoryBreakdown = filteredData.categoryBreakdown.filter(
            category => selectedCategories.has(category.name)
        );

        return { monthlyData: filteredMonthlyData, categoryBreakdown: filteredCategoryBreakdown };
    };

    const chartData = getFilteredChartData();

    if (loading) {
        return (
            <div className="min-h-screen bg-background p-4">
                <div className="max-w-7xl mx-auto">
                    <div className="animate-pulse space-y-6">
                        <div className="h-8 bg-surface rounded-lg w-48"></div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                            {[...Array(4)].map((_, i) => (
                                <div key={i} className="h-24 bg-surface rounded-xl"></div>
                            ))}
                        </div>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <div className="h-80 bg-surface rounded-xl"></div>
                            <div className="h-80 bg-surface rounded-xl"></div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="min-h-screen bg-background p-4 flex items-center justify-center">
                <div className="text-center">
                    <div
                        className="font-medium mb-2"
                        style={{
                            color: 'var(--color-error)',
                            fontFamily: 'var(--font-primary)',
                            fontSize: 'var(--font-size-lg)',
                            fontWeight: 'var(--font-weight-medium)'
                        }}
                    >
                        Error Loading Data
                    </div>
                    <div
                        className="mb-4"
                        style={{
                            color: 'var(--color-content-secondary)',
                            fontFamily: 'var(--font-primary)',
                            fontSize: 'var(--font-size-base)'
                        }}
                    >
                        {error}
                    </div>
                    <button
                        onClick={fetchAnalyticsData}
                        className="px-4 py-2 bg-button-primary text-button-primary-text rounded-lg hover:bg-button-primary-hover transition-colors"
                        style={{
                            fontFamily: 'var(--font-primary)',
                            fontSize: 'var(--font-size-sm)',
                            fontWeight: 'var(--font-weight-medium)'
                        }}
                    >
                        Retry
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-4 sm:space-y-6">
            {/* Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
                <h1
                    className="font-semibold text-foreground"
                    style={{
                        fontFamily: 'var(--font-display)',
                        fontSize: 'var(--font-size-xl)',
                        fontWeight: 'var(--font-weight-semibold)',
                        '@media (min-width: 640px)': {
                            fontSize: 'var(--font-size-2xl)'
                        },
                        '@media (min-width: 1024px)': {
                            fontSize: 'var(--font-size-3xl)'
                        }
                    }}
                >
                    Expense Analytics
                </h1>

                {/* Date Range Filter */}
                <div className="flex gap-1 p-1 bg-surface rounded-lg sm:rounded-xl backdrop-blur-md w-full sm:w-auto">
                    {DATE_RANGES.map((range) => (
                        <button
                            key={range.value}
                            onClick={() => setSelectedRange(range.value)}
                            className={`flex-1 sm:flex-none px-2 sm:px-3 py-1.5 sm:py-2 rounded-md sm:rounded-lg font-medium transition-all ${
                                selectedRange === range.value
                                    ? 'bg-primary text-primary-contrast shadow-sm'
                                    : 'text-content-secondary hover:text-foreground hover:bg-surface-hover'
                            }`}
                            style={{
                                fontFamily: 'var(--font-primary)',
                                fontSize: 'var(--font-size-xs)',
                                fontWeight: 'var(--font-weight-medium)',
                                '@media (min-width: 640px)': {
                                    fontSize: 'var(--font-size-sm)'
                                }
                            }}
                        >
                            {range.label}
                        </button>
                    ))}
                </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 lg:gap-4">
                <SummaryCard
                    title="Total Expenses"
                    value={analyticsService.formatCurrency(filteredData?.totalExpenses || 0)}
                    subtitle={`${filteredData?.totalMonths || 0} months`}
                    icon={<TotalIcon />}
                />
                <SummaryCard
                    title="Monthly Avg"
                    value={analyticsService.formatCurrency(filteredData?.averageMonthlySpend || 0)}
                    subtitle="Per month"
                    icon={<AverageIcon />}
                />
                <SummaryCard
                    title="Top Category"
                    value={filteredData?.highestSpendingCategory || 'N/A'}
                    subtitle={`${analyticsService.formatCurrency(filteredData?.categoryTotals[filteredData?.highestSpendingCategory] || 0)}`}
                    icon={<TopIcon />}
                />
                <SummaryCard
                    title="Peak Month"
                    value={filteredData?.highestSpendingMonth?.month || 'N/A'}
                    subtitle={analyticsService.formatCurrency(filteredData?.highestSpendingMonth?.total || 0)}
                    icon={<TrendIcon />}
                />
            </div>

            {/* Category Filters */}
            <div className="bg-glass-primary backdrop-blur-md rounded-lg sm:rounded-xl lg:rounded-2xl p-3 sm:p-4 border border-border shadow-sm">
                <h3
                    className="font-medium text-foreground mb-2 sm:mb-3"
                    style={{
                        fontFamily: 'var(--font-primary)',
                        fontSize: 'var(--font-size-sm)',
                        fontWeight: 'var(--font-weight-medium)',
                        '@media (min-width: 640px)': {
                            fontSize: 'var(--font-size-base)'
                        },
                        '@media (min-width: 1024px)': {
                            fontSize: 'var(--font-size-lg)'
                        }
                    }}
                >
                    Categories
                </h3>
                <div className="flex flex-wrap gap-1.5 sm:gap-2">
                    {Object.keys(filteredData?.categoryTotals || {}).map((category) => (
                        <button
                            key={category}
                            onClick={() => toggleCategory(category)}
                            className={`flex items-center px-2 sm:px-3 py-1.5 sm:py-2 rounded-md sm:rounded-lg font-medium transition-all border ${
                                selectedCategories.has(category)
                                    ? 'bg-primary text-primary-contrast border-primary shadow-sm'
                                    : 'bg-surface text-content-secondary border-border hover:bg-surface-hover hover:text-foreground'
                            }`}
                            style={{
                                fontFamily: 'var(--font-primary)',
                                fontSize: 'var(--font-size-xs)',
                                fontWeight: 'var(--font-weight-medium)',
                                '@media (min-width: 640px)': {
                                    fontSize: 'var(--font-size-sm)'
                                }
                            }}
                        >
              <span
                  className="inline-block w-2 h-2 rounded-full mr-1.5 flex-shrink-0"
                  style={{ backgroundColor: CHART_COLORS[category] || FALLBACK_COLORS[0] }}
              ></span>
                            <span className="truncate max-w-[60px] sm:max-w-none">{category}</span>
                        </button>
                    ))}
                </div>
            </div>

            {/* Charts */}
            <div className="space-y-4 lg:space-y-0 lg:grid lg:grid-cols-2 lg:gap-4 xl:gap-6">
                {/* Line Chart */}
                <div className="bg-glass-primary backdrop-blur-md rounded-lg sm:rounded-xl lg:rounded-2xl p-3 sm:p-4 lg:p-6 border border-border shadow-sm">
                    <h3
                        className="font-medium text-foreground mb-3 sm:mb-4"
                        style={{
                            fontFamily: 'var(--font-primary)',
                            fontSize: 'var(--font-size-sm)',
                            fontWeight: 'var(--font-weight-medium)',
                            '@media (min-width: 640px)': {
                                fontSize: 'var(--font-size-base)'
                            },
                            '@media (min-width: 1024px)': {
                                fontSize: 'var(--font-size-lg)'
                            }
                        }}
                    >
                        Monthly Trends
                    </h3>
                    <div className="h-56 sm:h-64 lg:h-80">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={chartData.monthlyData} margin={{ top: 5, right: 5, left: 0, bottom: 30 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" opacity={0.2} />
                                <XAxis
                                    dataKey="month"
                                    stroke="var(--color-content-tertiary)"
                                    fontSize={9}
                                    tickMargin={8}
                                    angle={-45}
                                    textAnchor="end"
                                    height={50}
                                    interval={0}
                                    style={{ fontFamily: 'var(--font-primary)' }}
                                />
                                <YAxis
                                    stroke="var(--color-content-tertiary)"
                                    fontSize={9}
                                    width={40}
                                    tickFormatter={(value) => analyticsService.formatNumber(value)}
                                    style={{ fontFamily: 'var(--font-primary)' }}
                                />
                                <Tooltip
                                    contentStyle={{
                                        backgroundColor: 'var(--color-tooltip-background)',
                                        border: '1px solid var(--color-border)',
                                        borderRadius: '8px',
                                        backdropFilter: 'blur(20px)',
                                        color: 'var(--color-tooltip-text)',
                                        fontSize: '11px',
                                        padding: '8px',
                                        fontFamily: 'var(--font-primary)'
                                    }}
                                    formatter={(value, name) => [analyticsService.formatCurrency(value), name]}
                                />
                                <Legend
                                    wrapperStyle={{
                                        fontSize: '10px',
                                        fontFamily: 'var(--font-primary)'
                                    }}
                                />
                                {Object.keys(filteredData?.categoryTotals || {}).map((category, index) => (
                                    selectedCategories.has(category) && (
                                        <Line
                                            key={category}
                                            type="monotone"
                                            dataKey={category}
                                            stroke={CHART_COLORS[category] || FALLBACK_COLORS[index % FALLBACK_COLORS.length]}
                                            strokeWidth={2}
                                            dot={{ fill: CHART_COLORS[category] || FALLBACK_COLORS[index % FALLBACK_COLORS.length], strokeWidth: 1, r: 2 }}
                                            activeDot={{ r: 4, strokeWidth: 0 }}
                                        />
                                    )
                                ))}
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Pie Chart */}
                <div className="bg-glass-primary backdrop-blur-md rounded-lg sm:rounded-xl lg:rounded-2xl p-3 sm:p-4 lg:p-6 border border-border shadow-sm">
                    <h3
                        className="font-medium text-foreground mb-3 sm:mb-4"
                        style={{
                            fontFamily: 'var(--font-primary)',
                            fontSize: 'var(--font-size-sm)',
                            fontWeight: 'var(--font-weight-medium)',
                            '@media (min-width: 640px)': {
                                fontSize: 'var(--font-size-base)'
                            },
                            '@media (min-width: 1024px)': {
                                fontSize: 'var(--font-size-lg)'
                            }
                        }}
                    >
                        Category Breakdown
                    </h3>
                    <div className="h-56 sm:h-64 lg:h-80">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={chartData.categoryBreakdown}
                                    cx="50%"
                                    cy="50%"
                                    outerRadius={window.innerWidth < 640 ? 70 : window.innerWidth < 1024 ? 90 : 100}
                                    dataKey="value"
                                    label={({ name, percentage }) => window.innerWidth < 640 ? `${percentage}%` : `${name} ${percentage}%`}
                                    labelLine={false}
                                    fontSize={window.innerWidth < 640 ? 9 : 10}
                                    style={{ fontFamily: 'var(--font-primary)' }}
                                >
                                    {chartData.categoryBreakdown.map((entry, index) => (
                                        <Cell
                                            key={`cell-${index}`}
                                            fill={CHART_COLORS[entry.name] || FALLBACK_COLORS[index % FALLBACK_COLORS.length]}
                                        />
                                    ))}
                                </Pie>
                                <Tooltip
                                    contentStyle={{
                                        backgroundColor: 'var(--color-tooltip-background)',
                                        border: '1px solid var(--color-border)',
                                        borderRadius: '8px',
                                        backdropFilter: 'blur(20px)',
                                        color: 'var(--color-tooltip-text)',
                                        fontSize: '11px',
                                        padding: '8px',
                                        fontFamily: 'var(--font-primary)'
                                    }}
                                    formatter={(value) => [analyticsService.formatCurrency(value), 'Amount']}
                                />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>

            {/* Detailed Category List */}
            <div className="bg-glass-primary backdrop-blur-md rounded-lg sm:rounded-xl lg:rounded-2xl p-3 sm:p-4 lg:p-6 border border-border shadow-sm">
                <h3
                    className="font-medium text-foreground mb-3 sm:mb-4"
                    style={{
                        fontFamily: 'var(--font-primary)',
                        fontSize: 'var(--font-size-sm)',
                        fontWeight: 'var(--font-weight-medium)',
                        '@media (min-width: 640px)': {
                            fontSize: 'var(--font-size-base)'
                        },
                        '@media (min-width: 1024px)': {
                            fontSize: 'var(--font-size-lg)'
                        }
                    }}
                >
                    Category Details
                </h3>
                <div className="space-y-2">
                    {filteredData?.categoryBreakdown.map((category, index) => (
                        <div key={category.name} className="flex items-center justify-between p-2.5 sm:p-3 bg-surface-100 rounded-lg">
                            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                                <div
                                    className="w-3 h-3 rounded-full flex-shrink-0"
                                    style={{ backgroundColor: CHART_COLORS[category.name] || FALLBACK_COLORS[index % FALLBACK_COLORS.length] }}
                                ></div>
                                <span
                                    className="font-medium text-foreground truncate"
                                    style={{
                                        fontFamily: 'var(--font-primary)',
                                        fontSize: 'var(--font-size-xs)',
                                        fontWeight: 'var(--font-weight-medium)',
                                        '@media (min-width: 640px)': {
                                            fontSize: 'var(--font-size-sm)'
                                        },
                                        '@media (min-width: 1024px)': {
                                            fontSize: 'var(--font-size-base)'
                                        }
                                    }}
                                >
                                    {category.name}
                                </span>
                            </div>
                            <div className="text-right flex-shrink-0 ml-2">
                                <div
                                    className="font-semibold text-foreground"
                                    style={{
                                        fontFamily: 'var(--font-primary)',
                                        fontSize: 'var(--font-size-xs)',
                                        fontWeight: 'var(--font-weight-semibold)',
                                        '@media (min-width: 640px)': {
                                            fontSize: 'var(--font-size-sm)'
                                        },
                                        '@media (min-width: 1024px)': {
                                            fontSize: 'var(--font-size-base)'
                                        }
                                    }}
                                >
                                    {analyticsService.formatCurrency(category.value)}
                                </div>
                                <div
                                    style={{
                                        color: 'var(--color-content-tertiary)',
                                        fontFamily: 'var(--font-primary)',
                                        fontSize: 'var(--font-size-xs)',
                                        fontWeight: 'var(--font-weight-normal)'
                                    }}
                                >
                                    {category.percentage}%
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

const SummaryCard = ({ title, value, subtitle, icon }) => {
    return (
        <div className="bg-glass-primary backdrop-blur-md rounded-lg sm:rounded-xl lg:rounded-2xl p-2.5 sm:p-3 lg:p-4 border border-border shadow-sm hover:shadow-md transition-all duration-normal">
            <div className="flex items-center justify-between h-full">
                <div className="flex-1 min-w-0">
                    <div
                        className="font-medium text-content-secondary mb-0.5 sm:mb-1"
                        style={{
                            fontFamily: 'var(--font-primary)',
                            fontSize: 'var(--font-size-xs)',
                            fontWeight: 'var(--font-weight-medium)'
                        }}
                    >
                        {title}
                    </div>
                    <div
                        className="font-semibold text-foreground mb-0.5 sm:mb-1 break-words leading-tight"
                        style={{
                            fontFamily: 'var(--font-primary)',
                            fontSize: 'var(--font-size-sm)',
                            fontWeight: 'var(--font-weight-semibold)',
                            '@media (min-width: 640px)': {
                                fontSize: 'var(--font-size-base)'
                            },
                            '@media (min-width: 1024px)': {
                                fontSize: 'var(--font-size-lg)'
                            }
                        }}
                    >
                        {value}
                    </div>
                    <div
                        className="leading-tight"
                        style={{
                            color: 'var(--color-content-tertiary)',
                            fontFamily: 'var(--font-primary)',
                            fontSize: 'var(--font-size-xs)',
                            fontWeight: 'var(--font-weight-normal)'
                        }}
                    >
                        {subtitle}
                    </div>
                </div>
                <div className="text-primary ml-2 flex-shrink-0">
                    {icon}
                </div>
            </div>
        </div>
    );
};

export default AnalyticsDashboard;
