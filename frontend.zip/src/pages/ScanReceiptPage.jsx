import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ScanScreen, ReceiptHistory } from '../components/receipt/index.js';

const ScanReceiptPage = () => {
    const [currentView, setCurrentView] = useState('scanner'); // 'scanner' | 'history'
    const navigate = useNavigate();

    const handleUploadSuccess = (file) => {
        console.log('Upload successful:', file);
        // You can add additional success handling here
    };

    const handleNavigateHome = () => {
        navigate('/home');
        console.log('Navigate to /home');
    };

    const handleShowHistory = () => {
        setCurrentView('history');
    };

    const handleBackToScanner = () => {
        setCurrentView('scanner');
    };

    if (currentView === 'history') {
        return (
            <ReceiptHistory
                onBack={handleBackToScanner}
                showHeader={true}
                title="Receipt History"
            />
        );
    }

    return (
        <ScanScreen
            onUploadSuccess={handleUploadSuccess}
            onNavigateHome={handleNavigateHome}
            onShowHistory={handleShowHistory}
        />
    );
};

export default ScanReceiptPage;
