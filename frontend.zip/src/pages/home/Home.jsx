import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../../context/ToastContext"; // Adjust path as needed
import chatService from "../../services/chatService"; // Adjust path as needed
import receiptService from "../../services/receiptService"; // Add this import
import {
    HomeIcon,
    MenuIcon,
    HelpIcon,
    LogoutIcon,
    HistoryIcon
} from "@/assets/svg/icons/icons.jsx";

const QUICK_ACTIONS = [
    {
        label: "Scan Receipt",
        icon: HomeIcon,
        path: "/scan-receipt",
    },
    {
        label: "Ask Queries",
        icon: HelpIcon,
        path: "/ask-queries",
    },
    {
        label: "History",
        icon: HistoryIcon,
        path: "/history",
    },
    {
        label: "Shopping List",
        icon: HelpIcon,
        path: "/shopping-list",
    }
];

const Home = () => {
    const [insights, setInsights] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const { showToast } = useToast();

    // Fetch insights on component mount
    useEffect(() => {
        fetchInsights();
    }, []);

    const parseInsightsResponse = (responseText) => {
        try {
            // First, try to parse JSON wrapped in markdown code block
            const jsonMatch = responseText.match(/```json\n(.*?)\n```/s);
            if (jsonMatch) {
                const parsedData = JSON.parse(jsonMatch[1]);
                return parsedData.data || [];
            }

            // If no markdown wrapper, try to parse as direct JSON string
            // Handle case where response might have quotes around it
            let cleanedResponse = responseText.trim();

            // Remove surrounding quotes if present
            if (cleanedResponse.startsWith('"') && cleanedResponse.endsWith('"')) {
                cleanedResponse = cleanedResponse.slice(1, -1);
                // Unescape any escaped quotes
                cleanedResponse = cleanedResponse.replace(/\\"/g, '"');
            }

            // Try to parse the cleaned response
            const parsedData = JSON.parse(cleanedResponse);
            return parsedData.data || [];

        } catch (error) {
            console.error("Error parsing insights response:", error);
            throw new Error("Invalid response format");
        }
    };

    const fetchInsights = async () => {
        try {
            setLoading(true);
            const response = await chatService.getInsights("Give me expense insights");

            if (response.success && response.data?.response) {
                const parsedInsights = parseInsightsResponse(response.data.response);
                setInsights(parsedInsights);

                // Generate insights pass after successfully getting insights
                if (parsedInsights.length > 0) {
                    try {
                        const passResponse = await receiptService.generateInsightsPass(parsedInsights);

                        if (passResponse.success) {
                            console.log('Insights pass generated successfully:', passResponse.data);
                            // Optionally show a success toast
                            showToast("Insights pass generated successfully!", "success");
                        } else {
                            console.error('Failed to generate insights pass:', passResponse.error);
                            // Optionally show an error toast, but don't prevent insights from showing
                            showToast("Failed to generate insights pass", "warning");
                        }
                    } catch (passError) {
                        console.error('Error generating insights pass:', passError);
                        // Don't show error to user since insights are still displayed
                    }
                }
            } else {
                throw new Error(response.error || "Failed to fetch insights");
            }
        } catch (error) {
            console.error("Error fetching insights:", error);
            showToast("Failed to load insights. Please try again.", "error");
            setInsights([]);
        } finally {
            setLoading(false);
        }
    };

    // Handle quick action clicks
    const handleQuickAction = (path) => {
        navigate(path);
    };

    return (
        <div className="w-full min-h-full bg-background font-primary">
            {/* Main Content Area - Proper scrollable container */}
            <div className="w-full h-full overflow-y-auto">
                <main className="flex flex-col items-center justify-start px-lg py-xl">
                    {/* Insights Section */}
                    <div className="w-full max-w-6xl mb-3xl">
                        <div className="text-center mb-2xl">
                            <h1 className="font-semibold leading-tight text-4xl sm:text-5xl md:text-6xl text-foreground mb-md">
                                Insights
                            </h1>
                        </div>

                        {/* Insights Cards Container - Fixed scrolling */}
                        <div className="relative w-full">
                            {loading ? (
                                <InsightsLoadingSkeleton />
                            ) : insights.length > 0 ? (
                                <div className="w-full">
                                    <div
                                        className="flex gap-lg overflow-x-auto pb-md scrollbar-hide"
                                        style={{
                                            scrollbarWidth: 'none',
                                            msOverflowStyle: 'none',
                                        }}
                                    >
                                        {insights.map((insight, index) => (
                                            <InsightCard
                                                key={index}
                                                title={insight.title}
                                                content={insight.insight}
                                            />
                                        ))}
                                    </div>
                                </div>
                            ) : (
                                <div className="text-center py-6xl">
                                    <p className="text-lg text-content-secondary">
                                        No insights available at the moment
                                    </p>
                                    <button
                                        onClick={fetchInsights}
                                        className="mt-lg px-lg py-md bg-button-primary text-button-primary-text rounded-lg hover:bg-button-primary-hover transition-all duration-normal"
                                    >
                                        Retry
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Quick Action Options - 2 per row grid */}
                    <div className="w-full max-w-lg mx-auto">
                        <div className="text-center mb-xl">
                            <h2 className="text-2xl font-semibold text-foreground mb-sm">
                                Quick Actions
                            </h2>
                            <p className="text-base text-content-secondary">
                                Choose from the options below
                            </p>
                        </div>

                        <div className="grid grid-cols-2 gap-lg">
                            {QUICK_ACTIONS.map((action, index) => (
                                <QuickActionButton
                                    key={index}
                                    action={action}
                                    onClick={() => handleQuickAction(action.path)}
                                />
                            ))}
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
};

// Insight Card Component - Using theme variables consistently
const InsightCard = ({ title, content }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const maxLength = 120; // Approximate character limit for the card
    const shouldShowSeeMore = content.length > maxLength;
    const displayContent = isExpanded ? content : content.slice(0, maxLength);

    return (
        <div className="flex-shrink-0 w-80 rounded-2xl bg-glass-primary backdrop-blur-md backdrop-saturate-[190%] backdrop-brightness-110 border border-border shadow-sm transition-all duration-normal">
            <div className="p-xl h-full flex flex-col">
                {/* Header */}
                <div className="mb-lg flex-shrink-0 pb-sm border-b border-border">
                    <h3 className="text-lg font-semibold text-content-primary leading-tight">
                        {title}
                    </h3>
                    <div className="w-12 h-1 bg-primary rounded-full mt-sm"></div>
                </div>

                {/* Content - Fixed overflow and alignment */}
                <div className="flex-1 flex flex-col justify-between pt-sm">
                    <div className="flex-1">
                        <p className="text-sm text-content-secondary leading-relaxed break-words">
                            {displayContent}
                            {!isExpanded && shouldShowSeeMore && '...'}
                        </p>
                    </div>

                    {shouldShowSeeMore && (
                        <div className="mt-md pt-sm border-t border-border">
                            <button
                                onClick={() => setIsExpanded(!isExpanded)}
                                className="text-xs text-primary hover:text-primary-light transition-colors duration-normal font-medium"
                            >
                                {isExpanded ? 'See less' : 'See more'}
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

// Loading Skeleton for Insights - Using theme variables
const InsightsLoadingSkeleton = () => {
    return (
        <div className="w-full">
            <div
                className="flex gap-lg overflow-x-auto pb-md scrollbar-hide"
                style={{
                    scrollbarWidth: 'none',
                    msOverflowStyle: 'none',
                }}
            >
                {[1, 2, 3].map((item) => (
                    <div
                        key={item}
                        className="flex-shrink-0 w-80 h-48 p-xl rounded-2xl bg-glass-primary backdrop-blur-md border border-border animate-pulse"
                    >
                        {/* Header skeleton */}
                        <div className="mb-lg">
                            <div className="h-5 bg-skeleton-base rounded w-24 mb-sm"></div>
                            <div className="w-12 h-1 bg-skeleton-base rounded-full"></div>
                        </div>

                        {/* Content skeleton */}
                        <div className="space-y-sm">
                            <div className="h-4 bg-skeleton-base rounded w-full"></div>
                            <div className="h-4 bg-skeleton-base rounded w-5/6"></div>
                            <div className="h-4 bg-skeleton-base rounded w-4/5"></div>
                            <div className="h-4 bg-skeleton-base rounded w-3/4"></div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

// Quick Action Button Component - Using theme variables consistently
const QuickActionButton = ({ action, onClick }) => {
    return (
        <button
            onClick={onClick}
            className="group relative flex flex-col items-center justify-center min-h-[140px] p-xl rounded-3xl bg-surface backdrop-blur-md backdrop-saturate-[190%] backdrop-brightness-110 shadow-md transition-all duration-normal focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background hover:bg-surface-hover hover:scale-105 hover:shadow-card-hover active:scale-95"
        >
            <div className="flex flex-col items-center text-center gap-md">
                {/* Icon Container */}
                <div className="w-14 h-14 flex items-center justify-center rounded-2xl bg-primary-glass transition-all duration-normal group-hover:scale-110">
                    <action.icon
                        size={28}
                        filled={false}
                        className="text-primary transition-colors duration-normal"
                    />
                </div>

                {/* Label */}
                <h3 className="text-base font-semibold leading-tight text-content-primary transition-colors duration-normal">
                    {action.label}
                </h3>
            </div>

            {/* Subtle glass effect on hover */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-normal pointer-events-none rounded-3xl">
                <div className="absolute inset-0 rounded-3xl bg-glass-light backdrop-blur-sm"></div>
            </div>
        </button>
    );
};

export default Home;
