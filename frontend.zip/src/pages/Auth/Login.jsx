import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

// Import our custom components
import ThemeToggle from '../../components/ui/ThemeToggle';
import TextField from '../../components/common/TextField/TextField';
import Button from '../../components/common/Button/Button';
import Alert from '../../components/common/Alert/Alert';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Call login from auth context
      const response = await login(email, password);

      if (response.success) {
        showToast('Login successful', 'success');
        // Redirect to dashboard after successful login
        navigate('/');
      } else {
        setError(response.message || 'Login failed. Please check your credentials.');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError(
          err.data?.message ||
          'Unable to login. Please check your credentials or try again later.'
      );
    } finally {
      setLoading(false);
    }
  };

  // Custom input styling based on theme
  const inputClassName = "rounded-md border border-border bg-input glass glass-border";

  return (
      <div className="min-h-screen flex flex-col bg-background font-primary">
        {/* Top bar with theme toggle and logo */}
        <div className="w-full p-4 flex justify-between items-center border-b border-border glass glass-border">
          <div className="text-2xl font-semibold text-primary">
            <span className="font-secondary">Think</span>
            <span className="font-bold">GPT</span>
          </div>
          <ThemeToggle />
        </div>

        <div className="flex-1 flex items-center justify-center px-4 py-8">
          <div className="w-full max-w-md p-8 bg-surface glass glass-border rounded-lg shadow-card">
            {/* Header section */}
            <div className="text-center mb-8">
              <h1 className="text-3xl font-semibold text-foreground font-secondary">
                Welcome Back
              </h1>
              <p className="text-content-secondary mt-2 font-primary">
                Sign in to your account
              </p>
            </div>

            {/* Error alert */}
            {error && (
                <Alert
                    variant="error"
                    className="mb-6"
                >
                  {error}
                </Alert>
            )}

            {/* Form section */}
            <form onSubmit={handleSubmit} className="space-y-6">
              <TextField
                  id="email"
                  label="Email Address"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  required
                  inputClassName={inputClassName}
                  labelClassName="font-secondary"
              />

              <TextField
                  id="password"
                  label="Password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  inputClassName={inputClassName}
                  labelClassName="font-secondary"
              />

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                      id="remember-me"
                      name="remember-me"
                      type="checkbox"
                      className="h-4 w-4 text-primary focus:ring-primary-light border-border rounded-sm"
                  />
                  <label htmlFor="remember-me" className="ml-2 block text-sm text-content-secondary font-primary">
                    Remember me
                  </label>
                </div>

                <div className="text-sm">
                  <a href="/forgot-password" className="font-medium text-content-link hover:text-content-link-hover transition-colors">
                    Forgot your password?
                  </a>
                </div>
              </div>

              <Button
                  type="submit"
                  variant="primary"
                  fullWidth
                  isLoading={loading}
                  className="py-2.5 font-secondary font-medium text-base"
              >
                Sign In
              </Button>

              {/* Create account link */}
              <div className="text-center mt-6">
              <span className="text-content-secondary font-primary text-sm">
                Don't have an account?{' '}
              </span>
                <a href="/signup" className="font-medium text-content-link hover:text-content-link-hover transition-colors">
                  Create account
                </a>
              </div>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 text-center text-content-tertiary text-sm font-primary">
          <p>© 2025 ThinkGPT. All rights reserved.</p>
        </div>
      </div>
  );
};

export default Login;
