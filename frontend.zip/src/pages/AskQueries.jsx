import React, { useState, useRef, useEffect } from 'react';
import chatService from '../services/chatService';
import receiptService from '../services/receiptService';
import { useToast } from '../context/ToastContext';

const AskQueries = () => {
    const [messages, setMessages] = useState([]);
    const [inputMessage, setInputMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [sessionId, setSessionId] = useState(null);
    const [walletLoadingStates, setWalletLoadingStates] = useState({});
    const [showDialog, setShowDialog] = useState(false);
    const [dialogConfig, setDialogConfig] = useState({});
    const messagesEndRef = useRef(null);
    const inputRef = useRef(null);
    const { showToast } = useToast();

    // Auto scroll to bottom when new messages are added
    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    // Focus input on component mount
    useEffect(() => {
        inputRef.current?.focus();
    }, []);

    // Function to extract JSON from markdown code block
    const extractJsonFromResponse = (response) => {
        const jsonPattern = /```json\s*(\{[\s\S]*?\})\s*```/;
        const match = response.match(jsonPattern);

        if (match) {
            try {
                const jsonData = JSON.parse(match[1]);
                return jsonData;
            } catch (error) {
                console.error('Failed to parse JSON:', error);
                return null;
            }
        }
        return null;
    };

    // Custom Dialog Component
    const Dialog = ({ isOpen, onClose, onConfirm, title, message, confirmText = "Confirm", cancelText = "Cancel", isConfirming = false }) => {
        if (!isOpen) return null;

        return (
            <div
                className="fixed inset-0 z-modal flex items-center justify-center p-4"
                style={{ backgroundColor: 'var(--color-overlay-modal)' }}
            >
                <div
                    className="relative w-full max-w-md backdrop-blur-md rounded-lg shadow-lg"
                    style={{
                        backgroundColor: 'var(--color-surface)',
                        border: '1px solid var(--color-border)',
                    }}
                >
                    {/* Header */}
                    <div className="px-6 py-4 border-b" style={{ borderColor: 'var(--color-border)' }}>
                        <h3
                            className="font-semibold"
                            style={{
                                color: 'var(--color-content-primary)',
                                fontFamily: 'var(--font-primary)',
                                fontSize: 'var(--font-size-lg)',
                                fontWeight: 'var(--font-weight-semibold)'
                            }}
                        >
                            {title}
                        </h3>
                    </div>

                    {/* Content */}
                    <div className="px-6 py-4">
                        <p
                            style={{
                                color: 'var(--color-content-secondary)',
                                fontFamily: 'var(--font-primary)',
                                fontSize: 'var(--font-size-base)',
                                lineHeight: 'var(--line-height-normal)'
                            }}
                        >
                            {message}
                        </p>
                    </div>

                    {/* Footer */}
                    <div className="px-6 py-4 flex justify-end space-x-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
                        <button
                            onClick={onClose}
                            disabled={isConfirming}
                            className="px-4 py-2 rounded-md transition-all duration-200 disabled:opacity-50"
                            style={{
                                backgroundColor: 'var(--color-button-secondary)',
                                color: 'var(--color-button-secondary-text)',
                                border: '1px solid var(--color-border)',
                                fontFamily: 'var(--font-primary)',
                                fontSize: 'var(--font-size-sm)',
                                fontWeight: 'var(--font-weight-medium)'
                            }}
                        >
                            {cancelText}
                        </button>
                        <button
                            onClick={onConfirm}
                            disabled={isConfirming}
                            className="px-4 py-2 rounded-md transition-all duration-200 disabled:opacity-50 inline-flex items-center"
                            style={{
                                backgroundColor: 'var(--color-button-primary)',
                                color: 'var(--color-button-primary-text)',
                                border: '1px solid var(--color-primary)',
                                fontFamily: 'var(--font-primary)',
                                fontSize: 'var(--font-size-sm)',
                                fontWeight: 'var(--font-weight-medium)'
                            }}
                        >
                            {isConfirming && (
                                <svg
                                    className="w-4 h-4 mr-2 animate-spin"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                >
                                    <circle
                                        className="opacity-25"
                                        cx="12"
                                        cy="12"
                                        r="10"
                                        stroke="currentColor"
                                        strokeWidth="4"
                                    />
                                    <path
                                        className="opacity-75"
                                        fill="currentColor"
                                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                    />
                                </svg>
                            )}
                            {confirmText}
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    // Handle wallet pass generation
    const handleAddToWallet = async (messageId, receiptData) => {
        // Show confirmation dialog
        setDialogConfig({
            title: 'Add to Wallet',
            message: 'Do you want to add this receipt to your wallet?',
            onConfirm: () => confirmAddToWallet(messageId, receiptData),
            onClose: () => setShowDialog(false),
            confirmText: 'Add to Wallet',
            cancelText: 'Cancel'
        });
        setShowDialog(true);
    };

    const confirmAddToWallet = async (messageId, receiptData) => {
        // Set loading state for dialog
        setDialogConfig(prev => ({ ...prev, isConfirming: true }));

        // Set loading state for this specific message
        setWalletLoadingStates(prev => ({ ...prev, [messageId]: true }));

        try {
            // Prepare payload excluding agent_response
            const { agent_response, ...payload } = receiptData;

            const response = await receiptService.generatePass(payload);

            if (response.success) {
                showToast('Pass created successfully!', 'success');

                // Update the message to remove the button
                setMessages(prev => prev.map(msg =>
                    msg.id === messageId
                        ? { ...msg, walletAdded: true }
                        : msg
                ));

                // Close current dialog
                setShowDialog(false);

                // Show redirect confirmation dialog
                setDialogConfig({
                    title: 'Success!',
                    message: 'Wallet pass created successfully! Do you want to open your wallet now?',
                    onConfirm: () => {
                        setShowDialog(false);
                        if (response.walletLink) {
                            window.open(response.walletLink, '_blank');
                        }
                    },
                    onClose: () => setShowDialog(false),
                    confirmText: 'Open Wallet',
                    cancelText: 'Later'
                });
                setShowDialog(true);
            } else {
                setShowDialog(false);
                showToast(response.error || 'Failed to create wallet pass', 'error');
            }
        } catch (error) {
            console.error('Wallet generation error:', error);
            setShowDialog(false);
            showToast('Something went wrong while creating the wallet pass', 'error');
        } finally {
            // Remove loading state
            setWalletLoadingStates(prev => {
                const newState = { ...prev };
                delete newState[messageId];
                return newState;
            });
        }
    };

    const handleSendMessage = async () => {
        if (!inputMessage.trim() || isLoading) return;

        const userMessage = inputMessage.trim();
        setInputMessage('');

        // Add user message to chat
        const newUserMessage = {
            id: Date.now(),
            type: 'user',
            content: userMessage,
            timestamp: new Date()
        };

        setMessages(prev => [...prev, newUserMessage]);
        setIsLoading(true);

        try {
            // Send message to API
            const response = await chatService.sendMessage(userMessage, sessionId);

            if (response.success) {
                // Update sessionId if this is the first message
                if (!sessionId && response.data.sessionId) {
                    setSessionId(response.data.sessionId);
                }

                // Check if response contains JSON receipt data
                const receiptData = extractJsonFromResponse(response.data.response);

                // Add AI response to chat
                const aiMessage = {
                    id: Date.now() + 1,
                    type: 'ai',
                    content: receiptData ? receiptData.agent_response : response.data.response,
                    timestamp: new Date(),
                    receiptData: receiptData,
                    walletAdded: false
                };

                setMessages(prev => [...prev, aiMessage]);
            } else {
                // Add error message to chat
                const errorMessage = {
                    id: Date.now() + 1,
                    type: 'error',
                    content: `Error: ${response.error}`,
                    timestamp: new Date()
                };

                setMessages(prev => [...prev, errorMessage]);
            }
        } catch (error) {
            // Add system error message to chat
            const systemErrorMessage = {
                id: Date.now() + 1,
                type: 'error',
                content: 'Something went wrong. Please try again.',
                timestamp: new Date()
            };

            setMessages(prev => [...prev, systemErrorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    };

    const TypingIndicator = () => (
        <div className="flex items-start space-x-3 mb-6">
            <div className="flex-shrink-0">
                <div
                    className="w-8 h-8 rounded-full flex items-center justify-center font-semibold backdrop-blur-md"
                    style={{
                        backgroundColor: 'var(--color-glass-primary)',
                        color: 'var(--color-content-primary)',
                        border: '1px solid var(--color-border-light)',
                        fontFamily: 'var(--font-primary)',
                        fontSize: 'var(--font-size-chat-small)'
                    }}
                >
                    AI
                </div>
            </div>
            <div
                className="px-4 py-3 rounded-2xl max-w-xs lg:max-w-md backdrop-blur-md"
                style={{
                    backgroundColor: 'var(--color-glass-secondary)',
                    color: 'var(--color-content-primary)',
                    border: '1px solid var(--color-border-light)'
                }}
            >
                <div className="flex space-x-1">
                    <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: 'var(--color-content-tertiary)' }}></div>
                    <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: 'var(--color-content-tertiary)', animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: 'var(--color-content-tertiary)', animationDelay: '0.4s' }}></div>
                </div>
            </div>
        </div>
    );

    const WalletButton = ({ messageId, receiptData }) => {
        const isLoading = walletLoadingStates[messageId];

        return (
            <button
                onClick={() => handleAddToWallet(messageId, receiptData)}
                disabled={isLoading}
                className="inline-flex items-center px-4 py-2 rounded-full transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed backdrop-blur-md mt-3"
                style={{
                    backgroundColor: 'var(--color-primary)',
                    color: 'var(--color-primary-contrast)',
                    border: '1px solid var(--color-primary)',
                    fontFamily: 'var(--font-primary)',
                    fontSize: 'var(--font-size-chat-small)',
                    fontWeight: 'var(--font-weight-medium)'
                }}
            >
                {isLoading ? (
                    <>
                        <svg
                            className="w-4 h-4 mr-2 animate-spin"
                            fill="none"
                            viewBox="0 0 24 24"
                        >
                            <circle
                                className="opacity-25"
                                cx="12"
                                cy="12"
                                r="10"
                                stroke="currentColor"
                                strokeWidth="4"
                            />
                            <path
                                className="opacity-75"
                                fill="currentColor"
                                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            />
                        </svg>
                        Adding to Wallet...
                    </>
                ) : (
                    <>
                        <svg
                            className="w-4 h-4 mr-2"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                            />
                        </svg>
                        Add to Wallet
                    </>
                )}
            </button>
        );
    };

    const MessageBubble = ({ message }) => {
        const isUser = message.type === 'user';
        const isError = message.type === 'error';
        const hasReceiptData = message.receiptData && !message.walletAdded;

        return (
            <div className={`flex ${isUser ? 'justify-end' : 'items-start space-x-3'} mb-6`}>
                {!isUser && (
                    <div className="flex-shrink-0">
                        <div
                            className="w-8 h-8 rounded-full flex items-center justify-center font-semibold backdrop-blur-md"
                            style={{
                                backgroundColor: isError ? 'var(--color-error-surface)' : 'var(--color-glass-primary)',
                                color: isError ? 'var(--color-error)' : 'var(--color-content-primary)',
                                border: `1px solid ${isError ? 'var(--color-error)' : 'var(--color-border-light)'}`,
                                fontFamily: 'var(--font-primary)',
                                fontSize: 'var(--font-size-chat-small)'
                            }}
                        >
                            {isError ? '!' : 'AI'}
                        </div>
                    </div>
                )}

                <div className={`max-w-xs lg:max-w-md ${isUser ? 'ml-auto' : ''}`}>
                    <div
                        className={`px-4 py-3 backdrop-blur-md ${isUser ? 'rounded-3xl' : 'rounded-2xl'} break-words`}
                        style={{
                            backgroundColor: isUser
                                ? 'var(--color-primary-glass)'
                                : isError
                                    ? 'var(--color-error-surface)'
                                    : 'var(--color-glass-secondary)',
                            color: isUser
                                ? 'var(--color-content-primary)'
                                : isError
                                    ? 'var(--color-error)'
                                    : 'var(--color-content-primary)',
                            border: `1px solid ${isUser
                                ? 'var(--color-primary)'
                                : isError
                                    ? 'var(--color-error)'
                                    : 'var(--color-border-light)'}`,
                            wordWrap: 'break-word',
                            overflowWrap: 'break-word'
                        }}
                    >
                        <p
                            className="whitespace-pre-wrap"
                            style={{
                                fontFamily: 'var(--font-primary)',
                                fontSize: 'var(--font-size-chat-base)',
                                lineHeight: 'var(--line-height-chat)',
                                fontWeight: 'var(--font-weight-normal)',
                                letterSpacing: 'var(--letter-spacing-normal)'
                            }}
                        >
                            {message.content}
                        </p>

                        {hasReceiptData && (
                            <WalletButton
                                messageId={message.id}
                                receiptData={message.receiptData}
                            />
                        )}
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="flex flex-col h-full min-h-0">
            {/* Custom Dialog */}
            <Dialog
                isOpen={showDialog}
                onClose={dialogConfig.onClose}
                onConfirm={dialogConfig.onConfirm}
                title={dialogConfig.title}
                message={dialogConfig.message}
                confirmText={dialogConfig.confirmText}
                cancelText={dialogConfig.cancelText}
                isConfirming={dialogConfig.isConfirming}
            />

            {/* Messages Container - Scrollable area that takes remaining space */}
            <div className="flex-1 overflow-y-auto min-h-0 px-4 py-6">
                <div className="max-w-4xl mx-auto">
                    {messages.length === 0 ? (
                        <div className="flex items-center justify-center h-full min-h-[400px]">
                            <div className="text-center">
                                <div
                                    className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center font-bold backdrop-blur-md"
                                    style={{
                                        backgroundColor: 'var(--color-glass-primary)',
                                        color: 'var(--color-content-primary)',
                                        border: '1px solid var(--color-border-light)',
                                        fontFamily: 'var(--font-primary)',
                                        fontSize: 'var(--font-size-2xl)'
                                    }}
                                >
                                    AI
                                </div>
                                <h2
                                    className="font-semibold mb-2"
                                    style={{
                                        color: 'var(--color-content-primary)',
                                        fontFamily: 'var(--font-display)',
                                        fontSize: 'var(--font-size-xl)',
                                        fontWeight: 'var(--font-weight-semibold)'
                                    }}
                                >
                                    How can I help you today?
                                </h2>
                                <p
                                    style={{
                                        color: 'var(--color-content-tertiary)',
                                        fontFamily: 'var(--font-primary)',
                                        fontSize: 'var(--font-size-sm)',
                                        fontWeight: 'var(--font-weight-normal)'
                                    }}
                                >
                                    Ask me anything about your receipts and purchases
                                </p>
                            </div>
                        </div>
                    ) : (
                        <>
                            {messages.map((message) => (
                                <MessageBubble key={message.id} message={message} />
                            ))}
                            {isLoading && <TypingIndicator />}
                            <div ref={messagesEndRef} />
                        </>
                    )}
                </div>
            </div>

            {/* Input Area - Fixed at bottom without top border */}
            <div className="flex-shrink-0 px-4 py-4">
                <div className="max-w-4xl mx-auto">
                    <div className="relative flex items-center space-x-3">
                        <div className="flex-1 relative">
                            <textarea
                                ref={inputRef}
                                value={inputMessage}
                                onChange={(e) => setInputMessage(e.target.value)}
                                onKeyPress={handleKeyPress}
                                placeholder="Ask anything"
                                disabled={isLoading}
                                rows={1}
                                className="w-full px-4 py-3 rounded-full border-none outline-none resize-none backdrop-blur-md transition-all duration-200"
                                style={{
                                    backgroundColor: 'var(--color-glass-primary)',
                                    color: 'var(--color-content-primary)',
                                    border: '1px solid var(--color-border-light)',
                                    minHeight: '48px',
                                    maxHeight: '120px',
                                    fontFamily: 'var(--font-primary)',
                                    fontSize: 'var(--font-size-chat-base)',
                                    fontWeight: 'var(--font-weight-normal)',
                                    lineHeight: 'var(--line-height-normal)',
                                    letterSpacing: 'var(--letter-spacing-normal)'
                                }}
                                onInput={(e) => {
                                    e.target.style.height = 'auto';
                                    e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
                                }}
                            />
                        </div>

                        <button
                            onClick={handleSendMessage}
                            disabled={!inputMessage.trim() || isLoading}
                            className="p-3 rounded-full transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed backdrop-blur-md flex items-center justify-center"
                            style={{
                                backgroundColor: inputMessage.trim() && !isLoading
                                    ? 'var(--color-primary)'
                                    : 'var(--color-glass-secondary)',
                                color: 'var(--color-primary-contrast)',
                                border: `1px solid ${inputMessage.trim() && !isLoading
                                    ? 'var(--color-primary)'
                                    : 'var(--color-border-light)'}`
                            }}
                        >
                            <svg
                                className="w-5 h-5"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AskQueries;
