import React from 'react';
import { Link } from 'react-router-dom';
import NotFound404SVG from '../../assets/svg/notFoundPage/NotFound404SVG';

const NotFoundPage = () => {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-md bg-surface">
            <div className="w-full max-w-3xl mx-auto text-center">
                <div className="mb-lg">
                    <NotFound404SVG />
                </div>

                <h1 className="text-4xl md:text-5xl font-bold text-content-primary mb-sm">
                    Page Not Found
                </h1>

                <p className="text-lg text-content-secondary mb-xl max-w-lg mx-auto">
                    Sorry, we couldn't find the page you're looking for. It might have been moved, deleted, or perhaps never existed.
                </p>

                <div className="flex flex-col sm:flex-row gap-md justify-center">
                    <Link
                        to="/"
                        className="px-lg py-sm bg-button-primary text-button-primary-text rounded-lg hover:bg-button-primary-hover transition-colors duration-fast font-medium"
                    >
                        Return Home
                    </Link>

                    <button
                        onClick={() => window.history.back()}
                        className="px-lg py-sm bg-button-secondary text-button-secondary-text rounded-lg hover:bg-button-secondary-hover transition-colors duration-fast font-medium"
                    >
                        Go Back
                    </button>
                </div>
            </div>
        </div>
    );
};

export default NotFoundPage;
