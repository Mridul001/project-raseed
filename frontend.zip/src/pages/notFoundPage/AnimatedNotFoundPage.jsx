import React from 'react';
import { Link } from 'react-router-dom';
import AnimatedNotFound404SVG from '../../assets/svg/notFoundPage/AnimatedNotFound404SVG';

const AnimatedNotFoundPage = () => {
    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-md bg-surface bg-gradient-to-br from-surface-100 to-surface-200">
            <div className="w-full max-w-4xl mx-auto text-center">
                <div className="mb-lg relative">
                    <AnimatedNotFound404SVG />
                </div>

                <h1 className="text-4xl md:text-6xl font-bold mb-sm bg-clip-text text-transparent bg-gradient-primary-to-secondary">
                    Page Not Found
                </h1>

                <p className="text-lg md:text-xl text-content-secondary mb-xl max-w-lg mx-auto">
                    Sorry, we couldn't find the page you're looking for. It might have been moved, deleted, or perhaps never existed.
                </p>

                <div className="flex flex-col sm:flex-row gap-md justify-center">
                    <Link
                        to="/"
                        className="group px-lg py-sm bg-button-primary text-button-primary-text rounded-lg font-medium transition-all duration-normal
                      hover:bg-button-primary-hover hover:shadow-lg hover:-translate-y-1"
                    >
                        <span className="flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 transition-transform duration-normal group-hover:-translate-x-1" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
                            </svg>
                            Return Home
                        </span>
                    </Link>

                    <button
                        onClick={() => window.history.back()}
                        className="group px-lg py-sm bg-button-secondary text-button-secondary-text rounded-lg font-medium transition-all duration-normal
                      hover:bg-button-secondary-hover hover:shadow-md hover:-translate-y-1"
                    >
                        <span className="flex items-center justify-center">
                            Go Back
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2 transition-transform duration-normal group-hover:translate-x-1" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
                            </svg>
                        </span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AnimatedNotFoundPage;
