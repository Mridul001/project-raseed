import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import InteractiveNotFound404SVG from '../../assets/svg/notFoundPage/InteractiveNotFound404SVG';

const InteractiveNotFoundPage = () => {
    const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
    const [scale, setScale] = useState(1);

    // Track mouse position for parallax effect
    useEffect(() => {
        const handleMouseMove = (e) => {
            // Get mouse position relative to the center of the screen
            const x = (e.clientX / window.innerWidth - 0.5) * 20;
            const y = (e.clientY / window.innerHeight - 0.5) * 20;
            setMousePosition({ x, y });
        };

        window.addEventListener('mousemove', handleMouseMove);
        return () => window.removeEventListener('mousemove', handleMouseMove);
    }, []);

    // Pulse animation for the 404 container
    useEffect(() => {
        const interval = setInterval(() => {
            setScale(prev => (prev === 1 ? 1.02 : 1));
        }, 2000);

        return () => clearInterval(interval);
    }, []);

    // Create a random floating particle
    const Particle = ({ size, color, speed, delay, xPos, yPos }) => {
        const [position, setPosition] = useState({ x: xPos, y: yPos });

        useEffect(() => {
            const moveParticle = () => {
                const randomX = (Math.random() - 0.5) * 2;
                const randomY = (Math.random() - 0.5) * 2;

                setPosition(prev => ({
                    x: prev.x + randomX,
                    y: prev.y + randomY
                }));
            };

            const timeout = setTimeout(() => {
                const interval = setInterval(moveParticle, speed);
                return () => clearInterval(interval);
            }, delay);

            return () => clearTimeout(timeout);
        }, [speed, delay]);

        return (
            <div
                className={`absolute rounded-full ${color}`}
                style={{
                    width: `${size}px`,
                    height: `${size}px`,
                    left: `calc(${position.x}% - ${size / 2}px)`,
                    top: `calc(${position.y}% - ${size / 2}px)`,
                    transition: `all ${speed / 1000}s ease-in-out`
                }}
            />
        );
    };

    // Generate random particles
    const particles = Array.from({ length: 15 }, (_, i) => ({
        id: i,
        size: Math.random() * 20 + 5,
        color: [
            'bg-primary-light/20',
            'bg-primary/30',
            'bg-secondary-light/20',
            'bg-secondary/30',
            'bg-accent-light/20',
            'bg-accent/30'
        ][Math.floor(Math.random() * 6)],
        speed: Math.random() * 3000 + 2000,
        delay: Math.random() * 1000,
        xPos: Math.random() * 100,
        yPos: Math.random() * 100
    }));

    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-md bg-surface relative overflow-hidden">
            {/* Floating particles background */}
            {particles.map(particle => (
                <Particle key={particle.id} {...particle} />
            ))}

            <div
                className="w-full max-w-4xl mx-auto text-center relative z-10"
                style={{
                    transform: `scale(${scale}) translate(${mousePosition.x}px, ${mousePosition.y}px)`,
                    transition: 'transform 0.5s ease-out'
                }}
            >
                <div className="mb-xl relative">
                    <InteractiveNotFound404SVG />
                </div>

                <h1 className="text-4xl md:text-6xl font-bold mb-sm relative">
                    <span className="bg-clip-text text-transparent bg-gradient-primary-to-secondary">
                        Page Not Found
                    </span>
                    <div className="absolute -top-3 -right-3 md:-top-4 md:-right-4 h-12 w-12 md:h-16 md:w-16 rounded-full bg-error-surface flex items-center justify-center animate-pulse">
                        <span className="text-xl md:text-2xl font-bold text-error">404</span>
                    </div>
                </h1>

                <p className="text-lg md:text-xl text-content-secondary mb-xl max-w-lg mx-auto leading-relaxed">
                    We've looked everywhere, but this page has wandered off into the digital wilderness. Perhaps it's on an adventure?
                </p>

                <div className="flex flex-col sm:flex-row gap-md justify-center">
                    <Link
                        to="/"
                        className="group relative overflow-hidden px-lg py-sm bg-button-primary text-button-primary-text rounded-lg font-medium transition-all duration-normal
                        hover:bg-button-primary-hover transform hover:-translate-y-1 hover:shadow-lg"
                    >
                        {/* Button background animation */}
                        <span className="absolute inset-0 w-full h-full opacity-0 group-hover:opacity-20">
                            <svg className="w-full h-full">
                                <rect width="100%" height="100%" fill="white" className="animate-pulse" />
                            </svg>
                        </span>

                        <span className="relative flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 transition-transform duration-normal group-hover:-translate-x-1" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
                            </svg>
                            Return Home
                        </span>
                    </Link>

                    <button
                        onClick={() => window.history.back()}
                        className="group relative overflow-hidden px-lg py-sm bg-button-secondary text-button-secondary-text rounded-lg font-medium transition-all duration-normal
                        hover:bg-button-secondary-hover transform hover:-translate-y-1 hover:shadow-md"
                    >
                        {/* Button background animation */}
                        <span className="absolute inset-0 w-full h-full opacity-0 group-hover:opacity-10">
                            <svg className="w-full h-full">
                                <rect width="100%" height="100%" fill="white" className="animate-pulse" />
                            </svg>
                        </span>

                        <span className="relative flex items-center justify-center">
                            Go Back
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2 transition-transform duration-normal group-hover:translate-x-1" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
                            </svg>
                        </span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default InteractiveNotFoundPage;
