import { createContext } from 'react';

// Create the theme context with default values
export const ThemeContext = createContext({
  theme: {},
  themeName: 'light',
  setTheme: () => {},
  toggleTheme: () => {},
  themes: {}
});