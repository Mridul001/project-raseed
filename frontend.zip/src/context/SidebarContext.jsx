import { createContext, useState, useEffect } from 'react';

export const SidebarContext = createContext({
  isOpen: true,
  setIsOpen: () => {},
  toggleSidebar: () => {},
});

export const SidebarProvider = ({ children }) => {
  // Initialize sidebar state - open on desktop by default, closed on mobile
  const getInitialState = () => {
    if (typeof window !== 'undefined') {
      // Check localStorage first
      const storedState = localStorage.getItem('sidebarOpen');
      if (storedState !== null) {
        return storedState === 'true';
      }
      // Default based on screen size
      return window.innerWidth >= 768;
    }
    return true; // Default when window is not available
  };
  
  const [isOpen, setIsOpen] = useState(getInitialState);
  
  const toggleSidebar = () => {
    setIsOpen(prevState => {
      const newState = !prevState;
      // Save state in localStorage
      if (typeof window !== 'undefined') {
        localStorage.setItem('sidebarOpen', String(newState));
      }
      return newState;
    });
  };

  // Handle window resize - only close on small screens, don't auto open on large
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const value = {
    isOpen,
    setIsOpen,
    toggleSidebar,
  };

  return <SidebarContext.Provider value={value}>{children}</SidebarContext.Provider>;
};