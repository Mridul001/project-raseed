import { createContext, useState, useContext, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "./ToastContext";
import authService from '../services/authService';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [mounted, setMounted] = useState(false);
  const hasLoggedOutRef = useRef(false);
  const isRedirectingRef = useRef(false);
  const { error: showErrorToast, success: showSuccessToast } = useToast();

  const logout = (reason) => {
    // Prevent multiple redirects
    if (isRedirectingRef.current) return;
    isRedirectingRef.current = true;

    // First handle the logout logic
    authService.logout();
    setUser(null);

    // Then show the toast message based on reason
    // Using a slight delay to ensure the toast shows up
    setTimeout(() => {
      if (reason === "expired") {
        showErrorToast(
          "Please log in again.",
          "Session Expired",
          { position: 'top-center' }
        );
      } else if (reason === "unauthorized") {
        showErrorToast(
          "Please log in again with appropriate credentials.",
          "Unauthorized Access",
          { position: 'top-center' }
        );
      } else {
        showSuccessToast(
          "You have been logged out successfully.",
          "Logged Out",
        );
      }

      // Delay redirect slightly to allow toast to be seen
      setTimeout(() => {
        // Use replace to prevent back navigation to protected pages
        navigate("/login", { replace: true });
        isRedirectingRef.current = false;
      }, 1000);
    }, 100);
  };

  // Login function using authService
  const login = async (email, password) => {
    try {
      const response = await authService.login(email, password);

      if (response.success) {
        setUser(response.data.user);
        // Show success toast after successful login
        // showSuccessToast(
        //   "You have been logged in successfully.",
        //   "Welcome Back",
        //   { position: 'top-center'
        // );
      }

      return response;
    } catch (error) {
      console.error("Login error:", error);
      // Show error toast if login fails
      showErrorToast(
        error.data?.message || "Please check your credentials and try again.",
        "Login Failed",
        { position: 'top-center' }
      );
      throw error;
    }
  };

  // Effect for initial mounting
  useEffect(() => {
    setMounted(true);
  }, []);

  // Check authentication on mount
  useEffect(() => {
    if (!mounted) return;

    const { isAuthenticated, user: authUser, expired } = authService.checkAuth();

    if (expired) {
      logout("expired");
    } else if (isAuthenticated && authUser) {
      setUser(authUser);
    }

    setLoading(false);
  }, [mounted]);

  // Check if user is authenticated
  const isAuthenticated = () => {
    const auth = authService.checkAuth();
    return auth.isAuthenticated;
  };

  if (!mounted) {
    return null;
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        setUser,
        loading,
        login,
        logout,
        isAuthenticated: isAuthenticated(),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
