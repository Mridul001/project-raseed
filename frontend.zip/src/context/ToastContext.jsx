import React, { createContext, useContext, useState, useCallback } from 'react';
import Toast from '../components/common/Toast/Toast';

// Create context
const ToastContext = createContext({
  showToast: () => {},
});

// Generate a unique ID for each toast
const generateId = () => `toast-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

/**
 * ToastProvider component that wraps the application to provide toast functionality
 * 
 * @component
 */
export const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  // Function to add a new toast
  const showToast = useCallback((message, type = 'info', duration = 3000, position = 'top-right', title = '') => {
    const id = generateId();
    
    setToasts((prevToasts) => [
      ...prevToasts,
      {
        id,
        message,
        title,
        type,
        duration,
        position,
      },
    ]);

    return id;
  }, []);

  // Function to remove a toast
  const removeToast = useCallback((id) => {
    setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== id));
  }, []);

  // Convenience methods for different toast types
  const success = useCallback((message, title, options = {}) => {
    return showToast(
      message, 
      'success', 
      options.duration || 3000, 
      options.position || 'top-right',
      title || 'Success'
    );
  }, [showToast]);

  const error = useCallback((message, title, options = {}) => {
    return showToast(
      message, 
      'error', 
      options.duration || 4000, 
      options.position || 'top-right',
      title || 'Error'
    );
  }, [showToast]);

  const warning = useCallback((message, title, options = {}) => {
    return showToast(
      message, 
      'warning', 
      options.duration || 4000, 
      options.position || 'top-right',
      title || 'Warning'
    );
  }, [showToast]);

  const info = useCallback((message, title, options = {}) => {
    return showToast(
      message, 
      'info', 
      options.duration || 3000, 
      options.position || 'top-right',
      title || 'Information'
    );
  }, [showToast]);

  return (
    <ToastContext.Provider 
      value={{ 
        showToast,
        success,
        error,
        warning,
        info
      }}
    >
      {children}
      
      {/* Render all active toasts */}
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          message={toast.message}
          title={toast.title}
          type={toast.type}
          duration={toast.duration}
          position={toast.position}
          onClose={() => removeToast(toast.id)}
        />
      ))}
    </ToastContext.Provider>
  );
};

/**
 * Custom hook to use toast functionality
 * 
 * @returns {Object} Toast methods
 */
export const useToast = () => useContext(ToastContext);

export default ToastContext;