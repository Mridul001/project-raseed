import Home from "../pages/home/Home.jsx";
import ScanReceipt from "../pages/ScanReceiptPage.jsx";
import AskQueries from "../pages/AskQueries.jsx";
import ReceiptHistory from "@/components/receipt/ReceiptHistory.jsx";
import AnalyticsDashboard from "../pages/AnalyticsDashboard.jsx";
import ShoppingList from "../pages/ShoppingList.jsx";

const routes = [
    // Protected routes (require authentication)
    {
        path: "/home",
        element: Home,
        public: false,
        title: "Home",
    },
    {
        path: "/scan-receipt",
        element: ScanReceipt,
        public: false,
        title: "Scan Receipt",
    },
    {
        path: "/history",
        element: ReceiptHistory,
        public: false,
        title: "Receipt History",
    },
    {
        path: "/ask-queries",
        element: AskQueries,
        public: false,
        title: "Ask Queries",
    },
    {
        path: "/stats",
        element: AnalyticsDashboard,
        public: false,
        title: "Stats",
    },
    {
        path: "/shopping-list",
        element: ShoppingList,
        public: false,
        title: "Shopping List",
    }
];

export default routes;
