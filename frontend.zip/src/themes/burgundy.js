const burgundyTheme = {
  name: 'burgundy',
  colors: {
    // Base colors
    background: '#faf5f6',
    foreground: '#1a0e10',

    // Sidebar colors
    sidebar: '#f7f0f1',
    'sidebar-text': '#6d4853',
    'sidebar-text-active': '#1a0e10',
    'sidebar-hover': '#f0e5e7',
    'sidebar-active': '#d43e57',
    'sidebar-icon': '#6d4853',
    'sidebar-icon-active': '#1a0e10',
    'sidebar-border': '#e9d5da',

    // Primary palette - Burgundy
    primary: '#B01A2C',
    'primary-light': '#D02D3E',
    'primary-dark': '#901522',
    'primary-contrast': '#ffffff',

    // Secondary palette - Complementary teal
    secondary: '#2C8EA8',
    'secondary-light': '#3CABC7',
    'secondary-dark': '#1F7A91',
    'secondary-contrast': '#ffffff',

    // Accent colors - Soft pink
    accent: '#FFC3C9',
    'accent-light': '#FFD8DC',
    'accent-dark': '#FFB0B7',
    'accent-contrast': '#B01A2C',

    // Surface colors
    surface: '#ffffff',
    'surface-100': '#ffffff',
    'surface-200': '#f6f1f2',
    'surface-300': '#ede6e7',
    'surface-hover': '#f6f1f2',
    'surface-pressed': '#ede6e7',
    'surface-elevated': '#ffffff',

    // Content/text colors
    'content-primary': '#1a0e10',
    'content-secondary': '#442730',
    'content-tertiary': '#6d4853',
    'content-disabled': '#a28791',
    'content-inverse': '#ffffff',
    'content-link': '#b01a2c',
    'content-link-hover': '#d02d3e',

    // Status colors
    success: '#22c55e',
    'success-light': '#4ade80',
    'success-dark': '#16a34a',
    'success-contrast': '#ffffff',
    'success-surface': '#dcfce7',

    error: '#ef4444',
    'error-light': '#f87171',
    'error-dark': '#dc2626',
    'error-contrast': '#ffffff',
    'error-surface': '#fee2e2',

    warning: '#f59e0b',
    'warning-light': '#fbbf24',
    'warning-dark': '#d97706',
    'warning-contrast': '#1a0e10',
    'warning-surface': '#fef3c7',

    info: '#3b82f6',
    'info-light': '#60a5fa',
    'info-dark': '#2563eb',
    'info-contrast': '#ffffff',
    'info-surface': '#dbeafe',

    // Neutral colors with subtle burgundy tint
    muted: '#e9e4e5',
    'muted-light': '#f4f1f1',
    'muted-dark': '#d9d4d5',
    'muted-hover': '#f4f1f1',
    'muted-pressed': '#d9d4d5',

    // Border colors
    border: '#ddd5d6',
    'border-light': '#e9e4e5',
    'border-dark': '#c9c1c2',
    'border-hover': '#c9c1c2',
    'border-focus': '#b01a2c',

    // Card colors
    card: '#ffffff',
    'card-hover': '#f6f1f2',
    'card-header': '#f6f1f2',
    'card-footer': '#f6f1f2',
    'card-border': '#ddd5d6',
    'card-shadow': '0 4px 6px -1px rgba(176, 26, 44, 0.05), 0 2px 4px -1px rgba(176, 26, 44, 0.03)',

    // Input colors
    input: '#ffffff',
    'input-border': '#ddd5d6',
    'input-hover-border': '#c9c1c2',
    'input-focus-border': '#b01a2c',
    'input-focus-ring': 'rgba(176, 26, 44, 0.2)',
    'input-disabled': '#f4f1f1',
    'input-disabled-border': '#e9e4e5',
    'input-placeholder': '#a28791',
    'input-icon': '#6d4853',

    // Button colors
    'button-primary': '#b01a2c',
    'button-primary-hover': '#d02d3e',
    'button-primary-active': '#901522',
    'button-primary-text': '#ffffff',
    'button-primary-disabled': '#ffeaec',
    'button-primary-disabled-text': '#d79da4',

    'button-secondary': '#f4f1f1',
    'button-secondary-hover': '#e9e4e5',
    'button-secondary-active': '#ddd5d6',
    'button-secondary-text': '#442730',
    'button-secondary-disabled': '#f9f7f8',
    'button-secondary-disabled-text': '#d9d4d5',

    'button-tertiary': 'transparent',
    'button-tertiary-hover': '#f4f1f1',
    'button-tertiary-active': '#e9e4e5',
    'button-tertiary-text': '#442730',
    'button-tertiary-disabled': 'transparent',
    'button-tertiary-disabled-text': '#d9d4d5',

    'button-danger': '#ef4444',
    'button-danger-hover': '#f87171',
    'button-danger-active': '#dc2626',
    'button-danger-text': '#ffffff',
    'button-danger-disabled': '#fee2e2',
    'button-danger-disabled-text': '#fca5a5',

    // Overlay colors
    'overlay-light': 'rgba(255, 255, 255, 0.8)',
    'overlay-dark': 'rgba(26, 14, 16, 0.3)',
    'overlay-modal': 'rgba(26, 14, 16, 0.5)',
    'backdrop': 'rgba(176, 26, 44, 0.05)',

    // Navigation
    'nav-background': '#ffffff',
    'nav-border': '#ddd5d6',
    'nav-text': '#6d4853',
    'nav-text-active': '#1a0e10',
    'nav-indicator': '#b01a2c',

    // Table colors
    'table-header': '#f6f1f2',
    'table-border': '#ddd5d6',
    'table-row-hover': '#f9f7f8',
    'table-row-stripe': '#f6f1f2',

    // Tooltip colors
    'tooltip-background': '#442730',
    'tooltip-text': '#ffffff',

    // Badge colors
    'badge-default': '#f4f1f1',
    'badge-default-text': '#442730',
    'badge-primary': '#ffeaec',
    'badge-primary-text': '#b01a2c',
    'badge-secondary': '#e1f3f7',
    'badge-secondary-text': '#2c8ea8',
    'badge-success': '#dcfce7',
    'badge-success-text': '#16a34a',
    'badge-error': '#fee2e2',
    'badge-error-text': '#dc2626',
    'badge-warning': '#fef3c7',
    'badge-warning-text': '#d97706',
    'badge-info': '#dbeafe',
    'badge-info-text': '#2563eb',

    // Progress bar colors
    'progress-background': '#f4f1f1',
    'progress-primary': '#b01a2c',
    'progress-success': '#22c55e',
    'progress-error': '#ef4444',
    'progress-warning': '#f59e0b',
    'progress-info': '#3b82f6',

    // Scroll colors
    'scroll-thumb': '#ddd5d6',
    'scroll-thumb-hover': '#c9c1c2',
    'scroll-track': '#f4f1f1',

    // Switch colors
    'switch-off': '#ddd5d6',
    'switch-off-background': '#f4f1f1',
    'switch-on': '#b01a2c',
    'switch-on-background': '#ffeaec',
    'switch-disabled': '#e9e4e5',
    'switch-disabled-background': '#f9f7f8',

    // Slider colors
    'slider-track': '#ddd5d6',
    'slider-range': '#b01a2c',
    'slider-thumb': '#ffffff',
    'slider-thumb-border': '#b01a2c',
    'slider-disabled': '#f4f1f1',

    // Menu colors
    'menu-background': '#ffffff',
    'menu-border': '#ddd5d6',
    'menu-item': '#1a0e10',
    'menu-item-hover': '#f6f1f2',
    'menu-item-disabled': '#c9c1c2',
    'menu-item-selected': '#b01a2c',
    'menu-divider': '#e9e4e5',

    // Divider
    divider: '#e9e4e5',

    // Skeleton/loading colors
    'skeleton-base': '#f4f1f1',
    'skeleton-highlight': '#f9f7f8'
  },
  fonts: {
    primary: "Lexend, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    secondary: "Montserrat, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    tertiary: "Roboto, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    code: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace"
  },
  fontSizes: {
    xs: '0.75rem',   // 12px
    sm: '0.875rem',  // 14px
    base: '1rem',    // 16px
    lg: '1.125rem',  // 18px
    xl: '1.25rem',   // 20px
    '2xl': '1.5rem', // 24px
    '3xl': '1.875rem', // 30px
    '4xl': '2.25rem',  // 36px
    '5xl': '3rem',     // 48px
    '6xl': '3.75rem',  // 60px
    '7xl': '4.5rem',   // 72px
    '8xl': '6rem',     // 96px
    '9xl': '8rem'      // 128px
  },
  fontWeights: {
    thin: 100,
    extralight: 200,
    light: 300,
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
    extrabold: 800,
    black: 900
  },
  lineHeights: {
    none: '1',
    tight: '1.25',
    snug: '1.375',
    normal: '1.5',
    relaxed: '1.625',
    loose: '2',
  },
  letterSpacings: {
    tighter: '-0.05em',
    tight: '-0.025em',
    normal: '0em',
    wide: '0.025em',
    wider: '0.05em',
    widest: '0.1em',
  },
  borderRadius: {
    none: '0',
    xs: '0.125rem',    // 2px
    sm: '0.25rem',     // 4px
    md: '0.375rem',    // 6px
    lg: '0.5rem',      // 8px
    xl: '0.75rem',     // 12px
    '2xl': '1rem',     // 16px
    '3xl': '1.5rem',   // 24px
    full: '9999px'
  },
  borderWidths: {
    none: '0',
    xs: '0.5px',
    thin: '1px',
    medium: '1.5px',
    thick: '2px',
    thicker: '4px'
  },
  spacing: {
    0: '0',
    px: '1px',
    xs: '0.25rem',     // 4px
    sm: '0.5rem',      // 8px
    md: '1rem',        // 16px
    lg: '1.5rem',      // 24px
    xl: '2rem',        // 32px
    '2xl': '2.5rem',   // 40px
    '3xl': '3rem',     // 48px
    '4xl': '4rem',     // 64px
    '5xl': '5rem',     // 80px
    '6xl': '6rem'      // 96px
  },
  shadows: {
    none: 'none',
    xs: '0 1px 2px 0 rgba(176, 26, 44, 0.05)',
    sm: '0 1px 3px 0 rgba(176, 26, 44, 0.1), 0 1px 2px 0 rgba(176, 26, 44, 0.06)',
    md: '0 4px 6px -1px rgba(176, 26, 44, 0.1), 0 2px 4px -1px rgba(176, 26, 44, 0.06)',
    lg: '0 10px 15px -3px rgba(176, 26, 44, 0.1), 0 4px 6px -2px rgba(176, 26, 44, 0.05)',
    xl: '0 20px 25px -5px rgba(176, 26, 44, 0.1), 0 10px 10px -5px rgba(176, 26, 44, 0.04)',
    '2xl': '0 25px 50px -12px rgba(176, 26, 44, 0.25)',
    inner: 'inset 0 2px 4px 0 rgba(176, 26, 44, 0.06)',
    'inner-md': 'inset 0 4px 6px -1px rgba(176, 26, 44, 0.1)',
    outlined: '0 0 0 2px rgba(176, 26, 44, 0.6)'
  },
  transitions: {
    fast: '150ms',
    normal: '300ms',
    slow: '500ms',
    ease: 'cubic-bezier(0.4, 0, 0.2, 1)',
    in: 'cubic-bezier(0.4, 0, 1, 1)',
    out: 'cubic-bezier(0, 0, 0.2, 1)',
    'in-out': 'cubic-bezier(0.4, 0, 0.2, 1)'
  },
  zIndices: {
    0: '0',
    10: '10',
    20: '20',
    30: '30',
    40: '40',
    50: '50',
    dropdown: '1000',
    sticky: '1100',
    overlay: '1300',
    modal: '1400',
    popover: '1500',
    tooltip: '1600'
  },
  opacity: {
    0: '0',
    5: '0.05',
    10: '0.1',
    20: '0.2',
    25: '0.25',
    30: '0.3',
    40: '0.4',
    50: '0.5',
    60: '0.6',
    70: '0.7',
    75: '0.75',
    80: '0.8',
    90: '0.9',
    95: '0.95',
    100: '1'
  },
  blurs: {
    none: '0',
    sm: '4px',
    md: '8px',
    lg: '16px',
    xl: '24px',
    '2xl': '40px',
    '3xl': '64px'
  },
  gradients: {
    'primary-to-secondary': 'linear-gradient(135deg, #b01a2c 0%, #2c8ea8 100%)',
    'primary-to-accent': 'linear-gradient(135deg, #b01a2c 0%, #ffc3c9 100%)',
    'secondary-to-accent': 'linear-gradient(135deg, #2c8ea8 0%, #ffc3c9 100%)',
    'primary-to-primary-dark': 'linear-gradient(135deg, #b01a2c 0%, #901522 100%)',
    'secondary-to-secondary-dark': 'linear-gradient(135deg, #2c8ea8 0%, #1f7a91 100%)',
    'accent-to-accent-dark': 'linear-gradient(135deg, #ffc3c9 0%, #ffb0b7 100%)',
    'success-to-info': 'linear-gradient(135deg, #22c55e 0%, #3b82f6 100%)',
    'error-to-warning': 'linear-gradient(135deg, #ef4444 0%, #f59e0b 100%)',
    'glow-primary': 'radial-gradient(circle at center, rgba(176, 26, 44, 0.3) 0%, rgba(176, 26, 44, 0) 70%)',
    'glow-secondary': 'radial-gradient(circle at center, rgba(44, 142, 168, 0.3) 0%, rgba(44, 142, 168, 0) 70%)'
  },
  animations: {
    'spin': 'spin 1s linear infinite',
    'ping': 'ping 1s cubic-bezier(0, 0, 0.2, 1) infinite',
    'pulse': 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
    'bounce': 'bounce 1s infinite'
  }
};

export default burgundyTheme;
