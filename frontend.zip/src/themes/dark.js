const darkTheme = {
  name: 'dark',
  colors: {
    // Base colors - Much darker for modern look
    background: '#000000', // Pure black
    foreground: '#ffffff',

    // Glassmorphic backgrounds with enhanced transparency
    glass: {
      primary: 'rgba(18, 18, 18, 0.7)', // Darker glass surface
      secondary: 'rgba(32, 32, 32, 0.6)', // Secondary glass
      tertiary: 'rgba(48, 48, 48, 0.5)', // Lighter glass
      heavy: 'rgba(18, 18, 18, 0.85)', // Less transparent
      light: 'rgba(255, 255, 255, 0.08)', // Very light glass
      frosted: 'rgba(255, 255, 255, 0.04)', // Frosted effect
    },

    // Primary palette - Vibrant modern blue
    primary: '#0066ff',
    'primary-light': '#3385ff',
    'primary-dark': '#0052cc',
    'primary-contrast': '#ffffff',
    'primary-glass': 'rgba(0, 102, 255, 0.15)',
    'primary-glow': 'rgba(0, 102, 255, 0.5)',

    // Secondary palette - Purple-blue harmony
    secondary: '#6366f1',
    'secondary-light': '#8b8cf1',
    'secondary-dark': '#4f46e5',
    'secondary-contrast': '#ffffff',
    'secondary-glass': 'rgba(99, 102, 241, 0.15)',
    'secondary-glow': 'rgba(99, 102, 241, 0.5)',

    // Accent colors - Vibrant cyan
    accent: '#00d4ff',
    'accent-light': '#33ddff',
    'accent-dark': '#00aacc',
    'accent-contrast': '#000000',
    'accent-glass': 'rgba(0, 212, 255, 0.15)',
    'accent-glow': 'rgba(0, 212, 255, 0.5)',

    // Surface colors with enhanced glass effect
    surface: 'rgba(18, 18, 18, 0.7)',
    'surface-100': 'rgba(18, 18, 18, 0.5)',
    'surface-200': 'rgba(32, 32, 32, 0.6)',
    'surface-300': 'rgba(48, 48, 48, 0.5)',
    'surface-hover': 'rgba(32, 32, 32, 0.8)',
    'surface-pressed': 'rgba(48, 48, 48, 0.9)',
    'surface-elevated': 'rgba(32, 32, 32, 0.95)',

    // Chat & AI specific colors
    chat: {
      'user-bubble': 'rgba(0, 102, 255, 0.25)',
      'user-text': '#ffffff',
      'ai-bubble': 'rgba(18, 18, 18, 0.7)',
      'ai-text': '#f5f5f5',
      'input-bg': 'rgba(32, 32, 32, 0.6)',
      'input-border': 'rgba(0, 102, 255, 0.4)',
      'typing-indicator': '#3385ff',
    },

    // Camera UI colors
    camera: {
      overlay: 'rgba(0, 0, 0, 0.8)',
      frame: 'rgba(0, 212, 255, 0.7)',
      button: 'rgba(0, 102, 255, 0.9)',
      'button-hover': 'rgba(0, 102, 255, 1)',
      indicator: '#00d4ff',
    },

    // Content/text colors
    'content-primary': '#ffffff',
    'content-secondary': '#f5f5f5',
    'content-tertiary': '#cccccc',
    'content-disabled': '#888888',
    'content-inverse': '#000000',
    'content-link': '#3385ff',
    'content-link-hover': '#5599ff',

    // Status colors with enhanced glass variants
    success: '#00cc66',
    'success-light': '#33d684',
    'success-dark': '#00994d',
    'success-contrast': '#ffffff',
    'success-surface': 'rgba(0, 204, 102, 0.15)',
    'success-glow': 'rgba(0, 204, 102, 0.5)',

    error: '#ff3366',
    'error-light': '#ff5577',
    'error-dark': '#cc1a40',
    'error-contrast': '#ffffff',
    'error-surface': 'rgba(255, 51, 102, 0.15)',
    'error-glow': 'rgba(255, 51, 102, 0.5)',

    warning: '#ffaa00',
    'warning-light': '#ffbb33',
    'warning-dark': '#cc8800',
    'warning-contrast': '#000000',
    'warning-surface': 'rgba(255, 170, 0, 0.15)',
    'warning-glow': 'rgba(255, 170, 0, 0.5)',

    info: '#0066ff',
    'info-light': '#3385ff',
    'info-dark': '#0052cc',
    'info-contrast': '#ffffff',
    'info-surface': 'rgba(0, 102, 255, 0.15)',
    'info-glow': 'rgba(0, 102, 255, 0.5)',

    // Border colors with enhanced glow options
    border: 'rgba(255, 255, 255, 0.1)',
    'border-light': 'rgba(255, 255, 255, 0.15)',
    'border-dark': 'rgba(255, 255, 255, 0.05)',
    'border-hover': 'rgba(255, 255, 255, 0.2)',
    'border-focus': 'rgba(0, 102, 255, 0.6)',
    'border-glow': 'rgba(0, 102, 255, 0.8)',

    // Card colors - enhanced glassmorphic
    card: 'rgba(18, 18, 18, 0.7)',
    'card-hover': 'rgba(32, 32, 32, 0.8)',
    'card-header': 'rgba(32, 32, 32, 0.85)',
    'card-footer': 'rgba(32, 32, 32, 0.85)',
    'card-border': 'rgba(255, 255, 255, 0.1)',

    // Input colors - modern glass style
    input: 'rgba(18, 18, 18, 0.6)',
    'input-border': 'rgba(255, 255, 255, 0.1)',
    'input-hover-border': 'rgba(255, 255, 255, 0.2)',
    'input-focus-border': 'rgba(0, 102, 255, 0.7)',
    'input-focus-ring': 'rgba(0, 102, 255, 0.25)',
    'input-disabled': 'rgba(18, 18, 18, 0.4)',
    'input-disabled-border': 'rgba(255, 255, 255, 0.05)',
    'input-placeholder': 'rgba(255, 255, 255, 0.4)',
    'input-icon': '#cccccc',

    // Button colors - vibrant modern style
    'button-primary': 'rgba(0, 102, 255, 0.9)',
    'button-primary-hover': 'rgba(0, 102, 255, 1)',
    'button-primary-active': 'rgba(0, 82, 204, 1)',
    'button-primary-text': '#ffffff',
    'button-primary-disabled': 'rgba(0, 102, 255, 0.3)',
    'button-primary-disabled-text': 'rgba(255, 255, 255, 0.5)',

    'button-secondary': 'rgba(32, 32, 32, 0.7)',
    'button-secondary-hover': 'rgba(48, 48, 48, 0.9)',
    'button-secondary-active': 'rgba(48, 48, 48, 1)',
    'button-secondary-text': '#ffffff',
    'button-secondary-disabled': 'rgba(32, 32, 32, 0.4)',
    'button-secondary-disabled-text': 'rgba(255, 255, 255, 0.3)',

    'button-glass': 'rgba(255, 255, 255, 0.08)',
    'button-glass-hover': 'rgba(255, 255, 255, 0.15)',
    'button-glass-active': 'rgba(255, 255, 255, 0.2)',
    'button-glass-text': '#ffffff',

    // Overlay colors
    'overlay-light': 'rgba(255, 255, 255, 0.08)',
    'overlay-dark': 'rgba(0, 0, 0, 0.6)',
    'overlay-modal': 'rgba(0, 0, 0, 0.8)',
    'overlay-glass': 'rgba(18, 18, 18, 0.85)',
    backdrop: 'rgba(0, 0, 0, 0.95)',

    // Navigation
    'nav-background': 'rgba(18, 18, 18, 0.85)',
    'nav-border': 'rgba(255, 255, 255, 0.1)',
    'nav-text': '#cccccc',
    'nav-text-active': '#ffffff',
    'nav-indicator': '#0066ff',
    'nav-glass': 'rgba(18, 18, 18, 0.7)',

    // Sidebar colors (enhanced glass style)
    sidebar: 'rgba(18, 18, 18, 0.85)',
    'sidebar-text': '#cccccc',
    'sidebar-text-active': '#ffffff',
    'sidebar-hover': 'rgba(32, 32, 32, 0.7)',
    'sidebar-active': 'rgba(0, 102, 255, 0.25)',
    'sidebar-icon': '#cccccc',
    'sidebar-icon-active': '#0066ff',
    'sidebar-border': 'rgba(255, 255, 255, 0.1)',

    // Special effects
    glow: {
      primary: 'rgba(0, 102, 255, 0.6)',
      secondary: 'rgba(99, 102, 241, 0.6)',
      accent: 'rgba(0, 212, 255, 0.6)',
      success: 'rgba(0, 204, 102, 0.6)',
      error: 'rgba(255, 51, 102, 0.6)',
      warning: 'rgba(255, 170, 0, 0.6)',
    },

    // Skeleton/loading
    'skeleton-base': 'rgba(32, 32, 32, 0.6)',
    'skeleton-highlight': 'rgba(48, 48, 48, 0.7)',

    // Scrollbar
    'scroll-thumb': 'rgba(255, 255, 255, 0.2)',
    'scroll-thumb-hover': 'rgba(255, 255, 255, 0.3)',
    'scroll-track': 'rgba(18, 18, 18, 0.4)',

    // Other UI elements
    divider: 'rgba(255, 255, 255, 0.1)',
    'tooltip-background': 'rgba(18, 18, 18, 0.98)',
    'tooltip-text': '#ffffff',
  },

  // Glass blur effects
  glass: {
    blur: {
      none: '0px',
      sm: '8px',
      md: '16px',
      lg: '24px',
      xl: '32px',
      '2xl': '48px',
    },
    // Backdrop filters for glassmorphism
    backdrop: {
      blur: 'blur(20px)',
      'blur-sm': 'blur(10px)',
      'blur-md': 'blur(20px)',
      'blur-lg': 'blur(28px)',
      'blur-xl': 'blur(36px)',
      saturate: 'saturate(190%)',
      brightness: 'brightness(110%)',
    },
  },

  // Enhanced shadows with stronger glow effects
  shadows: {
    none: 'none',
    xs: '0 1px 2px 0 rgba(0, 0, 0, 0.4)',
    sm: '0 1px 3px 0 rgba(0, 0, 0, 0.5), 0 1px 2px 0 rgba(0, 0, 0, 0.4)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.5), 0 2px 4px -1px rgba(0, 0, 0, 0.4)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.5), 0 4px 6px -2px rgba(0, 0, 0, 0.4)',
    xl: '0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.4)',
    '2xl': '0 25px 50px -12px rgba(0, 0, 0, 0.6)',
    inner: 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.4)',
    'inner-md': 'inset 0 4px 6px -1px rgba(0, 0, 0, 0.5)',

    // Enhanced glow shadows
    'glow-sm': '0 0 15px rgba(0, 102, 255, 0.4)',
    'glow-md': '0 0 25px rgba(0, 102, 255, 0.5)',
    'glow-lg': '0 0 35px rgba(0, 102, 255, 0.6)',
    'glow-primary': '0 0 25px rgba(0, 102, 255, 0.5)',
    'glow-secondary': '0 0 25px rgba(99, 102, 241, 0.5)',
    'glow-accent': '0 0 25px rgba(0, 212, 255, 0.5)',
    'glow-success': '0 0 25px rgba(0, 204, 102, 0.5)',
    'glow-error': '0 0 25px rgba(255, 51, 102, 0.5)',

    // Enhanced card shadows
    'card': '0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 0 50px rgba(0, 102, 255, 0.15)',
    'card-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.4), 0 0 50px rgba(0, 102, 255, 0.25)',
  },

  // GSAP-ready animations
  animations: {
    // Durations
    duration: {
      instant: '100ms',
      fast: '200ms',
      normal: '300ms',
      slow: '500ms',
      slower: '700ms',
      slowest: '1000ms',
    },
    // Easings for GSAP
    ease: {
      linear: 'none',
      in: 'power2.in',
      out: 'power2.out',
      inOut: 'power2.inOut',
      inQuad: 'power2.in',
      outQuad: 'power2.out',
      inOutQuad: 'power2.inOut',
      inCubic: 'power3.in',
      outCubic: 'power3.out',
      inOutCubic: 'power3.inOut',
      inQuart: 'power4.in',
      outQuart: 'power4.out',
      inOutQuart: 'power4.inOut',
      elastic: 'elastic.out(1, 0.3)',
      bounce: 'bounce.out',
      back: 'back.out(1.7)',
    },
    // Predefined animations
    fadeIn: 'fadeIn 300ms ease-out',
    fadeOut: 'fadeOut 300ms ease-in',
    slideIn: 'slideIn 300ms ease-out',
    slideOut: 'slideOut 300ms ease-in',
    scaleIn: 'scaleIn 200ms ease-out',
    scaleOut: 'scaleOut 200ms ease-in',
    spin: 'spin 1s linear infinite',
    ping: 'ping 1s cubic-bezier(0, 0, 0.2, 1) infinite',
    pulse: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
    bounce: 'bounce 1s infinite',
    shimmer: 'shimmer 2s linear infinite',
    glow: 'glow 2s ease-in-out infinite',
  },

  // Typography optimized for AI chat interfaces
  fonts: {
    primary: "Lexend, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    secondary: "Montserrat, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    display: "Lexend, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    code: "JetBrains Mono, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"
  },

  fontSizes: {
    // Chat specific sizes
    'chat-tiny': '0.625rem',    // 10px - timestamps
    'chat-small': '0.75rem',     // 12px - metadata
    'chat-base': '0.875rem',     // 14px - messages
    'chat-large': '1rem',        // 16px - emphasis

    // Standard sizes
    xs: '0.75rem',   // 12px
    sm: '0.875rem',  // 14px
    base: '1rem',    // 16px
    lg: '1.125rem',  // 18px
    xl: '1.25rem',   // 20px
    '2xl': '1.5rem', // 24px
    '3xl': '1.875rem', // 30px
    '4xl': '2.25rem',  // 36px
    '5xl': '3rem',     // 48px
    '6xl': '3.75rem',  // 60px
    '7xl': '4.5rem',   // 72px
    '8xl': '6rem',     // 96px
    '9xl': '8rem'      // 128px
  },

  fontWeights: {
    thin: 100,
    extralight: 200,
    light: 300,
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
    extrabold: 800,
    black: 900
  },

  lineHeights: {
    none: '1',
    tight: '1.25',
    snug: '1.375',
    normal: '1.5',
    relaxed: '1.625',
    loose: '2',
    chat: '1.4', // Optimized for readability in chat
  },

  letterSpacings: {
    tighter: '-0.05em',
    tight: '-0.025em',
    normal: '0em',
    wide: '0.025em',
    wider: '0.05em',
    widest: '0.1em',
  },

  borderRadius: {
    none: '0',
    xs: '0.25rem',     // 4px
    sm: '0.375rem',    // 6px
    md: '0.5rem',      // 8px
    lg: '0.75rem',     // 12px
    xl: '1rem',        // 16px
    '2xl': '1.25rem',  // 20px
    '3xl': '1.5rem',   // 24px
    full: '9999px',
    // Chat specific
    'chat-bubble': '1.25rem', // 20px - More rounded
    'chat-input': '1rem',   // 16px - More rounded
  },

  borderWidths: {
    none: '0',
    xs: '0.5px',
    thin: '1px',
    medium: '1.5px',
    thick: '2px',
    thicker: '4px'
  },

  spacing: {
    0: '0',
    px: '1px',
    xs: '0.25rem',     // 4px
    sm: '0.5rem',      // 8px
    md: '1rem',        // 16px
    lg: '1.5rem',      // 24px
    xl: '2rem',        // 32px
    '2xl': '2.5rem',   // 40px
    '3xl': '3rem',     // 48px
    '4xl': '4rem',     // 64px
    '5xl': '5rem',     // 80px
    '6xl': '6rem',     // 96px
    // Chat specific
    'chat-gap': '0.75rem',     // 12px
    'message-gap': '0.5rem',   // 8px
  },

  // Z-index for layered glass effects
  zIndices: {
    0: '0',
    10: '10',
    20: '20',
    30: '30',
    40: '40',
    50: '50',
    dropdown: '1000',
    sticky: '1100',
    overlay: '1300',
    modal: '1400',
    popover: '1500',
    tooltip: '1600',
    'chat-input': '100',
    'chat-bubble': '10',
    'camera-overlay': '1200',
  },

  opacity: {
    0: '0',
    5: '0.05',
    10: '0.1',
    20: '0.2',
    25: '0.25',
    30: '0.3',
    40: '0.4',
    50: '0.5',
    60: '0.6',
    70: '0.7',
    75: '0.75',
    80: '0.8',
    90: '0.9',
    95: '0.95',
    100: '1',
    // Glass specific
    'glass-light': '0.08',
    'glass-medium': '0.4',
    'glass-heavy': '0.7',
  },

  gradients: {
    // Enhanced modern gradients
    'primary-gradient': 'linear-gradient(135deg, #0066ff 0%, #0052cc 100%)',
    'secondary-gradient': 'linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)',
    'accent-gradient': 'linear-gradient(135deg, #00d4ff 0%, #00aacc 100%)',
    'primary-to-secondary': 'linear-gradient(135deg, #0066ff 0%, #6366f1 100%)',
    'primary-to-accent': 'linear-gradient(135deg, #0066ff 0%, #00d4ff 100%)',
    'secondary-to-accent': 'linear-gradient(135deg, #6366f1 0%, #00d4ff 100%)',

    // Enhanced glass gradients
    'glass-gradient': 'linear-gradient(135deg, rgba(255, 255, 255, 0.08) 0%, rgba(255, 255, 255, 0.04) 100%)',
    'glass-border': 'linear-gradient(135deg, rgba(255, 255, 255, 0.15) 0%, rgba(255, 255, 255, 0.05) 100%)',

    // Enhanced glow gradients
    'glow-primary': 'radial-gradient(circle at center, rgba(0, 102, 255, 0.4) 0%, rgba(0, 102, 255, 0) 70%)',
    'glow-secondary': 'radial-gradient(circle at center, rgba(99, 102, 241, 0.4) 0%, rgba(99, 102, 241, 0) 70%)',
    'glow-accent': 'radial-gradient(circle at center, rgba(0, 212, 255, 0.4) 0%, rgba(0, 212, 255, 0) 70%)',

    // Enhanced mesh gradients for backgrounds
    'mesh-primary': 'radial-gradient(at 20% 80%, rgba(0, 102, 255, 0.25) 0px, transparent 50%), radial-gradient(at 80% 20%, rgba(99, 102, 241, 0.25) 0px, transparent 50%), radial-gradient(at 40% 40%, rgba(0, 212, 255, 0.15) 0px, transparent 50%)',
  },

  // Keep other properties same
  transitions: {
    fast: '150ms',
    normal: '300ms',
    slow: '500ms',
    ease: 'cubic-bezier(0.4, 0, 0.2, 1)',
    in: 'cubic-bezier(0.4, 0, 1, 1)',
    out: 'cubic-bezier(0, 0, 0.2, 1)',
    'in-out': 'cubic-bezier(0.4, 0, 0.2, 1)'
  },
};

export default darkTheme;
