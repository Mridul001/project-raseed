const lightTheme = {
  name: 'light',
  colors: {
    // Base colors - Clean, bright modern theme
    background: '#ffffff', // Pure white
    foreground: '#000000',

    // Glassmorphic backgrounds with transparency
    glass: {
      primary: 'rgba(255, 255, 255, 0.85)', // Main glass surface
      secondary: 'rgba(250, 250, 250, 0.8)', // Secondary glass
      tertiary: 'rgba(245, 245, 245, 0.7)', // Lighter glass
      heavy: 'rgba(255, 255, 255, 0.95)', // Less transparent
      light: 'rgba(0, 0, 0, 0.03)', // Very light glass
      frosted: 'rgba(0, 0, 0, 0.02)', // Frosted effect
    },

    // Primary palette - Vibrant modern blue
    primary: '#0066ff',
    'primary-light': '#3385ff',
    'primary-dark': '#0052cc',
    'primary-contrast': '#ffffff',
    'primary-glass': 'rgba(0, 102, 255, 0.08)',
    'primary-glow': 'rgba(0, 102, 255, 0.3)',

    // Secondary palette - Purple-blue harmony
    secondary: '#6366f1',
    'secondary-light': '#8b8cf1',
    'secondary-dark': '#4f46e5',
    'secondary-contrast': '#ffffff',
    'secondary-glass': 'rgba(99, 102, 241, 0.08)',
    'secondary-glow': 'rgba(99, 102, 241, 0.3)',

    // Accent colors - Vibrant cyan
    accent: '#00d4ff',
    'accent-light': '#33ddff',
    'accent-dark': '#00aacc',
    'accent-contrast': '#000000',
    'accent-glass': 'rgba(0, 212, 255, 0.08)',
    'accent-glow': 'rgba(0, 212, 255, 0.3)',

    // Surface colors with glass effect
    surface: 'rgba(255, 255, 255, 0.85)',
    'surface-100': 'rgba(255, 255, 255, 0.7)',
    'surface-200': 'rgba(250, 250, 250, 0.8)',
    'surface-300': 'rgba(245, 245, 245, 0.7)',
    'surface-hover': 'rgba(250, 250, 250, 0.9)',
    'surface-pressed': 'rgba(245, 245, 245, 1)',
    'surface-elevated': 'rgba(255, 255, 255, 1)',

    // Chat & AI specific colors
    chat: {
      'user-bubble': 'rgba(0, 102, 255, 0.15)',
      'user-text': '#000000',
      'ai-bubble': 'rgba(255, 255, 255, 0.9)',
      'ai-text': '#1a1a1a',
      'input-bg': 'rgba(250, 250, 250, 0.8)',
      'input-border': 'rgba(0, 102, 255, 0.25)',
      'typing-indicator': '#0066ff',
    },

    // Camera UI colors
    camera: {
      overlay: 'rgba(0, 0, 0, 0.6)',
      frame: 'rgba(0, 212, 255, 0.5)',
      button: 'rgba(0, 102, 255, 0.9)',
      'button-hover': 'rgba(0, 102, 255, 1)',
      indicator: '#00d4ff',
    },

    // Content/text colors
    'content-primary': '#000000',
    'content-secondary': '#1a1a1a',
    'content-tertiary': '#666666',
    'content-disabled': '#999999',
    'content-inverse': '#ffffff',
    'content-link': '#0066ff',
    'content-link-hover': '#0052cc',

    // Status colors with glass variants
    success: '#00cc66',
    'success-light': '#33d684',
    'success-dark': '#00994d',
    'success-contrast': '#ffffff',
    'success-surface': 'rgba(0, 204, 102, 0.08)',
    'success-glow': 'rgba(0, 204, 102, 0.3)',

    error: '#ff3366',
    'error-light': '#ff5577',
    'error-dark': '#cc1a40',
    'error-contrast': '#ffffff',
    'error-surface': 'rgba(255, 51, 102, 0.08)',
    'error-glow': 'rgba(255, 51, 102, 0.3)',

    warning: '#ffaa00',
    'warning-light': '#ffbb33',
    'warning-dark': '#cc8800',
    'warning-contrast': '#000000',
    'warning-surface': 'rgba(255, 170, 0, 0.08)',
    'warning-glow': 'rgba(255, 170, 0, 0.3)',

    info: '#0066ff',
    'info-light': '#3385ff',
    'info-dark': '#0052cc',
    'info-contrast': '#ffffff',
    'info-surface': 'rgba(0, 102, 255, 0.08)',
    'info-glow': 'rgba(0, 102, 255, 0.3)',

    // Border colors with glow options
    border: 'rgba(0, 0, 0, 0.08)',
    'border-light': 'rgba(0, 0, 0, 0.04)',
    'border-dark': 'rgba(0, 0, 0, 0.12)',
    'border-hover': 'rgba(0, 0, 0, 0.15)',
    'border-focus': 'rgba(0, 102, 255, 0.4)',
    'border-glow': 'rgba(0, 102, 255, 0.6)',

    // Card colors - glassmorphic
    card: 'rgba(255, 255, 255, 0.85)',
    'card-hover': 'rgba(250, 250, 250, 0.9)',
    'card-header': 'rgba(250, 250, 250, 0.95)',
    'card-footer': 'rgba(250, 250, 250, 0.95)',
    'card-border': 'rgba(0, 0, 0, 0.06)',

    // Input colors - glass style
    input: 'rgba(255, 255, 255, 0.8)',
    'input-border': 'rgba(0, 0, 0, 0.08)',
    'input-hover-border': 'rgba(0, 0, 0, 0.12)',
    'input-focus-border': 'rgba(0, 102, 255, 0.5)',
    'input-focus-ring': 'rgba(0, 102, 255, 0.15)',
    'input-disabled': 'rgba(250, 250, 250, 0.6)',
    'input-disabled-border': 'rgba(0, 0, 0, 0.04)',
    'input-placeholder': 'rgba(0, 0, 0, 0.4)',
    'input-icon': '#666666',

    // Button colors - modern glass style
    'button-primary': 'rgba(0, 102, 255, 0.95)',
    'button-primary-hover': 'rgba(0, 102, 255, 1)',
    'button-primary-active': 'rgba(0, 82, 204, 1)',
    'button-primary-text': '#ffffff',
    'button-primary-disabled': 'rgba(0, 102, 255, 0.4)',
    'button-primary-disabled-text': 'rgba(255, 255, 255, 0.7)',

    'button-secondary': 'rgba(250, 250, 250, 0.9)',
    'button-secondary-hover': 'rgba(245, 245, 245, 1)',
    'button-secondary-active': 'rgba(240, 240, 240, 1)',
    'button-secondary-text': '#000000',
    'button-secondary-disabled': 'rgba(250, 250, 250, 0.5)',
    'button-secondary-disabled-text': 'rgba(0, 0, 0, 0.3)',

    'button-glass': 'rgba(0, 0, 0, 0.03)',
    'button-glass-hover': 'rgba(0, 0, 0, 0.06)',
    'button-glass-active': 'rgba(0, 0, 0, 0.1)',
    'button-glass-text': '#000000',

    // Overlay colors
    'overlay-light': 'rgba(255, 255, 255, 0.6)',
    'overlay-dark': 'rgba(0, 0, 0, 0.3)',
    'overlay-modal': 'rgba(0, 0, 0, 0.5)',
    'overlay-glass': 'rgba(255, 255, 255, 0.9)',
    backdrop: 'rgba(255, 255, 255, 0.95)',

    // Navigation
    'nav-background': 'rgba(255, 255, 255, 0.9)',
    'nav-border': 'rgba(0, 0, 0, 0.06)',
    'nav-text': '#666666',
    'nav-text-active': '#000000',
    'nav-indicator': '#0066ff',
    'nav-glass': 'rgba(255, 255, 255, 0.85)',

    // Sidebar colors (glass style)
    sidebar: 'rgba(255, 255, 255, 0.9)',
    'sidebar-text': '#666666',
    'sidebar-text-active': '#000000',
    'sidebar-hover': 'rgba(250, 250, 250, 0.8)',
    'sidebar-active': 'rgba(0, 102, 255, 0.15)',
    'sidebar-icon': '#666666',
    'sidebar-icon-active': '#0066ff',
    'sidebar-border': 'rgba(0, 0, 0, 0.06)',

    // Special effects
    glow: {
      primary: 'rgba(0, 102, 255, 0.4)',
      secondary: 'rgba(99, 102, 241, 0.4)',
      accent: 'rgba(0, 212, 255, 0.4)',
      success: 'rgba(0, 204, 102, 0.4)',
      error: 'rgba(255, 51, 102, 0.4)',
      warning: 'rgba(255, 170, 0, 0.4)',
    },

    // Skeleton/loading
    'skeleton-base': 'rgba(245, 245, 245, 0.8)',
    'skeleton-highlight': 'rgba(250, 250, 250, 0.9)',

    // Scrollbar
    'scroll-thumb': 'rgba(0, 0, 0, 0.15)',
    'scroll-thumb-hover': 'rgba(0, 0, 0, 0.25)',
    'scroll-track': 'rgba(245, 245, 245, 0.6)',

    // Other UI elements
    divider: 'rgba(0, 0, 0, 0.06)',
    'tooltip-background': 'rgba(0, 0, 0, 0.95)',
    'tooltip-text': '#ffffff',
  },

  // Glass blur effects - same as dark
  glass: {
    blur: {
      none: '0px',
      sm: '8px',
      md: '16px',
      lg: '24px',
      xl: '32px',
      '2xl': '48px',
    },
    backdrop: {
      blur: 'blur(20px)',
      'blur-sm': 'blur(10px)',
      'blur-md': 'blur(20px)',
      'blur-lg': 'blur(28px)',
      'blur-xl': 'blur(36px)',
      saturate: 'saturate(190%)',
      brightness: 'brightness(110%)',
    },
  },

  // Updated shadows for light theme
  shadows: {
    none: 'none',
    xs: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
    sm: '0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
    xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
    '2xl': '0 25px 50px -12px rgba(0, 0, 0, 0.15)',
    inner: 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.06)',
    'inner-md': 'inset 0 4px 6px -1px rgba(0, 0, 0, 0.1)',

    // Glow shadows for light theme
    'glow-sm': '0 0 15px rgba(0, 102, 255, 0.2)',
    'glow-md': '0 0 25px rgba(0, 102, 255, 0.25)',
    'glow-lg': '0 0 35px rgba(0, 102, 255, 0.3)',
    'glow-primary': '0 0 25px rgba(0, 102, 255, 0.25)',
    'glow-secondary': '0 0 25px rgba(99, 102, 241, 0.25)',
    'glow-accent': '0 0 25px rgba(0, 212, 255, 0.25)',
    'glow-success': '0 0 25px rgba(0, 204, 102, 0.25)',
    'glow-error': '0 0 25px rgba(255, 51, 102, 0.25)',

    // Card shadows for light theme
    'card': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 0 50px rgba(0, 102, 255, 0.08)',
    'card-hover': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 0 50px rgba(0, 102, 255, 0.15)',
  },

  // GSAP-ready animations - same as dark
  animations: {
    duration: {
      instant: '100ms',
      fast: '200ms',
      normal: '300ms',
      slow: '500ms',
      slower: '700ms',
      slowest: '1000ms',
    },
    ease: {
      linear: 'none',
      in: 'power2.in',
      out: 'power2.out',
      inOut: 'power2.inOut',
      inQuad: 'power2.in',
      outQuad: 'power2.out',
      inOutQuad: 'power2.inOut',
      inCubic: 'power3.in',
      outCubic: 'power3.out',
      inOutCubic: 'power3.inOut',
      inQuart: 'power4.in',
      outQuart: 'power4.out',
      inOutQuart: 'power4.inOut',
      elastic: 'elastic.out(1, 0.3)',
      bounce: 'bounce.out',
      back: 'back.out(1.7)',
    },
    fadeIn: 'fadeIn 300ms ease-out',
    fadeOut: 'fadeOut 300ms ease-in',
    slideIn: 'slideIn 300ms ease-out',
    slideOut: 'slideOut 300ms ease-in',
    scaleIn: 'scaleIn 200ms ease-out',
    scaleOut: 'scaleOut 200ms ease-in',
    spin: 'spin 1s linear infinite',
    ping: 'ping 1s cubic-bezier(0, 0, 0.2, 1) infinite',
    pulse: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
    bounce: 'bounce 1s infinite',
    shimmer: 'shimmer 2s linear infinite',
    glow: 'glow 2s ease-in-out infinite',
  },

  // Typography - same as dark
  fonts: {
    primary: "Lexend, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    secondary: "Montserrat, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    display: "Lexend, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    code: "JetBrains Mono, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"
  },

  fontSizes: {
    'chat-tiny': '0.625rem',
    'chat-small': '0.75rem',
    'chat-base': '0.875rem',
    'chat-large': '1rem',
    xs: '0.75rem',
    sm: '0.875rem',
    base: '1rem',
    lg: '1.125rem',
    xl: '1.25rem',
    '2xl': '1.5rem',
    '3xl': '1.875rem',
    '4xl': '2.25rem',
    '5xl': '3rem',
    '6xl': '3.75rem',
    '7xl': '4.5rem',
    '8xl': '6rem',
    '9xl': '8rem'
  },

  fontWeights: {
    thin: 100,
    extralight: 200,
    light: 300,
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
    extrabold: 800,
    black: 900
  },

  lineHeights: {
    none: '1',
    tight: '1.25',
    snug: '1.375',
    normal: '1.5',
    relaxed: '1.625',
    loose: '2',
    chat: '1.4',
  },

  letterSpacings: {
    tighter: '-0.05em',
    tight: '-0.025em',
    normal: '0em',
    wide: '0.025em',
    wider: '0.05em',
    widest: '0.1em',
  },

  borderRadius: {
    none: '0',
    xs: '0.25rem',
    sm: '0.375rem',
    md: '0.5rem',
    lg: '0.75rem',
    xl: '1rem',
    '2xl': '1.25rem',
    '3xl': '1.5rem',
    full: '9999px',
    'chat-bubble': '1.25rem',
    'chat-input': '1rem',
  },

  borderWidths: {
    none: '0',
    xs: '0.5px',
    thin: '1px',
    medium: '1.5px',
    thick: '2px',
    thicker: '4px'
  },

  spacing: {
    0: '0',
    px: '1px',
    xs: '0.25rem',
    sm: '0.5rem',
    md: '1rem',
    lg: '1.5rem',
    xl: '2rem',
    '2xl': '2.5rem',
    '3xl': '3rem',
    '4xl': '4rem',
    '5xl': '5rem',
    '6xl': '6rem',
    'chat-gap': '0.75rem',
    'message-gap': '0.5rem',
  },

  zIndices: {
    0: '0',
    10: '10',
    20: '20',
    30: '30',
    40: '40',
    50: '50',
    dropdown: '1000',
    sticky: '1100',
    overlay: '1300',
    modal: '1400',
    popover: '1500',
    tooltip: '1600',
    'chat-input': '100',
    'chat-bubble': '10',
    'camera-overlay': '1200',
  },

  opacity: {
    0: '0',
    5: '0.05',
    10: '0.1',
    20: '0.2',
    25: '0.25',
    30: '0.3',
    40: '0.4',
    50: '0.5',
    60: '0.6',
    70: '0.7',
    75: '0.75',
    80: '0.8',
    90: '0.9',
    95: '0.95',
    100: '1',
    'glass-light': '0.03',
    'glass-medium': '0.15',
    'glass-heavy': '0.8',
  },

  gradients: {
    'primary-gradient': 'linear-gradient(135deg, #0066ff 0%, #0052cc 100%)',
    'secondary-gradient': 'linear-gradient(135deg, #6366f1 0%, #4f46e5 100%)',
    'accent-gradient': 'linear-gradient(135deg, #00d4ff 0%, #00aacc 100%)',
    'primary-to-secondary': 'linear-gradient(135deg, #0066ff 0%, #6366f1 100%)',
    'primary-to-accent': 'linear-gradient(135deg, #0066ff 0%, #00d4ff 100%)',
    'secondary-to-accent': 'linear-gradient(135deg, #6366f1 0%, #00d4ff 100%)',
    'glass-gradient': 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(255, 255, 255, 0.8) 100%)',
    'glass-border': 'linear-gradient(135deg, rgba(0, 0, 0, 0.08) 0%, rgba(0, 0, 0, 0.03) 100%)',
    'glow-primary': 'radial-gradient(circle at center, rgba(0, 102, 255, 0.15) 0%, rgba(0, 102, 255, 0) 70%)',
    'glow-secondary': 'radial-gradient(circle at center, rgba(99, 102, 241, 0.15) 0%, rgba(99, 102, 241, 0) 70%)',
    'glow-accent': 'radial-gradient(circle at center, rgba(0, 212, 255, 0.15) 0%, rgba(0, 212, 255, 0) 70%)',
    'mesh-primary': 'radial-gradient(at 20% 80%, rgba(0, 102, 255, 0.12) 0px, transparent 50%), radial-gradient(at 80% 20%, rgba(99, 102, 241, 0.12) 0px, transparent 50%), radial-gradient(at 40% 40%, rgba(0, 212, 255, 0.08) 0px, transparent 50%)',
  },

  transitions: {
    fast: '150ms',
    normal: '300ms',
    slow: '500ms',
    ease: 'cubic-bezier(0.4, 0, 0.2, 1)',
    in: 'cubic-bezier(0.4, 0, 1, 1)',
    out: 'cubic-bezier(0, 0, 0.2, 1)',
    'in-out': 'cubic-bezier(0.4, 0, 0.2, 1)'
  },
};

export default lightTheme;
