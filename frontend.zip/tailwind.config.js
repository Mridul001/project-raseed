/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  darkMode: 'class', // This ensures dark mode works with the 'dark' class
  theme: {
    extend: {
      colors: {
        // Base colors
        background: 'var(--color-background)',
        foreground: 'var(--color-foreground)',

        // Sidebar colors
        sidebar: {
          DEFAULT: 'var(--color-sidebar)',
          text: 'var(--color-sidebar-text)',
          'text-active': 'var(--color-sidebar-text-active)',
          hover: 'var(--color-sidebar-hover)',
          active: 'var(--color-sidebar-active)',
          icon: 'var(--color-sidebar-icon)',
          'icon-active': 'var(--color-sidebar-icon-active)',
          border: 'var(--color-sidebar-border)',
        },

        // Primary palette - Enhanced vibrant blue
        primary: {
          DEFAULT: 'var(--color-primary)',
          light: 'var(--color-primary-light)',
          dark: 'var(--color-primary-dark)',
          contrast: 'var(--color-primary-contrast)',
          glass: 'var(--color-primary-glass)',
          glow: 'var(--color-primary-glow)',
        },

        // Secondary palette - Enhanced purple-blue
        secondary: {
          DEFAULT: 'var(--color-secondary)',
          light: 'var(--color-secondary-light)',
          dark: 'var(--color-secondary-dark)',
          contrast: 'var(--color-secondary-contrast)',
          glass: 'var(--color-secondary-glass)',
          glow: 'var(--color-secondary-glow)',
        },

        // Accent colors - Enhanced vibrant cyan
        accent: {
          DEFAULT: 'var(--color-accent)',
          light: 'var(--color-accent-light)',
          dark: 'var(--color-accent-dark)',
          contrast: 'var(--color-accent-contrast)',
          glass: 'var(--color-accent-glass)',
          glow: 'var(--color-accent-glow)',
        },

        // Enhanced Surface colors
        surface: {
          DEFAULT: 'var(--color-surface)',
          100: 'var(--color-surface-100)',
          200: 'var(--color-surface-200)',
          300: 'var(--color-surface-300)',
          hover: 'var(--color-surface-hover)',
          pressed: 'var(--color-surface-pressed)',
          elevated: 'var(--color-surface-elevated)',
        },

        // Enhanced Glassmorphic colors
        glass: {
          primary: 'var(--color-glass-primary)',
          secondary: 'var(--color-glass-secondary)',
          tertiary: 'var(--color-glass-tertiary)',
          heavy: 'var(--color-glass-heavy)',
          light: 'var(--color-glass-light)',
          frosted: 'var(--color-glass-frosted)',
        },

        // Enhanced Chat & AI specific colors
        chat: {
          'user-bubble': 'var(--color-chat-user-bubble)',
          'user-text': 'var(--color-chat-user-text)',
          'ai-bubble': 'var(--color-chat-ai-bubble)',
          'ai-text': 'var(--color-chat-ai-text)',
          'input-bg': 'var(--color-chat-input-bg)',
          'input-border': 'var(--color-chat-input-border)',
          'typing-indicator': 'var(--color-chat-typing-indicator)',
        },

        // Enhanced Camera UI colors
        camera: {
          overlay: 'var(--color-camera-overlay)',
          frame: 'var(--color-camera-frame)',
          button: 'var(--color-camera-button)',
          'button-hover': 'var(--color-camera-button-hover)',
          indicator: 'var(--color-camera-indicator)',
        },

        // Enhanced Content/text colors
        content: {
          primary: 'var(--color-content-primary)',
          secondary: 'var(--color-content-secondary)',
          tertiary: 'var(--color-content-tertiary)',
          disabled: 'var(--color-content-disabled)',
          inverse: 'var(--color-content-inverse)',
          link: 'var(--color-content-link)',
          'link-hover': 'var(--color-content-link-hover)',
        },

        // Enhanced Status colors with glow variants
        success: {
          DEFAULT: 'var(--color-success)',
          light: 'var(--color-success-light)',
          dark: 'var(--color-success-dark)',
          contrast: 'var(--color-success-contrast)',
          surface: 'var(--color-success-surface)',
          glow: 'var(--color-success-glow)',
        },
        error: {
          DEFAULT: 'var(--color-error)',
          light: 'var(--color-error-light)',
          dark: 'var(--color-error-dark)',
          contrast: 'var(--color-error-contrast)',
          surface: 'var(--color-error-surface)',
          glow: 'var(--color-error-glow)',
        },
        warning: {
          DEFAULT: 'var(--color-warning)',
          light: 'var(--color-warning-light)',
          dark: 'var(--color-warning-dark)',
          contrast: 'var(--color-warning-contrast)',
          surface: 'var(--color-warning-surface)',
          glow: 'var(--color-warning-glow)',
        },
        info: {
          DEFAULT: 'var(--color-info)',
          light: 'var(--color-info-light)',
          dark: 'var(--color-info-dark)',
          contrast: 'var(--color-info-contrast)',
          surface: 'var(--color-info-surface)',
          glow: 'var(--color-info-glow)',
        },

        // Enhanced Glow colors
        glow: {
          primary: 'var(--color-glow-primary)',
          secondary: 'var(--color-glow-secondary)',
          accent: 'var(--color-glow-accent)',
          success: 'var(--color-glow-success)',
          error: 'var(--color-glow-error)',
          warning: 'var(--color-glow-warning)',
        },

        // Neutral colors
        muted: {
          DEFAULT: 'var(--color-muted)',
          light: 'var(--color-muted-light)',
          dark: 'var(--color-muted-dark)',
          hover: 'var(--color-muted-hover)',
          pressed: 'var(--color-muted-pressed)',
        },

        // Enhanced Border colors
        border: {
          DEFAULT: 'var(--color-border)',
          light: 'var(--color-border-light)',
          dark: 'var(--color-border-dark)',
          hover: 'var(--color-border-hover)',
          focus: 'var(--color-border-focus)',
          glow: 'var(--color-border-glow)',
        },

        // Enhanced Card and container colors
        card: {
          DEFAULT: 'var(--color-card)',
          hover: 'var(--color-card-hover)',
          header: 'var(--color-card-header)',
          footer: 'var(--color-card-footer)',
          border: 'var(--color-card-border)',
        },

        // Enhanced Input colors
        input: {
          DEFAULT: 'var(--color-input)',
          border: 'var(--color-input-border)',
          'hover-border': 'var(--color-input-hover-border)',
          'focus-border': 'var(--color-input-focus-border)',
          'focus-ring': 'var(--color-input-focus-ring)',
          disabled: 'var(--color-input-disabled)',
          'disabled-border': 'var(--color-input-disabled-border)',
          placeholder: 'var(--color-input-placeholder)',
          icon: 'var(--color-input-icon)',
        },

        // Enhanced Button colors
        button: {
          primary: 'var(--color-button-primary)',
          'primary-hover': 'var(--color-button-primary-hover)',
          'primary-active': 'var(--color-button-primary-active)',
          'primary-text': 'var(--color-button-primary-text)',
          'primary-disabled': 'var(--color-button-primary-disabled)',
          'primary-disabled-text': 'var(--color-button-primary-disabled-text)',

          secondary: 'var(--color-button-secondary)',
          'secondary-hover': 'var(--color-button-secondary-hover)',
          'secondary-active': 'var(--color-button-secondary-active)',
          'secondary-text': 'var(--color-button-secondary-text)',
          'secondary-disabled': 'var(--color-button-secondary-disabled)',
          'secondary-disabled-text': 'var(--color-button-secondary-disabled-text)',

          glass: 'var(--color-button-glass)',
          'glass-hover': 'var(--color-button-glass-hover)',
          'glass-active': 'var(--color-button-glass-active)',
          'glass-text': 'var(--color-button-glass-text)',

          tertiary: 'var(--color-button-tertiary)',
          'tertiary-hover': 'var(--color-button-tertiary-hover)',
          'tertiary-active': 'var(--color-button-tertiary-active)',
          'tertiary-text': 'var(--color-button-tertiary-text)',
          'tertiary-disabled': 'var(--color-button-tertiary-disabled)',
          'tertiary-disabled-text': 'var(--color-button-tertiary-disabled-text)',

          danger: 'var(--color-button-danger)',
          'danger-hover': 'var(--color-button-danger-hover)',
          'danger-active': 'var(--color-button-danger-active)',
          'danger-text': 'var(--color-button-danger-text)',
          'danger-disabled': 'var(--color-button-danger-disabled)',
          'danger-disabled-text': 'var(--color-button-danger-disabled-text)',
        },

        // Enhanced Overlay colors
        overlay: {
          light: 'var(--color-overlay-light)',
          dark: 'var(--color-overlay-dark)',
          modal: 'var(--color-overlay-modal)',
          glass: 'var(--color-overlay-glass)',
        },
        backdrop: 'var(--color-backdrop)',

        // Enhanced Navigation
        nav: {
          background: 'var(--color-nav-background)',
          border: 'var(--color-nav-border)',
          text: 'var(--color-nav-text)',
          'text-active': 'var(--color-nav-text-active)',
          indicator: 'var(--color-nav-indicator)',
          glass: 'var(--color-nav-glass)',
        },

        // Table colors
        table: {
          header: 'var(--color-table-header)',
          border: 'var(--color-table-border)',
          'row-hover': 'var(--color-table-row-hover)',
          'row-stripe': 'var(--color-table-row-stripe)',
        },

        // Enhanced Tooltip colors
        tooltip: {
          background: 'var(--color-tooltip-background)',
          text: 'var(--color-tooltip-text)',
        },

        // Badge colors
        badge: {
          default: 'var(--color-badge-default)',
          'default-text': 'var(--color-badge-default-text)',
          primary: 'var(--color-badge-primary)',
          'primary-text': 'var(--color-badge-primary-text)',
          secondary: 'var(--color-badge-secondary)',
          'secondary-text': 'var(--color-badge-secondary-text)',
          success: 'var(--color-badge-success)',
          'success-text': 'var(--color-badge-success-text)',
          error: 'var(--color-badge-error)',
          'error-text': 'var(--color-badge-error-text)',
          warning: 'var(--color-badge-warning)',
          'warning-text': 'var(--color-badge-warning-text)',
          info: 'var(--color-badge-info)',
          'info-text': 'var(--color-badge-info-text)',
        },

        // Progress bar colors
        progress: {
          background: 'var(--color-progress-background)',
          primary: 'var(--color-progress-primary)',
          success: 'var(--color-progress-success)',
          error: 'var(--color-progress-error)',
          warning: 'var(--color-progress-warning)',
          info: 'var(--color-progress-info)',
        },

        // Enhanced Scroll colors
        scroll: {
          thumb: 'var(--color-scroll-thumb)',
          'thumb-hover': 'var(--color-scroll-thumb-hover)',
          track: 'var(--color-scroll-track)',
        },

        // Switch colors
        switch: {
          off: 'var(--color-switch-off)',
          'off-background': 'var(--color-switch-off-background)',
          on: 'var(--color-switch-on)',
          'on-background': 'var(--color-switch-on-background)',
          disabled: 'var(--color-switch-disabled)',
          'disabled-background': 'var(--color-switch-disabled-background)',
        },

        // Slider colors
        slider: {
          track: 'var(--color-slider-track)',
          range: 'var(--color-slider-range)',
          thumb: 'var(--color-slider-thumb)',
          'thumb-border': 'var(--color-slider-thumb-border)',
          disabled: 'var(--color-slider-disabled)',
        },

        // Menu colors
        menu: {
          background: 'var(--color-menu-background)',
          border: 'var(--color-menu-border)',
          item: 'var(--color-menu-item)',
          'item-hover': 'var(--color-menu-item-hover)',
          'item-disabled': 'var(--color-menu-item-disabled)',
          'item-selected': 'var(--color-menu-item-selected)',
          divider: 'var(--color-menu-divider)',
        },

        // Enhanced Divider
        divider: 'var(--color-divider)',

        // Enhanced Skeleton/loading
        skeleton: {
          base: 'var(--color-skeleton-base)',
          highlight: 'var(--color-skeleton-highlight)',
        },
      },
      fontFamily: {
        primary: ['var(--font-primary)'],
        secondary: ['var(--font-secondary)'],
        tertiary: ['var(--font-tertiary)'],
        code: ['var(--font-code)'],
      },
      fontSize: {
        // Enhanced chat specific sizes
        'chat-tiny': 'var(--font-size-chat-tiny)',
        'chat-small': 'var(--font-size-chat-small)',
        'chat-base': 'var(--font-size-chat-base)',
        'chat-large': 'var(--font-size-chat-large)',

        // Standard sizes
        xs: 'var(--font-size-xs)',
        sm: 'var(--font-size-sm)',
        base: 'var(--font-size-base)',
        lg: 'var(--font-size-lg)',
        xl: 'var(--font-size-xl)',
        '2xl': 'var(--font-size-2xl)',
        '3xl': 'var(--font-size-3xl)',
        '4xl': 'var(--font-size-4xl)',
        '5xl': 'var(--font-size-5xl)',
        '6xl': 'var(--font-size-6xl)',
        '7xl': 'var(--font-size-7xl)',
        '8xl': 'var(--font-size-8xl)',
        '9xl': 'var(--font-size-9xl)',
      },
      fontWeight: {
        thin: 'var(--font-weight-thin)',
        extralight: 'var(--font-weight-extralight)',
        light: 'var(--font-weight-light)',
        normal: 'var(--font-weight-normal)',
        medium: 'var(--font-weight-medium)',
        semibold: 'var(--font-weight-semibold)',
        bold: 'var(--font-weight-bold)',
        extrabold: 'var(--font-weight-extrabold)',
        black: 'var(--font-weight-black)',
      },
      lineHeight: {
        none: 'var(--line-height-none)',
        tight: 'var(--line-height-tight)',
        snug: 'var(--line-height-snug)',
        normal: 'var(--line-height-normal)',
        relaxed: 'var(--line-height-relaxed)',
        loose: 'var(--line-height-loose)',
        chat: 'var(--line-height-chat)',
      },
      letterSpacing: {
        tighter: 'var(--letter-spacing-tighter)',
        tight: 'var(--letter-spacing-tight)',
        normal: 'var(--letter-spacing-normal)',
        wide: 'var(--letter-spacing-wide)',
        wider: 'var(--letter-spacing-wider)',
        widest: 'var(--letter-spacing-widest)',
      },
      borderRadius: {
        none: 'var(--radius-none)',
        xs: 'var(--radius-xs)',
        sm: 'var(--radius-sm)',
        md: 'var(--radius-md)',
        lg: 'var(--radius-lg)',
        xl: 'var(--radius-xl)',
        '2xl': 'var(--radius-2xl)',
        '3xl': 'var(--radius-3xl)',
        full: 'var(--radius-full)',
        // Enhanced chat specific radius
        'chat-bubble': 'var(--radius-chat-bubble)',
        'chat-input': 'var(--radius-chat-input)',
      },
      borderWidth: {
        none: 'var(--border-width-none)',
        xs: 'var(--border-width-xs)',
        thin: 'var(--border-width-thin)',
        medium: 'var(--border-width-medium)',
        thick: 'var(--border-width-thick)',
        thicker: 'var(--border-width-thicker)',
      },
      spacing: {
        0: 'var(--spacing-0)',
        px: 'var(--spacing-px)',
        xs: 'var(--spacing-xs)',
        sm: 'var(--spacing-sm)',
        md: 'var(--spacing-md)',
        lg: 'var(--spacing-lg)',
        xl: 'var(--spacing-xl)',
        '2xl': 'var(--spacing-2xl)',
        '3xl': 'var(--spacing-3xl)',
        '4xl': 'var(--spacing-4xl)',
        '5xl': 'var(--spacing-5xl)',
        '6xl': 'var(--spacing-6xl)',
        // Enhanced chat specific spacing
        'chat-gap': 'var(--spacing-chat-gap)',
        'message-gap': 'var(--spacing-message-gap)',
      },
      boxShadow: {
        none: 'var(--shadow-none)',
        xs: 'var(--shadow-xs)',
        sm: 'var(--shadow-sm)',
        md: 'var(--shadow-md)',
        lg: 'var(--shadow-lg)',
        xl: 'var(--shadow-xl)',
        '2xl': 'var(--shadow-2xl)',
        inner: 'var(--shadow-inner)',
        'inner-md': 'var(--shadow-inner-md)',
        outlined: 'var(--shadow-outlined)',

        // Enhanced glow shadows
        'glow-sm': 'var(--shadow-glow-sm)',
        'glow-md': 'var(--shadow-glow-md)',
        'glow-lg': 'var(--shadow-glow-lg)',
        'glow-primary': 'var(--shadow-glow-primary)',
        'glow-secondary': 'var(--shadow-glow-secondary)',
        'glow-accent': 'var(--shadow-glow-accent)',
        'glow-success': 'var(--shadow-glow-success)',
        'glow-error': 'var(--shadow-glow-error)',

        // Enhanced card shadows
        card: 'var(--shadow-card)',
        'card-hover': 'var(--shadow-card-hover)',
      },
      transitionDuration: {
        instant: 'var(--animation-duration-instant)',
        fast: 'var(--animation-duration-fast)',
        normal: 'var(--animation-duration-normal)',
        slow: 'var(--animation-duration-slow)',
        slower: 'var(--animation-duration-slower)',
        slowest: 'var(--animation-duration-slowest)',
      },
      transitionTimingFunction: {
        ease: 'var(--transition-ease)',
        in: 'var(--transition-in)',
        out: 'var(--transition-out)',
        'in-out': 'var(--transition-in-out)',
        linear: 'var(--animation-ease-linear)',
        elastic: 'var(--animation-ease-elastic)',
        bounce: 'var(--animation-ease-bounce)',
        back: 'var(--animation-ease-back)',
      },
      zIndex: {
        0: 'var(--z-0)',
        10: 'var(--z-10)',
        20: 'var(--z-20)',
        30: 'var(--z-30)',
        40: 'var(--z-40)',
        50: 'var(--z-50)',
        dropdown: 'var(--z-dropdown)',
        sticky: 'var(--z-sticky)',
        overlay: 'var(--z-overlay)',
        modal: 'var(--z-modal)',
        popover: 'var(--z-popover)',
        tooltip: 'var(--z-tooltip)',
        'chat-input': 'var(--z-chat-input)',
        'chat-bubble': 'var(--z-chat-bubble)',
        'camera-overlay': 'var(--z-camera-overlay)',
      },
      opacity: {
        0: 'var(--opacity-0)',
        5: 'var(--opacity-5)',
        10: 'var(--opacity-10)',
        20: 'var(--opacity-20)',
        25: 'var(--opacity-25)',
        30: 'var(--opacity-30)',
        40: 'var(--opacity-40)',
        50: 'var(--opacity-50)',
        60: 'var(--opacity-60)',
        70: 'var(--opacity-70)',
        75: 'var(--opacity-75)',
        80: 'var(--opacity-80)',
        90: 'var(--opacity-90)',
        95: 'var(--opacity-95)',
        100: 'var(--opacity-100)',
        // Enhanced glass specific opacity
        'glass-light': 'var(--opacity-glass-light)',
        'glass-medium': 'var(--opacity-glass-medium)',
        'glass-heavy': 'var(--opacity-glass-heavy)',
      },
      backdropBlur: {
        none: 'var(--blur-none)',
        sm: 'var(--blur-sm)',
        md: 'var(--blur-md)',
        lg: 'var(--blur-lg)',
        xl: 'var(--blur-xl)',
        '2xl': 'var(--blur-2xl)',
        '3xl': 'var(--blur-3xl)',
      },
      backgroundImage: {
        // Enhanced gradients
        'primary-gradient': 'var(--gradient-primary-gradient)',
        'secondary-gradient': 'var(--gradient-secondary-gradient)',
        'accent-gradient': 'var(--gradient-accent-gradient)',
        'primary-to-secondary': 'var(--gradient-primary-to-secondary)',
        'primary-to-accent': 'var(--gradient-primary-to-accent)',
        'secondary-to-accent': 'var(--gradient-secondary-to-accent)',
        'primary-to-primary-dark': 'var(--gradient-primary-to-primary-dark)',
        'secondary-to-secondary-dark': 'var(--gradient-secondary-to-secondary-dark)',
        'accent-to-accent-dark': 'var(--gradient-accent-to-accent-dark)',
        'success-to-info': 'var(--gradient-success-to-info)',
        'error-to-warning': 'var(--gradient-error-to-warning)',

        // Enhanced glass gradients
        'glass-gradient': 'var(--gradient-glass-gradient)',
        'glass-border': 'var(--gradient-glass-border)',

        // Enhanced glow gradients
        'glow-primary': 'var(--gradient-glow-primary)',
        'glow-secondary': 'var(--gradient-glow-secondary)',
        'glow-accent': 'var(--gradient-glow-accent)',

        // Enhanced mesh gradients
        'mesh-primary': 'var(--gradient-mesh-primary)',
      },
      animation: {
        // Enhanced animations
        spin: 'var(--animation-spin)',
        ping: 'var(--animation-ping)',
        pulse: 'var(--animation-pulse)',
        bounce: 'var(--animation-bounce)',
        fadeIn: 'var(--animation-fadeIn)',
        fadeOut: 'var(--animation-fadeOut)',
        slideIn: 'var(--animation-slideIn)',
        slideOut: 'var(--animation-slideOut)',
        scaleIn: 'var(--animation-scaleIn)',
        scaleOut: 'var(--animation-scaleOut)',
        shimmer: 'var(--animation-shimmer)',
        glow: 'var(--animation-glow)',
      },
    },
  },
  plugins: [],
}
